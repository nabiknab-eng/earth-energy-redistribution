# Known limitations

- The common trend record is short (approximately 2006–2022 after derivative
  alignment) and contains strong serial dependence.
- ERA5 is a reanalysis.  Its structural trend uncertainty and observing-system
  changes are not fully quantified by temporal HAC intervals.
- NCEI OHC covers 0–2000 m; deep-ocean storage is omitted.
- Cap-resolved OHC mapping and sampling uncertainty is not fully quantified.
- Land heat, glacier/ice-sheet enthalpy and several sea-ice sensible/structural
  terms are omitted from `E_known`.
- PIOMAS is a model-assimilation product.  The three scaling scenarios do not
  span its complete structural uncertainty.
- SH sea-ice storage is not included in the NH-focused corrected branch.
- CERES EBAF and OHC are partly statistically dependent through the EBAF global
  energy-balance constraint.
- `H_raw` is implied under a uniform global-storage proxy, not actual transport.
- `H_corr` is known-storage-corrected required transport, not independently
  observed actual total transport.
- `H_corr - AHT` is unresolved/non-atmospheric remainder, not automatically
  ocean heat transport.
- The post-audit maximum-DGP interval is a calibrated scenario envelope.  Its
  transfer to every real multicomponent series is an open question.
- The original structural bound and combined safe threshold were retired; no
  replacement combined uncertainty distribution is claimed.
- Non-detection is not evidence of a zero trend or absence of physical change.
- Reference figures are didactic outputs, not independent evidence, and their
  captions/axes/signs remain objects of audit.
- No conclusion in this bundle attributes ASR, transport or Arctic energy
  change to CO2, clouds, aerosols or forcing.
