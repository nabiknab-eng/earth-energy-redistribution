# Expected raw metadata contract

These checks identify the requested products after a fresh download.  A
failure stops the supplied pipeline; the reviewer should diagnose rather than
silently coerce the input.

| Dataset | Expected decoded contract |
|---|---|
| CERES EBAF Ed4.2.1 | `time=313`, `lat=180`; 2000-03–2026-03; all requested `z*` and `g*` flux variables present; flux units `W m-2`; latitude south-to-north |
| ERA5 v1.0 | CF-1.6 NetCDF4 monthly members; 0.25° grid; 1,441 longitude nodes with one cyclic duplicate and 1,440 unique longitudes; latitude increasing; `tefln` `W m**-1`; `tetend` `W m**-2`; exact member counts and request coverage from JSON |
| NCEI OHC | title contains `0-2000 m monthly 1.00 degree`; `h18_hc` shape at least `(216,1,180,360)`; unit `10^18_joules`; native 1° grid; requested 2005-01–2022-12 available |
| PIOMAS v2.1 | official aggregate CSV header includes year; each `heff.HYYYY.nc.gz` decodes to `heff(12,120,360)` in metres; `lat_scaler`, `kmt`, `dxt`, `dyt` present; model attribute identifies PIOMAS |

Additional mandatory runtime checks:

- no duplicate months or missing requested months;
- coordinate monotonicity and exact latitude rows used by boundary extraction;
- finite samples and stable physical units;
- unique ERA5 longitudes before zonal integration;
- cap areas equal analytic spherical cap areas;
- CERES row areas sum to the Earth area;
- transport equals zero at both poles within numerical tolerance;
- generated monthly series have the declared common period and one row per
  time/latitude key.

Live rolling CERES, OHC or PIOMAS aggregate sources may contain newer months.
The script deliberately selects the declared historical range.  If a product
version or numerical field has been revised, preserve the fresh result and
document the revision; do not tune it to the author's reference.
