# Response to the first external audit

This is an audit trail, not a claim that the corrections are necessarily
right.  The V4 reviewer must independently audit both the original findings
and the repairs.  Full generated records are in `stage10_audit_response/`; the
original HTML and unchanged external Monte Carlo scripts are in
`first_external_audit/`.

## N1 — primary HAC(24) undercoverage

**AUDITOR CLAIM →** The primary overlapping storage derivative with HAC(24)
substantially undercovers; nominal uncertainty is too narrow.

**OUR REPRODUCTION →** Unchanged external runs gave coverage 77.925% for AR(1)
phi=0, 76.775% for phi=0.6 and 69.025% for phi=0.9.  The expanded matrix spans
67.5–81.2% for the relevant nominal branch.

**STATUS → CONFIRMED.**

**CHANGE MADE →** Keep the point estimator, compute the full declared DGP
matrix, and multiply the selected HAC standard error by the maximum
DGP-specific empirical q95 of `|estimate-truth|/SE` (critical value 4.569 for
the primary derivative).

**NUMERICAL EFFECT →** Point trends are unchanged.  At 60/65/70°N, the former
nominal half-widths 42.40/34.37/31.24 become calibrated temporal half-widths
98.85/80.12/72.84 TW decade-1.  All intervals contain zero.

**REMAINING OPEN QUESTION →** Whether this maximum-DGP scenario calibration
transfers to a multicomponent real `H_corr` series, and whether a residual-based
or fixed-b/bootstrap method is better.

## N2 — invalid annual-difference HAC inference

**AUDITOR CLAIM →** With only 16 annual observations, requested HAC lag 24
collapses to an extreme effective lag and gives roughly 46–51% coverage.

**OUR REPRODUCTION →** The failure was reproduced (approximately 45.8–51.1%).

**STATUS → CONFIRMED.**

**CHANGE MADE →** Old annual confidence intervals are explicitly invalidated;
annual difference now uses effective lag 2 plus a Monte Carlo critical value
4.106.  The annual branch is sensitivity evidence, not an independent proof.

**NUMERICAL EFFECT →** Annual `H_corr` point estimates at 60/65/70°N remain
-1.06/+0.07/+4.64 TW decade-1, with corrected intervals
[-72.48,70.35]/[-51.02,51.15]/[-35.65,44.93].  A former 75°N interval excluding
zero becomes [-25.57,40.25].

**REMAINING OPEN QUESTION →** Very-small-sample inference remains weak even
after the lag correction.

## N3 — structural bound and safe threshold

**AUDITOR CLAIM →** The former structural bound double-counted temporal noise
and included ad-hoc area/scaling assumptions; adding it to temporal MDE was not
a coherent probability statement.

**OUR REPRODUCTION →** The component audit confirmed temporal-MDE proxies,
Earth-area sea-ice scaling and an unsupported glacier step.

**STATUS → CONFIRMED.**

**CHANGE MADE →** Retire the structural bound and combined safe threshold.
Separate (A) temporal inference, (B) quantified method scenarios, and (C)
unquantified structural limitations.  No replacement ad-hoc sum was created.

**NUMERICAL EFFECT →** Former safe thresholds 63.30/51.93/47.35 TW decade-1 at
60/65/70°N are no longer used.  The primary reported temporal half-widths are
98.85/80.12/72.84, while deep ocean, OHC mapping, land/glacier, PIOMAS structure
and ERA5 structure remain unquantified.

**REMAINING OPEN QUESTION →** A defensible probabilistic structural model is
still absent; unquantified is not zero.

## N4 — storage alias is algebraic

**AUDITOR CLAIM →** `raw - alias = H_corr` is an identity and was given too much
weight as if it independently validated the corrected result.

**OUR REPRODUCTION →** Direct symbolic and numerical checks confirm
`H_raw - H_alias = dE_known/dt - N_cap`.

**STATUS → CONFIRMED.**

**CHANGE MADE →** Rename and interpret storage alias strictly as the difference
between a uniform global-storage proxy and known regional storage.  Estimate
its interval directly from the joint monthly series so covariance is retained.

**NUMERICAL EFFECT →** Alias trends at 60/65/70°N are
21.30/18.23/12.18 TW decade-1, with calibrated intervals
[-60.06,102.66]/[-38.58,75.04]/[-36.51,60.88]; none excludes zero.  `H_corr`
point values do not change.

**REMAINING OPEN QUESTION →** The explicit global-mean term cancels
algebraically, but the effect of CERES EBAF's global energy constraint on
regional `N_cap` and covariance still requires scrutiny.

## N5 — identities mislabeled as validation

**AUDITOR CLAIM →** Some PASS checks merely restated construction identities.

**OUR REPRODUCTION →** Several checks were algebraic; other grid, metadata and
numerical checks can catch implementation errors but not all observational
mapping errors.

**STATUS → PARTIALLY CONFIRMED.**

**CHANGE MADE →** Diagnostics are classified as algebraic identity, numerical
implementation, data integrity or independent comparison.

**NUMERICAL EFFECT →** No climate number changes; evidentiary weight is reduced
for identity-only PASS results.

**REMAINING OPEN QUESTION →** Static mask/coverage tests do not quantify Argo
mapping/sampling uncertainty.

## N6 — missing inference and structural tests

**AUDITOR CLAIM →** The original tests insufficiently covered statistical and
structural machinery.

**OUR REPRODUCTION →** Gaps were confirmed.

**STATUS → CONFIRMED.**

**CHANGE MADE →** Add known-trend/unit tests, small-n rejection, negative HAC
variance rejection, derivative tests, Monte Carlo coverage tests, storage
identity classification, retirement checks and PIOMAS scaling tests.

**NUMERICAL EFFECT →** Sixty-six targeted workspace tests passed after Stage 10;
the new tests force N1–N3 failures to remain visible.

**REMAINING OPEN QUESTION →** Passing tests cannot establish observational
truth or exhaust all plausible DGPs.

## N7 — PIOMAS scaling and defensive implementation issues

**AUDITOR CLAIM →** Monthly uniform scaling could inject a trend; variance was
silently clamped; regional-grid geometry and annual lag handling needed guards.

**OUR REPRODUCTION →** Scaling sensitivity exists; other points were valid
defensive concerns.

**STATUS → PARTIALLY CONFIRMED.**

**CHANGE MADE →** Compare monthly official scaling, constant mean scaling and no
scaling; reject negative HAC variance; reject incomplete regional latitude
geometry; declare and test the annual lag.

**NUMERICAL EFFECT →** Maximum tested scaling impact on `H_corr` trend is only
0.34/0.33/0.32 TW decade-1 at 60/65/70°N (roughly 0.17–0.35 over 50–80°N).

**REMAINING OPEN QUESTION →** This scenario spread is not full PIOMAS model or
sea-ice enthalpy uncertainty.

## R1 — alleged threefold derivative-efficiency difference

**AUDITOR CLAIM →** An earlier criticism said derivative estimators differed in
effective noise by about a factor of three.

**OUR REPRODUCTION →** The unchanged head-to-head script gives empirical SD
ratios only about 0.93–1.04.

**STATUS → INVALID / RETRACTED CRITICISM.**

**CHANGE MADE →** No estimator was selected to force a desired result; retain
all three as sensitivity branches.

**NUMERICAL EFFECT →** No point-estimate change.

**REMAINING OPEN QUESTION →** Similar empirical SD does not imply correct
coverage, which is handled separately under N1/N2.

## R2 — significance of selected raw/SH intervals

**AUDITOR CLAIM →** An earlier criticism relied on isolated nominal intervals
that excluded zero.

**OUR REPRODUCTION →** Applying the corrected calibration to all relevant
series removes that claimed significance.

**STATUS → INVALID / RETRACTED CRITICISM.**

**CHANGE MADE →** Use consistent calibrated inference and forbid treating the
alias identity as independent confirmation.

**NUMERICAL EFFECT →** The cited significance disappears; point estimates are
unchanged.

**REMAINING OPEN QUESTION →** Whether one calibrated critical value is valid
across all physical series remains unresolved.
