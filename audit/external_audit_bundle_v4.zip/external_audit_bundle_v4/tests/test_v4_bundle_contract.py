from pathlib import Path
import json
import re

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def test_no_climate_data_or_reduced_time_series_in_bundle():
    forbidden_suffixes = {".nc", ".nc4", ".grib", ".grb", ".h5", ".hdf", ".gz", ".zip"}
    offenders = [path for path in ROOT.rglob("*") if path.is_file() and path.suffix.lower() in forbidden_suffixes]
    assert offenders == []
    csvs = [path.name.lower() for path in ROOT.rglob("*.csv")]
    assert not any("timeseries" in name or "monthly_energy" in name for name in csvs)


def test_blind_workflow_does_not_read_reference_results():
    blind = (ROOT / "run_v4_blind_reproduction.sh").read_text()
    builder = (ROOT / "code" / "build_blind_results_table.py").read_text()
    assert "reference_results" not in blind
    assert "reference_results" not in builder
    assert "BLIND_REFERENCE_VALUES" not in blind
    assert "BLIND_REFERENCE_VALUES" not in builder


def test_reference_values_are_only_revealed_by_second_command():
    compare = (ROOT / "compare_after_blind.sh").read_text()
    assert "BLIND_REFERENCE_VALUES.csv" in compare
    assert "INCOMPLETE — RAW DATA REPRODUCTION NOT PERFORMED." in compare
    reference = pd.read_csv(ROOT / "reference_results" / "BLIND_REFERENCE_VALUES.csv")
    assert list(reference.columns) == ["quantity", "authors_reference", "tolerance"]
    assert reference.quantity.is_unique


def test_all_four_official_dataset_specs_are_present_and_nonempty():
    specs = ROOT / "download_specs"
    required = {
        "ceres_ebaf_ed4.2.1.json",
        "era5_requests.json",
        "ncei_ohc_0_2000_monthly.json",
        "piomas_v2.1.json",
        "piomas_original_files.json",
    }
    assert required <= {path.name for path in specs.iterdir()}
    for name in required:
        assert json.loads((specs / name).read_text())


def test_no_active_code_contains_author_machine_absolute_paths():
    offenders = []
    for path in list((ROOT / "code").rglob("*.py")) + list(ROOT.glob("*.sh")):
        text = path.read_text(errors="replace")
        if re.search(r"/Users/[^/]+/|[A-Za-z]:\\\\Users\\\\", text):
            offenders.append(str(path.relative_to(ROOT)))
    assert offenders == []


def test_required_v4_documents_exist():
    required = {
        "README_FOR_EXTERNAL_AUDIT.md", "REVIEWER_PROMPT.md",
        "RESPONSE_TO_FIRST_EXTERNAL_AUDIT.md", "METHODS.md",
        "DATA_DOWNLOAD_AND_PROVENANCE.md", "EXPECTED_RAW_METADATA.md",
        "CLAIMS_AND_EVIDENCE.md", "OPEN_METHODICAL_QUESTIONS.md",
        "KNOWN_LIMITATIONS.md", "FILE_MANIFEST.csv", "CHECKSUMS.sha256",
        "requirements-lock.txt", "V4_SELF_CHECK.md",
    }
    assert required <= {path.name for path in ROOT.iterdir()}
