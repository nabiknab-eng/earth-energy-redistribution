from pathlib import Path
import json

import numpy as np
import pandas as pd
import pytest

from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints
from src.energy_budget import decimal_year, ols_hac_trend
from src.post_audit_statistics import (
    annual_difference_batch,
    block_mean_derivative_batch,
    central_derivative_batch,
    integrate_tendency,
    legacy_hac_batch,
    ols_batch,
    synthetic_estimator_series,
)


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
RHO_ICE = 917.0
LATENT_HEAT_FUSION = 334_000.0


def test_ols_hac_known_trend_and_units():
    index = pd.date_range("2000-01-15", periods=120, freq="MS") + pd.Timedelta(days=14)
    years = decimal_year(index)
    # 0.001 PW/year = 10 TW/decade.
    trend = ols_hac_trend(2.0 + 0.001 * years, index, maxlags=12, deseasonalize=False)
    assert np.isclose(trend.slope_per_decade * 1000.0, 10.0, rtol=2e-3)
    assert trend.se_per_decade < 1e-10


def test_ols_hac_small_n_rejected():
    with pytest.raises(ValueError, match="at least three"):
        ols_hac_trend(np.array([1.0, 2.0]), pd.date_range("2000-01-01", periods=2), maxlags=1)


def test_primary_legacy_hac_undercoverage_and_mc_calibration_recovers():
    rng = np.random.default_rng(4102)
    index, values = synthetic_estimator_series("ar1_0.6", 0.0, 300, rng)["block_12m_means"]
    slopes, se, _ = legacy_hac_batch(values, index, 24)
    nominal = np.mean(np.abs(slopes) <= 1.959963984540054 * se)
    metadata = json.loads((OUT / "monte_carlo_calibration_metadata.json").read_text())
    critical = metadata["calibrated_critical_values"]["block_12m_means"]
    calibrated = np.mean(np.abs(slopes) <= critical * se)
    assert nominal < 0.88
    assert calibrated > 0.93


def test_linear_state_gives_constant_tendency_for_both_monthly_derivatives():
    index = monthly_midpoints("2005-01", 216)
    origin = index[0]
    seconds = np.asarray([(t - origin).total_seconds() for t in index])
    state = 7.5e12 * seconds
    _, block = block_mean_tendency(state, index)
    _, central = central_span_tendency(state, index)
    assert np.allclose(block, 7.5e12, rtol=2e-14)
    assert np.allclose(central, 7.5e12, rtol=2e-14)


def test_quadratic_state_gives_expected_linear_tendency_trend():
    index = monthly_midpoints("2005-01", 216)
    years = np.asarray([(t - index[0]).total_seconds() / (365.2425 * 86400) for t in index])
    tendency = (0.004 * (years - years.mean()))[None, :]
    state = integrate_tendency(tendency, index)
    products = {
        "block": block_mean_derivative_batch(state, index),
        "central": central_derivative_batch(state, index),
        "annual": annual_difference_batch(state, index),
    }
    for _, (time, values) in products.items():
        slope, _ = ols_batch(values, time)
        # 0.004 PW/year = 40 TW/decade; calendar midpoint integration is sub-percent.
        assert np.isclose(slope[0], 40.0, rtol=5e-3)


def test_storage_alias_and_hcorr_are_identity_not_independent_validation():
    frame = pd.read_csv(OUT / "storage_corrected_transport_timeseries.csv")
    q = frame[(frame.hemisphere == "NH") & (frame.boundary_abs_deg == 60) & (frame.method == "block_12m_means")]
    direct = q.known_storage_plus_sea_ice_pw - q.ntoa_cap_pw
    assert np.allclose(direct, q.h_known_plus_sea_ice_pw, atol=1e-13)
    delta = np.linspace(-0.2, 0.2, len(q))
    raw_perturbed = q.raw_implied_pw.to_numpy() + delta
    alias_perturbed = q.storage_alias_known_plus_sea_ice_pw.to_numpy() + delta
    assert np.allclose(raw_perturbed - alias_perturbed, direct, atol=1e-13)


def test_post_audit_structural_table_has_no_mde_bound_or_combined_threshold():
    structural = pd.read_csv(OUT / "post_audit_structural_uncertainty.csv")
    quantified = structural[structural.status != "UNQUANTIFIED"]
    assert not quantified.basis.str.contains("MDE", case=False).any()
    unquantified = structural[structural.status == "UNQUANTIFIED"]
    assert unquantified.plus_minus_tw_dec.isna().all()
    uncertainty = pd.read_csv(OUT / "POST_AUDIT_UNCERTAINTY.csv")
    assert uncertainty.combined_safe_threshold.isna().all()


def test_piomas_rescaling_sensitivity_is_continuous_in_latitude():
    d = pd.read_csv(OUT / "piomas_rescaling_diagnostics.csv").sort_values("boundary_deg_n")
    assert np.max(np.abs(np.diff(d.maximum_abs_rescaling_sensitivity_tw_dec))) < 0.1
    assert np.isfinite(d.factor_linear_trend_per_decade).all()
    assert np.isfinite(d.factor_quadratic_second_derivative_per_decade2).all()


def test_piomas_volume_to_latent_energy_and_rescaling_signal():
    ice = pd.read_csv(OUT / "sea_ice_cap_monthly_energy.csv")
    expected = -ice.sea_ice_volume_1000_km3 * 1e12 * RHO_ICE * LATENT_HEAT_FUSION
    assert np.allclose(expected, ice.sea_ice_latent_energy_j, rtol=2e-15)
    detail = pd.read_csv(OUT / "piomas_rescaling_sensitivity.csv")
    wide = detail.pivot(index="boundary_deg_n", columns="scaling_method", values="h_corr_trend_tw_dec")
    diagnostics = pd.read_csv(OUT / "piomas_rescaling_diagnostics.csv").set_index("boundary_deg_n")
    delta = (wide.monthly_official_scaling - wide.constant_mean_scaling).abs()
    assert np.allclose(delta, diagnostics.maximum_abs_rescaling_sensitivity_tw_dec, atol=1e-10)
    assert (delta < 0.4).all()


def test_annual_pre_audit_intervals_are_retired_and_replaced():
    annual = pd.read_csv(OUT / "post_audit_derivative_sensitivity.csv")
    q = annual[annual.estimator == "annual_difference"]
    assert q.old_ci_invalid.all()
    assert ((q.calibrated_ci_low_tw_dec <= 0) & (q.calibrated_ci_high_tw_dec >= 0)).all()
