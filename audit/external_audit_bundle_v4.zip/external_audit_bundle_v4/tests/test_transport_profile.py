import numpy as np
import pandas as pd

from src.analyze_ohc_storage import monthly_midpoints
from src.analyze_transport_profile import _filtered_components, _state_at, _summary_row
from src.energy_budget import PW, cap_area
from src.process_transport_profile_inputs import _cap_weights


def test_quarter_degree_cap_weights_reproduce_exact_cap_area():
    lat = np.arange(90.0, 29.75, -0.25)
    for boundary in (30.0, 47.0, 60.0, 70.0, 85.0):
        assert np.isclose(np.sum(_cap_weights(lat, boundary)), cap_area(boundary), rtol=2e-15)


def test_profile_budget_and_partition_are_exact_identities():
    time = monthly_midpoints("2005-01", 36)
    x = np.arange(36, dtype=float)
    raw = pd.DataFrame(
        {
            "time": time,
            "ohc_0_2000_j": (3.0e20 + x * 2.0e18),
            "ntoa_cap_pw": 0.4 + 0.01 * x,
            "raw_implied_pw": 0.5 + 0.01 * x,
            "atmospheric_storage_pw": 0.03 * np.sin(x),
            "aht_pw": 1.5 + 0.02 * x,
        }
    )
    out = _filtered_components(raw, "block_12m_means")
    assert np.max(np.abs(out.closure_residual_pw)) < 1e-14
    assert np.max(np.abs(out.partition_residual_pw)) < 1e-14
    assert np.allclose(out.h_known_pw, out.known_storage_pw - out.ntoa_cap_pw)
    assert np.allclose(out.non_atmospheric_residual_pw, out.h_known_pw - out.actual_aht_pw)


def test_linear_state_interpolation_is_exact():
    index = monthly_midpoints("2005-01", 24)
    origin = index[0]
    seconds = np.asarray([(t - origin).total_seconds() for t in index])
    values = 7.0 + 3.5 * seconds
    target = pd.Timestamp("2006-01-01")
    expected = 7.0 + 3.5 * (target - origin).total_seconds()
    assert np.isclose(_state_at(values, index, target), expected)


def test_detectability_uses_95_percent_ci_halfwidth():
    index = pd.date_range("2006-01-15", periods=193, freq="MS") + pd.Timedelta(days=14)
    rng = np.random.default_rng(42)
    values = 2.0 + np.arange(len(index)) * 0.001 + rng.normal(0, 0.02, len(index))
    row = _summary_row(60.0, "block_12m_means", "actual_aht", values, index)
    expected = 0.5 * (row["trend_ci_high_tw_dec"] - row["trend_ci_low_tw_dec"])
    assert np.isclose(row["minimum_detectable_trend_tw_dec_95"], expected)
    assert row["signal_to_ci_halfwidth"] >= 0
