from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"


def test_storage_alias_and_direct_budget_are_equivalent():
    frame = pd.read_csv(OUT / "storage_corrected_transport_timeseries.csv")
    assert np.max(
        np.abs(frame.raw_minus_h_known_pw - frame.storage_alias_known_pw)
    ) < 1e-12
    nh = frame[frame.hemisphere == "NH"]
    assert np.max(
        np.abs(
            nh.raw_minus_h_known_plus_sea_ice_pw
            - nh.storage_alias_known_plus_sea_ice_pw
        )
    ) < 1e-12


def test_algebraic_identity_is_numerically_closed_but_kept_separate():
    frame = pd.read_csv(OUT / "storage_corrected_transport_timeseries.csv")
    assert np.max(np.abs(frame.algebraic_closure_residual_pw)) < 1e-12
    closure = pd.read_csv(OUT / "closure_residual_profile.csv")
    assert (closure.unresolved_remainder_abs_mean_pw > 0).any()
    assert set(closure.interpretation) == {"undecidable"}


def test_detection_threshold_identity_and_primary_non_detection():
    frame = pd.read_csv(OUT / "storage_corrected_detection_limits.csv")
    nh = frame[frame.hemisphere == "NH"]
    assert np.allclose(
        nh.conservative_safe_threshold_tw_dec,
        nh.temporal_mde95_tw_dec + nh.structural_bound_tw_dec,
    )
    assert not nh.robust_above_safe_threshold.any()
    assert frame[frame.hemisphere == "SH"].structural_bound_tw_dec.isna().all()


def test_three_ohc_derivatives_are_present():
    frame = pd.read_csv(OUT / "storage_derivative_sensitivity.csv")
    methods = set(
        frame[
            (frame.hemisphere == "NH")
            & (frame.boundary_abs_deg == 60)
            & (frame.metric == "ohc_storage")
        ].method
    )
    assert methods == {
        "block_12m_means",
        "central_12m_endpoints",
        "annual_difference",
    }


def test_sh_is_partial_and_no_unverified_sea_ice_is_inserted():
    profile = pd.read_csv(OUT / "storage_corrected_transport_profile.csv")
    assert profile[
        (profile.hemisphere == "SH")
        & (profile.metric == "h_known_plus_sea_ice")
    ].empty
    decision = pd.read_csv(OUT / "sh_sea_ice_decision.csv")
    assert decision.decision.iloc[0] == "do_not_compute_SH_sea_ice_storage"
    coverage = pd.read_csv(OUT / "ohc_cap_coverage_nh_sh.csv")
    assert (
        coverage[
            (coverage.hemisphere == "SH")
            & (coverage.boundary_abs_deg == 80)
        ].interpretation_class.iloc[0]
        == "not_interpretable_as_cap_storage"
    )


def test_sh_aht_sign_is_poleward_positive():
    source = pd.read_csv(ROOT / "tables/era5_global_aht_monthly.csv")
    source["month"] = pd.to_datetime(source.time).dt.to_period("M")
    stage = pd.read_csv(
        OUT / "storage_corrected_transport_timeseries.csv", parse_dates=["time"]
    )
    q = stage[
        (stage.hemisphere == "SH")
        & (stage.boundary_abs_deg == 60)
        & (stage.method == "block_12m_means")
    ]
    assert q.actual_aht_poleward_pw.mean() > 0
    assert source[np.isclose(source.latitude_deg, -60)].actual_aht_pw.mean() < 0


def test_required_stage9_outputs_exist():
    names = [
        "STORAGE_CORRECTED_TRANSPORT.md",
        "STORAGE_COMPONENTS.md",
        "CLOSURE_DIAGNOSTICS.md",
        "DATA_DEPENDENCE_NOTE.md",
        "storage_alias_global_or_hemispheric_profile.png",
        "storage_components_vs_latitude.png",
        "total_aht_nonatmospheric_profile.png",
        "closure_residual_vs_latitude.png",
        "storage_corrected_detection_limits.png",
    ]
    for name in names:
        assert (OUT / name).stat().st_size > 100
