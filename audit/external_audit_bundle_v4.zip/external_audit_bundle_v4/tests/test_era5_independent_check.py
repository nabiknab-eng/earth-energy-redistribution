import json
import os
from pathlib import Path
import sys

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "code" / "era5"
sys.path.insert(0, str(HERE))

from reduce_raw_era5_independently import (
    GRID_DEG, PW_W, R_EARTH_M, cap_ring_weights_m2,
    cap_storage_tendency_w, zonal_energy_transport_w,
)

NUMERICAL_ABS_TOLERANCE_PW = 1.0e-9
PHYSICAL_MATERIALITY_PW = 1.0e-3


def test_summary_payloads_equal_immutable_original_requests():
    spec = json.loads((ROOT / "download_specs" / "era5_requests.json").read_text())
    assert spec["request_count"] == len(spec["requests"]) == 15
    for row in spec["requests"]:
        original = json.loads((HERE / row["original_request_source"]).read_text())
        match = [x for x in original if Path(x["path"]).name == row["download_filename"]]
        assert len(match) == 1
        assert row["cds_api_request_exact"] == match[0]["request"]
        assert set(row["cds_api_request_exact"]) == {"variable", "year", "month", "area"}


def test_request_volume_and_unique_chunk_names():
    spec = json.loads((ROOT / "download_specs" / "era5_requests.json").read_text())
    assert spec["expected_total_archive_bytes"] == 1_757_939_898
    assert len({row["download_filename"] for row in spec["requests"]}) == 15


def test_constant_w_per_m_zonal_flux_has_analytic_circumference_integral():
    lat = np.array([-60.0, 0.0, 60.0, 90.0])
    lon_keep = np.arange(1440)
    field = np.full((len(lat), 1440), 2.5)
    watts = zonal_energy_transport_w(field, lat, lon_keep, np.deg2rad(GRID_DEG))
    expected = 2.5 * 2.0 * np.pi * R_EARTH_M * np.cos(np.deg2rad(lat))
    expected[-1] = 0.0
    assert np.allclose(watts, expected, rtol=2e-15, atol=1e-8)


def test_constant_wm2_cap_tendency_has_analytic_cap_area():
    lat = np.arange(30.0, 90.0 + GRID_DEG, GRID_DEG)
    keep = np.arange(1440)
    field = np.full((len(lat), 1440), 1.75)
    boundaries = np.array([30.0, 60.0, 80.0])
    weights = cap_ring_weights_m2(lat, boundaries, "NH")
    watts = cap_storage_tendency_w(field, keep, weights)
    expected_area = 2.0 * np.pi * R_EARTH_M**2 * (1.0 - np.sin(np.deg2rad(boundaries)))
    assert np.allclose(watts, 1.75 * expected_area, rtol=3e-15)


def test_sh_cap_weights_match_nh_geometric_areas():
    nh_lat = np.arange(30.0, 90.0 + GRID_DEG, GRID_DEG)
    sh_lat = np.arange(-90.0, -50.0 + GRID_DEG, GRID_DEG)
    bounds = np.array([50.0, 60.0, 80.0])
    nh = cap_ring_weights_m2(nh_lat, bounds, "NH").sum(axis=1)
    sh = cap_ring_weights_m2(sh_lat, bounds, "SH").sum(axis=1)
    assert np.allclose(nh, sh, rtol=3e-15)


def test_tolerances_are_predefined_and_separate_from_materiality():
    assert NUMERICAL_ABS_TOLERANCE_PW == 1e-9
    assert PHYSICAL_MATERIALITY_PW == 1e-3
    assert np.isclose(NUMERICAL_ABS_TOLERANCE_PW * PW_W, 1e6, rtol=0, atol=1e-9)


def test_raw_metadata_passes_when_full_reduction_has_run():
    workspace = Path(os.environ.get("AUDIT_WORKSPACE", ROOT / "work" / "raw_reproduction_workspace"))
    metadata = workspace / "independent_era5" / "ERA5_RAW_METADATA.csv"
    if metadata.exists():
        frame = pd.read_csv(metadata)
        assert set(frame.status) == {"PASS"}
        assert set(frame.product_versions) == {"v1.0"}
