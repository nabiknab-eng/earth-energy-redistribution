from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def test_global_context_technical_diagnostics_pass():
    frame = pd.read_csv(ROOT / "outputs/global_energy_context_diagnostics.csv")
    assert len(frame) >= 14
    assert frame.status.eq("PASS").all()


def test_global_context_table_has_real_sh_equator_aht():
    frame = pd.read_csv(ROOT / "outputs/global_energy_context_table.csv")
    assert frame.latitude_deg.tolist() == [-60.0, -70.0, 0.0, 60.0, 70.0]
    assert np.isfinite(frame.actual_aht_climatology_pw).all()
    assert np.isfinite(frame.actual_aht_trend_tw_dec).all()
    assert frame.loc[frame.latitude_deg <= 0, "h_known_plus_sea_ice_climatology_pw"].isna().all()
    assert frame.loc[frame.latitude_deg > 0, "h_known_plus_sea_ice_climatology_pw"].notna().all()


def test_global_transport_extrema_and_cross_equator_are_asymmetric():
    frame = pd.read_csv(ROOT / "outputs/global_energy_context_summary_metrics.csv")
    values = frame.set_index("metric").value
    assert values["CERES raw implied total: maximum southward transport"] < -5
    assert values["CERES raw implied total: maximum northward transport"] > 5
    assert values["CERES raw implied total: cross-equatorial transport"] > 0
    assert values["actual ERA5 atmospheric: cross-equatorial transport"] < 0
    zero = frame[frame.metric.str.startswith("CERES N_TOA zero crossing")].value.to_numpy()
    assert len(zero) == 2 and zero[0] < 0 < zero[1]


def test_requested_global_context_artifacts_exist():
    for name in [
        "global_energy_budget_three_panel.png",
        "climatology_vs_trend_transport.png",
        "global_energy_context_table.csv",
        "GLOBAL_ENERGY_CONTEXT.md",
    ]:
        path = ROOT / "outputs" / name
        assert path.exists() and path.stat().st_size > 0
