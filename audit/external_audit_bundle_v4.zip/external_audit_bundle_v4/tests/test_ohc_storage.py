import numpy as np
import pandas as pd

from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints


def test_monthly_midpoints_follow_real_calendar():
    index = monthly_midpoints("2019-01", 15)
    assert index[0] == pd.Timestamp("2019-01-16 12:00:00")
    assert index[13] == pd.Timestamp("2020-02-15 12:00:00")


def test_block_mean_tendency_recovers_linear_energy_rate():
    index = monthly_midpoints("2005-01", 60)
    seconds = (index - index[0]).total_seconds().to_numpy()
    rate_w = 4.2e14
    energy = 7e22 + rate_w * seconds
    _, tendency = block_mean_tendency(energy, index)
    assert np.allclose(tendency, rate_w, rtol=1e-14)


def test_central_span_tendency_recovers_linear_energy_rate():
    index = monthly_midpoints("2005-01", 60)
    seconds = (index - index[0]).total_seconds().to_numpy()
    rate_w = -1.7e13
    energy = 9e21 + rate_w * seconds
    _, tendency = central_span_tendency(energy, index)
    assert np.allclose(tendency, rate_w, rtol=2e-14)
