import numpy as np
import pytest

from src.energy_budget import (
    EARTH_AREA,
    PW,
    TW,
    area_weighted_global_mean,
    cap_area,
    cap_integral_from_zonal,
    implied_transport,
    implied_transport_from_north,
    source_from_transport,
    latitude_edges,
    validated_hac_standard_error,
    zonal_band_areas,
)


LAT = np.arange(-89.5, 90.0, 1.0)


def test_band_areas_sum_to_sphere():
    assert np.isclose(zonal_band_areas(LAT).sum(), EARTH_AREA, rtol=2e-15)


def test_one_wm2_global_is_0510_pw():
    assert np.isclose(EARTH_AREA / PW, 0.510064, rtol=2e-4)


def test_uniform_source_after_mean_removal_zero_transport():
    edge, h = implied_transport(np.full(LAT.size, 3.0), LAT)
    assert edge[0] == -90 and edge[-1] == 90
    assert np.max(np.abs(h / PW)) < 1e-12


def test_analytic_hemispheric_dipole_sign_and_amplitude():
    src = np.where(LAT < 0, 1.0, -1.0)
    edge, h = implied_transport(src, LAT)
    equator = np.flatnonzero(np.isclose(edge, 0.0))[0]
    # Southern surplus must be transported northward across the equator.
    assert h[equator] > 0
    assert np.isclose(h[equator], 0.5 * EARTH_AREA, rtol=2e-15)
    assert abs(h[-1] / PW) < 1e-12


def test_cap_integral_matches_boundary_transport():
    src = np.sin(np.deg2rad(LAT)) + 0.25 * np.cos(2 * np.deg2rad(LAT))
    src -= area_weighted_global_mean(src, LAT)
    edge, h = implied_transport(src, LAT, remove_global_mean=False)
    i60 = np.flatnonzero(np.isclose(edge, 60.0))[0]
    direct = cap_integral_from_zonal(src, LAT, 60.0)
    # Conservative source: H(60N) equals minus source integrated over north cap.
    assert np.isclose(h[i60], -direct, rtol=1e-14, atol=1e-2)


def test_cap_area_formula_matches_grid():
    areas = zonal_band_areas(LAT)
    assert np.isclose(areas[LAT >= 60.5].sum(), cap_area(60.0), rtol=2e-15)


def test_forward_source_reconstruction_is_exact_finite_volume():
    src = np.sin(np.deg2rad(LAT)) + 0.3 * np.cos(3 * np.deg2rad(LAT))
    src -= area_weighted_global_mean(src, LAT)
    _, h = implied_transport(src, LAT, remove_global_mean=False)
    reconstructed = source_from_transport(h, LAT)
    relative_rms = np.sqrt(np.mean((reconstructed - src) ** 2)) / np.sqrt(np.mean(src**2))
    assert relative_rms < 1e-13


def test_independent_north_and_south_integrations_agree():
    src = np.sin(np.deg2rad(LAT)) + 0.2 * np.cos(4 * np.deg2rad(LAT))
    edge_s, h_s = implied_transport(src, LAT)
    edge_n, h_n = implied_transport_from_north(src, LAT)
    assert np.array_equal(edge_s, edge_n)
    assert np.max(np.abs((h_s - h_n) / PW)) < 1e-12
    assert abs(h_s[0] / PW) < 1e-12
    assert abs(h_s[-1] / PW) < 1e-12


def test_explicit_watt_tw_pw_chain_on_cap():
    watts = cap_area(60.0)
    assert np.isclose(watts / TW / 1000.0, watts / PW, rtol=0, atol=1e-16)


def test_regional_latitude_subset_is_not_silently_extended_to_poles():
    with pytest.raises(ValueError, match="pole-to-pole"):
        latitude_edges(np.arange(50.5, 90.0, 1.0))


def test_materially_negative_hac_variance_raises():
    with pytest.raises(FloatingPointError, match="negative HAC"):
        validated_hac_standard_error(-1e-3, 1.0)
    assert validated_hac_standard_error(-1e-16, 1.0) == 0.0
