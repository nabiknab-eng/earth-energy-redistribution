#!/usr/bin/env python3
"""Reveal author references only after a completed blind raw reproduction."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--blind-results", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    blind = pd.read_csv(args.blind_results)
    if blind.empty or not (blind.status == "SEALED_PENDING_COMPARISON").all():
        raise SystemExit("blind result contract is absent or invalid")
    reference = pd.read_csv(args.reference)
    if reference.quantity.duplicated().any() or blind.quantity.duplicated().any():
        raise SystemExit("duplicate quantity")
    merged = blind.drop(columns=["authors_reference", "absolute_difference", "relative_difference", "status", "probable_cause"]).merge(reference, on="quantity", validate="one_to_one")
    merged["absolute_difference"] = np.abs(merged.reviewer_raw_result - merged.authors_reference)
    denominator = np.abs(merged.authors_reference)
    merged["relative_difference"] = np.where(denominator > 0, merged.absolute_difference / denominator, np.nan)
    merged["status"] = np.where(merged.absolute_difference <= merged.tolerance, "PASS", "FAIL")
    merged["probable_cause"] = np.where(merged.status == "PASS", "within declared numerical tolerance", "review metadata, product revision, preprocessing, units/signs and statistics")
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    merged.to_csv(output / "INDEPENDENT_RAW_REPRODUCTION_REVEALED.csv", index=False)
    failures = merged[merged.status != "PASS"]
    lines = [
        "# Post-blind reference comparison",
        "",
        f"Compared quantities: {len(merged)}",
        f"Within declared numeric tolerance: {len(merged) - len(failures)}",
        f"Outside tolerance: {len(failures)}",
        "",
        "Byte-level archive SHA mismatches are not scientific failures when decoded product identity, metadata, dimensions, units and numerical fields pass.",
        "",
    ]
    if len(failures):
        lines += ["## Differences requiring review", "", failures[["quantity", "reviewer_raw_result", "authors_reference", "absolute_difference", "tolerance"]].to_markdown(index=False), ""]
    else:
        lines += ["All sealed reference quantities were reproduced within tolerance.", ""]
    (output / "POST_BLIND_COMPARISON.md").write_text("\n".join(lines))
    print("\n".join(lines))
    if len(failures):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
