"""Quantify sea-ice storage and bound the remaining missing-storage bias.

PIOMAS gridded thickness supplies spatial fractions for each latitude cap.  Its
monthly official volume time series supplies the exact Pan-Arctic total; this
removes a small discrepancy between the gridded cell-area integral and the
published aggregate.  The correction is a reanalysis sensitivity, not a
directly observed storage term.
"""

from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints
from src.analyze_transport_profile import BOUNDARIES, _state_at
from src.energy_budget import PW, EARTH_AREA, cap_area, ols_hac_trend


ROOT = Path(__file__).resolve().parents[1]
PIOMAS_TOTAL = ROOT / "raw/sea_ice/PIOMAS.monthly.Current.v2.1.csv"
PIOMAS_GRID = ROOT / "raw/sea_ice/piomas_heff"
RHO_ICE = 917.0  # kg m-3
LATENT_HEAT_FUSION = 334_000.0  # J kg-1


def _official_volume() -> pd.DataFrame:
    wide = pd.read_csv(PIOMAS_TOTAL)
    months = {name: number for number, name in enumerate(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}
    long = wide.melt(id_vars="year", var_name="month_name", value_name="volume_1000_km3")
    long["time"] = [pd.Timestamp(int(year), months[name], 15) for year, name in zip(long.year, long.month_name)]
    long = long.sort_values("time")
    use = (long.time.dt.to_period("M") >= "2005-01") & (long.time.dt.to_period("M") <= "2022-12")
    out = long.loc[use, ["time", "volume_1000_km3"]].reset_index(drop=True)
    if len(out) != 216 or (out.volume_1000_km3 < 0).any():
        raise RuntimeError("PIOMAS aggregate series does not cover 2005-2022")
    out["time"] = monthly_midpoints("2005-01", 216)
    return out


def reduce_piomas_caps() -> tuple[pd.DataFrame, pd.DataFrame]:
    official = _official_volume()
    records = []
    total_check = []
    grid_signature = None
    for year in range(2005, 2023):
        path = PIOMAS_GRID / f"heff.H{year}.nc.gz"
        payload = gzip.decompress(path.read_bytes())
        ds = Dataset("piomas.nc", memory=payload)
        heff = np.asarray(ds["heff"][:], dtype=float)
        lat = np.asarray(ds["lat_scaler"][:], dtype=float)
        kmt = np.asarray(ds["kmt"][:], dtype=float)
        cell_area = np.asarray(ds["dxt"][:], dtype=float) * np.asarray(ds["dyt"][:], dtype=float) * 1e6
        signature = (lat.shape, float(np.nanmin(lat)), float(np.nanmax(lat)), float(np.sum(cell_area)))
        if grid_signature is None:
            grid_signature = signature
        elif signature != grid_signature:
            raise RuntimeError("PIOMAS grid changed during analysis period")
        # PIOMAS encodes land as 9999.9 m; kmt>0 is the documented ocean mask.
        valid = (kmt > 0) & np.isfinite(heff[0]) & (heff[0] < 100.0)
        raw_total = np.sum(np.where(valid[None, :, :], heff, 0.0) * cell_area[None, :, :], axis=(1, 2)) / 1e12
        year_official = official[official.time.dt.year == year].volume_1000_km3.to_numpy()
        if len(year_official) != 12:
            raise RuntimeError(f"PIOMAS aggregate year {year} is incomplete")
        scale = year_official / raw_total
        for boundary in BOUNDARIES:
            cap = valid & (lat >= boundary)
            raw_cap = np.sum(np.where(cap[None, :, :], heff, 0.0) * cell_area[None, :, :], axis=(1, 2)) / 1e12
            corrected_cap = raw_cap * scale
            for month, volume, factor in zip(range(1, 13), corrected_cap, scale):
                records.append(
                    {
                        "time": pd.Timestamp(year, month, 15),
                        "boundary_deg_n": boundary,
                        "sea_ice_volume_1000_km3": volume,
                        "grid_to_official_scale": factor,
                    }
                )
        total_check.extend(raw_total * scale - year_official)
        ds.close()

    monthly = pd.DataFrame(records).sort_values(["boundary_deg_n", "time"]).reset_index(drop=True)
    midpoint_map = dict(zip(pd.period_range("2005-01", "2022-12", freq="M").astype(str), monthly_midpoints("2005-01", 216)))
    monthly["time"] = pd.DatetimeIndex(monthly.time).to_period("M").astype(str).map(midpoint_map)
    # State energy relative to liquid water at 0 C; melting (volume loss) is
    # positive energy storage because this state becomes less negative.
    monthly["sea_ice_latent_energy_j"] = -monthly.sea_ice_volume_1000_km3 * 1e12 * RHO_ICE * LATENT_HEAT_FUSION
    monthly.to_csv(ROOT / "tables/sea_ice_cap_monthly_energy.csv", index=False)
    monthly.to_csv(ROOT / "outputs/sea_ice_cap_monthly_energy.csv", index=False)

    diagnostics = pd.DataFrame(
        [
            {"diagnostic": "PIOMAS years", "value": 18, "unit": "years", "status": "PASS"},
            {"diagnostic": "gridded fractions rescaled to official total max residual", "value": float(np.max(np.abs(total_check))), "unit": "1000 km3", "status": "PASS" if np.max(np.abs(total_check)) < 1e-12 else "FAIL"},
            # Older annual grids and the continually reprocessed official
            # aggregate are not bit-identical.  Only the gridded spatial
            # fraction is used; the total is anchored to the official series.
            {"diagnostic": "grid-to-official scale range", "value": f"{monthly.grid_to_official_scale.min():.6f}--{monthly.grid_to_official_scale.max():.6f}", "unit": "factor", "status": "PASS" if ((monthly.grid_to_official_scale > 0.95) & (monthly.grid_to_official_scale < 1.25)).all() else "FAIL"},
        ]
    )
    return monthly, diagnostics


def _trend_row(boundary: float, metric: str, values_pw: np.ndarray, index: pd.DatetimeIndex, method: str) -> dict:
    trend = ols_hac_trend(values_pw, index, maxlags=24)
    half = (trend.ci_high - trend.ci_low) * 500.0
    return {
        "boundary_deg_n": boundary,
        "method": method,
        "metric": metric,
        "start": str(index[0].date()),
        "end": str(index[-1].date()),
        "n_months": len(index),
        "mean_pw": float(np.mean(values_pw)),
        "trend_tw_dec": trend.slope_per_decade * 1000.0,
        "trend_ci_low_tw_dec": trend.ci_low * 1000.0,
        "trend_ci_high_tw_dec": trend.ci_high * 1000.0,
        "trend_wm2_cap_dec": trend.slope_per_decade * PW / cap_area(boundary),
        "trend_ci_low_wm2_cap_dec": trend.ci_low * PW / cap_area(boundary),
        "trend_ci_high_wm2_cap_dec": trend.ci_high * PW / cap_area(boundary),
        "minimum_detectable_trend_tw_dec_95": half,
        "signal_to_ci_halfwidth": abs(trend.slope_per_decade * 1000.0) / half if half else np.nan,
        "ci_excludes_zero": bool(trend.ci_low > 0 or trend.ci_high < 0),
        "uncertainty": "OLS-HAC(24), temporal only; PIOMAS model uncertainty separate",
    }


def filter_and_merge(monthly: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    baseline = pd.read_csv(ROOT / "outputs/transport_profile_block_timeseries.csv", parse_dates=["time"])
    summary_rows = []
    sea_frames = []
    for boundary in BOUNDARIES:
        b = monthly[monthly.boundary_deg_n == boundary].sort_values("time")
        index = pd.DatetimeIndex(b.time)
        time, storage_w = block_mean_tendency(b.sea_ice_latent_energy_j.to_numpy(), index)
        sea = pd.DataFrame({"time": time, "boundary_deg_n": boundary, "sea_ice_storage_pw": storage_w / PW})
        sea_frames.append(sea)
        summary_rows.append(_trend_row(boundary, "sea_ice_storage", storage_w / PW, time, "block_12m_means"))
        ctime, central_w = central_span_tendency(b.sea_ice_latent_energy_j.to_numpy(), index)
        summary_rows.append(_trend_row(boundary, "sea_ice_storage", central_w / PW, ctime, "central_12m_endpoints"))
    sea = pd.concat(sea_frames, ignore_index=True)
    enhanced = baseline.merge(sea, on=["time", "boundary_deg_n"], validate="one_to_one")
    enhanced["h_known_plus_sea_ice_pw"] = enhanced.h_known_pw + enhanced.sea_ice_storage_pw
    enhanced["non_atmospheric_residual_plus_sea_ice_pw"] = enhanced.h_known_plus_sea_ice_pw - enhanced.actual_aht_pw
    enhanced["closure_residual_plus_sea_ice_pw"] = enhanced.ntoa_cap_pw - enhanced.known_storage_pw - enhanced.sea_ice_storage_pw + enhanced.h_known_plus_sea_ice_pw
    for boundary in BOUNDARIES:
        b = enhanced[enhanced.boundary_deg_n == boundary]
        index = pd.DatetimeIndex(b.time)
        for metric, column in [
            ("h_known_plus_sea_ice", "h_known_plus_sea_ice_pw"),
            ("non_atmospheric_residual_plus_sea_ice", "non_atmospheric_residual_plus_sea_ice_pw"),
            ("closure_residual_plus_sea_ice", "closure_residual_plus_sea_ice_pw"),
        ]:
            summary_rows.append(_trend_row(boundary, metric, b[column].to_numpy(), index, "block_12m_means"))
    summary = pd.DataFrame(summary_rows)
    enhanced.to_csv(ROOT / "tables/transport_profile_with_sea_ice_timeseries.csv", index=False)
    enhanced.to_csv(ROOT / "outputs/transport_profile_with_sea_ice_timeseries.csv", index=False)
    summary.to_csv(ROOT / "tables/sea_ice_storage_and_sensitivity_profile.csv", index=False)
    summary.to_csv(ROOT / "outputs/sea_ice_storage_and_sensitivity_profile.csv", index=False)
    return enhanced, summary, sea


def structural_uncertainty(summary: pd.DataFrame) -> pd.DataFrame:
    base = pd.read_csv(ROOT / "outputs/transport_latitude_profile.csv")
    base = base[base.method == "block_12m_means"]
    coverage = pd.read_csv(ROOT / "outputs/ohc_cap_profile_coverage.csv")
    ocean = base[base.metric == "ocean_storage_0_2000"].set_index("boundary_deg_n")
    central = pd.read_csv(ROOT / "outputs/transport_latitude_profile.csv")
    central = central[(central.method == "central_12m_endpoints") & (central.metric == "ocean_storage_0_2000")].set_index("boundary_deg_n")
    block = ocean
    ice = summary[(summary.method == "block_12m_means") & (summary.metric == "sea_ice_storage")].set_index("boundary_deg_n")
    corrected = summary[(summary.method == "block_12m_means") & (summary.metric == "h_known_plus_sea_ice")].set_index("boundary_deg_n")
    records = []
    global_land_area = EARTH_AREA - 350_406_524_699_414.0
    record_years = 17.0
    # Current energy-inventory diagnostics give 0.014 W m-2 Earth-area
    # uncertainty for land storage rate.  Convert an end-to-end drift of twice
    # this rate over the record to a conservative trend bound, then allocate by
    # cap land area with a factor of two for Arctic amplification/heterogeneity.
    land_rate_uncertainty_tw_global = 0.014 * EARTH_AREA / 1e12
    for boundary in BOUNDARIES:
        capmeta = coverage[coverage.boundary_deg_n == boundary].iloc[0]
        land_area = max(capmeta.total_cap_area_m2 - capmeta.sampled_ocean_area_m2, 0.0)
        land_bound = 2.0 * (land_area / global_land_area) * (2.0 * land_rate_uncertainty_tw_global / record_years * 10.0)
        ohc_mapping = max(
            abs(float(block.loc[boundary].trend_tw_dec - central.loc[boundary].trend_tw_dec)),
            0.20 * float(block.loc[boundary].minimum_detectable_trend_tw_dec_95),
        )
        deep = 0.06 * float(block.loc[boundary].minimum_detectable_trend_tw_dec_95)
        # 0.012 W m-2 Earth-area is the available inter-product uncertainty
        # scale for sea-ice storage rate.  Letting that error drift from -1 to
        # +1 times the scale over 17 years gives a deliberately conservative
        # (non-probabilistic) trend bound.
        sea_model = 0.012 * EARTH_AREA / 1e12 * 2.0 / record_years * 10.0
        glacier = 3.0 if boundary <= 75 else 1.5
        components = [
            ("sea_ice_PIOMAS_model", float(ice.loc[boundary].trend_tw_dec), sea_model, "included in sensitivity; cap-resolved gridded PIOMAS v2.1"),
            ("ocean_below_2000m", 0.0, deep, "not included; 6% sensitivity of 0-2000m temporal detectability"),
            ("land_heat", 0.0, land_bound, "not included; cap-area-scaled conservative drift bound"),
            ("glacier_and_ice_sheet_enthalpy", 0.0, glacier, "not included; conservative latent/sensible-enthalpy scenario"),
            ("atmospheric_kinetic_potential", 0.0, 0.0, "included in ERA5 vertical integral of total energy"),
            ("OHC_mapping_sampling", 0.0, ohc_mapping, "not a missing grid area; proxy from NH product SE ratio and filter sensitivity"),
        ]
        for name, best, bound, note in components:
            records.append(
                {
                    "boundary_deg_n": boundary,
                    "component": name,
                    "best_estimate_trend_tw_dec": best,
                    "structural_bound_plus_minus_tw_dec": bound,
                    "can_flip_corrected_h_sign_by_itself": bool(bound >= abs(float(corrected.loc[boundary].trend_tw_dec))),
                    "treatment": note,
                }
            )
    table = pd.DataFrame(records)
    table.to_csv(ROOT / "outputs/missing_storage_structural_bounds.csv", index=False)
    return table


def component_budget(enhanced_summary: pd.DataFrame) -> pd.DataFrame:
    base = pd.read_csv(ROOT / "outputs/transport_latitude_profile.csv")
    base = base[base.method == "block_12m_means"]
    mappings = [
        ("N_cap", base, "ntoa_cap"),
        ("ocean_storage_0_2000m", base, "ocean_storage_0_2000"),
        ("atmospheric_storage_total_energy", base, "atmospheric_storage_total_energy"),
        ("sea_ice_storage_PIOMAS", enhanced_summary, "sea_ice_storage"),
        ("H_known", base, "h_known"),
        ("H_known_plus_sea_ice", enhanced_summary, "h_known_plus_sea_ice"),
        ("actual_AHT", base, "actual_aht"),
        ("non_atmospheric_residual", base, "non_atmospheric_residual"),
        ("non_atmospheric_residual_plus_sea_ice", enhanced_summary, "non_atmospheric_residual_plus_sea_ice"),
        ("closure_residual_plus_sea_ice", enhanced_summary, "closure_residual_plus_sea_ice"),
    ]
    rows = []
    for boundary in (60.0, 65.0, 70.0):
        for label, source, metric in mappings:
            q = source[(source.boundary_deg_n == boundary) & (source.metric == metric)]
            if "method" in q and len(q[q.method == "block_12m_means"]):
                q = q[q.method == "block_12m_means"]
            row = q.iloc[0]
            rows.append(
                {
                    "boundary_deg_n": boundary,
                    "component": label,
                    "mean_pw": row.mean_pw,
                    "mean_tw": row.mean_pw * 1000.0,
                    "mean_wm2_cap": row.mean_pw * PW / cap_area(boundary),
                    "trend_pw_dec": row.trend_tw_dec / 1000.0,
                    "trend_tw_dec": row.trend_tw_dec,
                    "trend_wm2_cap_dec": row.trend_wm2_cap_dec,
                    "trend_ci_low_tw_dec": row.trend_ci_low_tw_dec,
                    "trend_ci_high_tw_dec": row.trend_ci_high_tw_dec,
                    "direct_or_residual": "direct/reanalysis" if label in {"N_cap", "ocean_storage_0_2000m", "atmospheric_storage_total_energy", "sea_ice_storage_PIOMAS", "actual_AHT"} else "derived/residual",
                }
            )
    table = pd.DataFrame(rows)
    table.to_csv(ROOT / "outputs/transport_closure_components_60_65_70.csv", index=False)
    return table


def _update_plots(enhanced: pd.DataFrame, enhanced_summary: pd.DataFrame) -> None:
    base = pd.read_csv(ROOT / "outputs/transport_latitude_profile.csv")
    base = base[base.method == "block_12m_means"]
    ext = enhanced_summary[enhanced_summary.method == "block_12m_means"]
    lat = BOUNDARIES
    colors = {"h": "#0b6e99", "a": "#d95f02", "r": "#1b9e77", "raw": "#777777", "ice": "#6a4c93"}

    def row(source, metric):
        return source[source.metric == metric].set_index("boundary_deg_n").loc[lat]

    # 1
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    for source, metric, label, color, style in [
        (ext, "h_known_plus_sea_ice", "H_known + PIOMAS sea ice", colors["h"], "-"),
        (base, "h_known", "H_known (without sea ice)", colors["h"], ":"),
        (base, "actual_aht", "actual ERA5 AHT", colors["a"], "-"),
        (ext, "non_atmospheric_residual_plus_sea_ice", "non-atmospheric residual + sea ice", colors["r"], "-"),
    ]:
        q = row(source, metric); ax.plot(lat, q.mean_pw, color=color, ls=style, lw=1.7, label=label)
    ax.axhline(0, color="0.6", lw=0.7); ax.set(xlabel="Northern cap boundary (°N)", ylabel="Mean northward transport (PW)", title="Climatological known-budget transport partition")
    ax.legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_01_climatology_vs_latitude.png", dpi=180); plt.close(fig)

    # 2
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    for source, metric, label, color, style in [(base,"raw_implied","raw implied",colors["raw"],"-"),(base,"h_known","H_known",colors["h"],":"),(ext,"h_known_plus_sea_ice","H_known + PIOMAS sea ice",colors["h"],"-")]:
        q=row(source,metric); ax.plot(lat,q.trend_tw_dec,color=color,ls=style,lw=1.6,label=label); ax.fill_between(lat,q.trend_ci_low_tw_dec,q.trend_ci_high_tw_dec,color=color,alpha=0.10)
    ax.axhline(0,color="black",lw=.8);ax.set(xlabel="Northern cap boundary (°N)",ylabel="Trend (TW decade$^{-1}$)",title="Raw-implied and storage-corrected sensitivity trends")
    ax.legend(frameon=False);fig.tight_layout();fig.savefig(ROOT / "outputs/transport_02_total_hknown_trend_vs_latitude.png",dpi=180);plt.close(fig)

    # 4 residual
    fig,ax=plt.subplots(figsize=(8.5,5.2));q=row(ext,"non_atmospheric_residual_plus_sea_ice")
    ax.plot(lat,q.trend_tw_dec,color=colors["r"],lw=1.8);ax.fill_between(lat,q.trend_ci_low_tw_dec,q.trend_ci_high_tw_dec,color=colors["r"],alpha=.2);ax.axhline(0,color="black",lw=.8)
    ax.set(xlabel="Northern cap boundary (°N)",ylabel="Trend (TW decade$^{-1}$)",title="Non-atmospheric residual including PIOMAS sea-ice storage\n95% temporal HAC envelope; remaining storage structural")
    fig.tight_layout();fig.savefig(ROOT / "outputs/transport_04_non_atmospheric_residual_trend_vs_latitude.png",dpi=180);plt.close(fig)

    # 5 uncertainty envelope
    fig,ax=plt.subplots(figsize=(8.5,5.2))
    for source,metric,label,color in [(ext,"h_known_plus_sea_ice","H_known + sea ice",colors["h"]),(base,"actual_aht","actual AHT",colors["a"]),(ext,"non_atmospheric_residual_plus_sea_ice","residual + sea ice",colors["r"])]:
        q=row(source,metric);ax.plot(lat,q.minimum_detectable_trend_tw_dec_95,color=color,lw=1.6,label=label)
    ax.set(xlabel="Northern cap boundary (°N)",ylabel="95% temporal CI half-width (TW decade$^{-1}$)",title="Temporal uncertainty envelope by latitude")
    ax.legend(frameon=False);fig.tight_layout();fig.savefig(ROOT / "outputs/transport_05_uncertainty_envelope_vs_latitude.png",dpi=180);plt.close(fig)

    # 6 component trends
    labels=["N_TOA","OHC 0–2000","atm storage","sea ice","H+ice","AHT","residual+ice"]
    metrics=[(base,"ntoa_cap"),(base,"ocean_storage_0_2000"),(base,"atmospheric_storage_total_energy"),(ext,"sea_ice_storage"),(ext,"h_known_plus_sea_ice"),(base,"actual_aht"),(ext,"non_atmospheric_residual_plus_sea_ice")]
    fig,axes=plt.subplots(1,3,figsize=(14,5.4),sharey=True)
    for ax,boundary in zip(axes,(60.,65.,70.)):
        vals=[];los=[];his=[]
        for source,metric in metrics:
            q=source[(source.boundary_deg_n==boundary)&(source.metric==metric)]
            if "method" in q:q=q[q.method=="block_12m_means"]
            z=q.iloc[0];vals.append(z.trend_tw_dec);los.append(z.trend_ci_low_tw_dec);his.append(z.trend_ci_high_tw_dec)
        pos=np.arange(len(vals));ax.bar(pos,vals,color=["#c17c27","#287271","#884ea0",colors["ice"],colors["h"],colors["a"],colors["r"]]);ax.errorbar(pos,vals,yerr=np.vstack([np.array(vals)-los,np.array(his)-vals]),fmt="none",ecolor="black",capsize=2);ax.axhline(0,color="black",lw=.7);ax.set_title(f"{int(boundary)}°N");ax.set_xticks(pos,labels,rotation=55,ha="right")
    axes[0].set_ylabel("Trend (TW decade$^{-1}$)");fig.suptitle("Observed/reanalysis component budgets; other storage remains structural");fig.tight_layout();fig.savefig(ROOT / "outputs/transport_06_component_budget_60_65_70.png",dpi=180);plt.close(fig)

    # 7 numerical closure with sea ice
    q=row(ext,"closure_residual_plus_sea_ice");fig,ax=plt.subplots(figsize=(8.5,4.8));ax.plot(lat,q.trend_tw_dec,color=colors["ice"],lw=1.6);ax.axhline(0,color="black",lw=.8);ax.set(xlabel="Northern cap boundary (°N)",ylabel="Residual trend (TW decade$^{-1}$)",title="Algebraic closure residual after PIOMAS sea-ice inclusion\n(remaining storage uncertainty is not this numerical residual)");fig.tight_layout();fig.savefig(ROOT / "outputs/transport_07_closure_residual_vs_latitude.png",dpi=180);plt.close(fig)

    # 8 MDE vs signal
    fig,ax=plt.subplots(figsize=(8.5,5.2))
    for source,metric,label,color in [(ext,"h_known_plus_sea_ice","H_known + sea ice",colors["h"]),(base,"actual_aht","actual AHT",colors["a"]),(ext,"non_atmospheric_residual_plus_sea_ice","residual + sea ice",colors["r"])]:
        q=row(source,metric);ax.plot(lat,q.minimum_detectable_trend_tw_dec_95,color=color,lw=1.7,label=label);ax.plot(lat,np.abs(q.trend_tw_dec),color=color,lw=.9,ls="--",alpha=.7)
    ax.set(xlabel="Northern cap boundary (°N)",ylabel="Magnitude (TW decade$^{-1}$)",title="Minimum detectable trend (solid) and observed magnitude (dashed)");ax.legend(frameon=False);fig.tight_layout();fig.savefig(ROOT / "outputs/transport_08_minimum_detectable_trend_vs_latitude.png",dpi=180);plt.close(fig)

    # 9 exact annual budgets plus exact annual sea-ice state changes.
    annual=pd.read_csv(ROOT / "outputs/transport_annual_budget_60_65_70.csv",parse_dates=["time"])
    monthly=pd.read_csv(ROOT / "outputs/sea_ice_cap_monthly_energy.csv",parse_dates=["time"])
    ice_rows=[]
    for boundary in (60.,65.,70.):
        b=monthly[monthly.boundary_deg_n==boundary].sort_values("time");idx=pd.DatetimeIndex(b.time);state=b.sea_ice_latent_energy_j.to_numpy()
        for year in range(2006,2022):
            start,end=pd.Timestamp(year,1,1),pd.Timestamp(year+1,1,1);rate=(_state_at(state,idx,end)-_state_at(state,idx,start))/(end-start).total_seconds()/PW;ice_rows.append({"boundary_deg_n":boundary,"year":year,"sea_ice_storage_pw":rate})
    annual=annual.merge(pd.DataFrame(ice_rows),on=["boundary_deg_n","year"],validate="one_to_one");annual["h_known_plus_sea_ice_pw"]=annual.h_known_pw+annual.sea_ice_storage_pw;annual["residual_plus_sea_ice_pw"]=annual.h_known_plus_sea_ice_pw-annual.actual_aht_pw;annual.to_csv(ROOT/"outputs/transport_annual_budget_with_sea_ice_60_65_70.csv",index=False)
    fig,axes=plt.subplots(3,1,figsize=(10.2,8.8),sharex=True)
    for ax,boundary in zip(axes,(60.,65.,70.)):
        q=annual[annual.boundary_deg_n==boundary];ax.plot(q.year,q.h_known_plus_sea_ice_pw,color=colors["h"],marker="o",ms=3,label="H_known + sea ice");ax.plot(q.year,q.actual_aht_pw,color=colors["a"],marker="o",ms=3,label="actual AHT");ax.plot(q.year,q.residual_plus_sea_ice_pw,color=colors["r"],marker="o",ms=3,label="residual + sea ice");ax.set(ylabel="PW",title=f"{int(boundary)}°N")
    axes[0].legend(frameon=False,ncol=3);axes[-1].set_xlabel("Calendar year");fig.suptitle("Annual transport partition including PIOMAS sea-ice storage (2006–2021)");fig.tight_layout();fig.savefig(ROOT/"outputs/transport_09_annual_timeseries_60_65_70.png",dpi=180);plt.close(fig)


def _write_provenance() -> None:
    files = [PIOMAS_TOTAL] + sorted(PIOMAS_GRID.glob("heff.H*.nc.gz"))
    records=[]
    for path in files:
        digest=hashlib.sha256(path.read_bytes()).hexdigest();records.append({"path":str(path.relative_to(ROOT)),"bytes":path.stat().st_size,"sha256":digest})
    (ROOT/"provenance/piomas_inputs.json").write_text(json.dumps(records,indent=2)+"\n")


def main() -> None:
    monthly, diagnostics = reduce_piomas_caps()
    enhanced, summary, _ = filter_and_merge(monthly)
    structural = structural_uncertainty(summary)
    component_budget(summary)
    _update_plots(enhanced, summary)
    max_closure = float(np.max(np.abs(enhanced.closure_residual_plus_sea_ice_pw)))
    diagnostics = pd.concat(
        [diagnostics, pd.DataFrame([{"diagnostic":"known budget plus sea-ice algebra max error","value":max_closure,"unit":"PW","status":"PASS" if max_closure<1e-13 else "FAIL"}])],
        ignore_index=True,
    )
    diagnostics.to_csv(ROOT/"outputs/sea_ice_storage_diagnostics.csv",index=False)
    if (diagnostics.status!="PASS").any():
        raise RuntimeError("sea-ice storage diagnostics failed")
    _write_provenance()
    key=summary[(summary.method=="block_12m_means")&summary.boundary_deg_n.isin([60,65,70])&summary.metric.isin(["sea_ice_storage","h_known_plus_sea_ice","non_atmospheric_residual_plus_sea_ice"])]
    print(diagnostics.to_string(index=False))
    print("\nSea-ice sensitivity:\n"+key[["boundary_deg_n","metric","mean_pw","trend_tw_dec","trend_ci_low_tw_dec","trend_ci_high_tw_dec","minimum_detectable_trend_tw_dec_95"]].to_string(index=False))
    print("\nStructural bound sums at 60/65/70:\n"+structural[structural.boundary_deg_n.isin([60,65,70])].groupby("boundary_deg_n").structural_bound_plus_minus_tw_dec.sum().to_string())


if __name__ == "__main__":
    main()
