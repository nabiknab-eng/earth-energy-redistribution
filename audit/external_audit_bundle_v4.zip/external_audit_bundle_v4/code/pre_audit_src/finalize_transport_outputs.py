"""Assemble compact machine-readable transport conclusions."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from src.energy_budget import PW, cap_area


ROOT = Path(__file__).resolve().parents[1]
BOUNDARIES = np.arange(30.0, 86.0)


def metric(frame: pd.DataFrame, name: str) -> pd.DataFrame:
    out = frame[frame.metric == name].set_index("boundary_deg_n").loc[BOUNDARIES].copy()
    return out


def profile_table() -> pd.DataFrame:
    base = pd.read_csv(ROOT / "outputs/transport_latitude_profile.csv")
    base = base[base.method == "block_12m_means"]
    extra = pd.read_csv(ROOT / "outputs/sea_ice_storage_and_sensitivity_profile.csv")
    extra = extra[extra.method == "block_12m_means"]
    structural = pd.read_csv(ROOT / "outputs/missing_storage_structural_bounds.csv")
    structural_sum = structural.groupby("boundary_deg_n").structural_bound_plus_minus_tw_dec.sum()

    out = pd.DataFrame({"boundary_deg_n": BOUNDARIES})
    definitions = [
        (base, "raw_implied", "raw_implied"),
        (base, "h_known", "h_known"),
        (extra, "h_known_plus_sea_ice", "h_known_plus_sea_ice"),
        (base, "actual_aht", "actual_aht"),
        (base, "non_atmospheric_residual", "non_atmospheric_residual"),
        (extra, "non_atmospheric_residual_plus_sea_ice", "non_atmospheric_residual_plus_sea_ice"),
        (extra, "sea_ice_storage", "sea_ice_storage"),
    ]
    for source, name, prefix in definitions:
        q = metric(source, name)
        out[f"{prefix}_mean_pw"] = q.mean_pw.to_numpy()
        out[f"{prefix}_trend_tw_dec"] = q.trend_tw_dec.to_numpy()
        out[f"{prefix}_ci_low_tw_dec"] = q.trend_ci_low_tw_dec.to_numpy()
        out[f"{prefix}_ci_high_tw_dec"] = q.trend_ci_high_tw_dec.to_numpy()
        out[f"{prefix}_mde95_tw_dec"] = q.minimum_detectable_trend_tw_dec_95.to_numpy()
        out[f"{prefix}_ci_excludes_zero"] = q.ci_excludes_zero.to_numpy()
    out["remaining_structural_bound_sum_tw_dec"] = out.boundary_deg_n.map(structural_sum)
    out["h_known_plus_sea_ice_conservative_safe_detection_tw_dec"] = (
        out.h_known_plus_sea_ice_mde95_tw_dec + out.remaining_structural_bound_sum_tw_dec
    )
    out["h_known_plus_sea_ice_signal_to_safe_threshold"] = (
        np.abs(out.h_known_plus_sea_ice_trend_tw_dec)
        / out.h_known_plus_sea_ice_conservative_safe_detection_tw_dec
    )
    out.to_csv(ROOT / "outputs/transport_profile_best_estimates.csv", index=False)
    return out


def detectability(profile: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, row in profile.iterrows():
        boundary = row.boundary_deg_n
        structural = row.remaining_structural_bound_sum_tw_dec
        for metric_name, prefix, structural_applies in [
            ("H_known_plus_sea_ice", "h_known_plus_sea_ice", True),
            ("actual_AHT", "actual_aht", False),
            ("non_atmospheric_residual_plus_sea_ice", "non_atmospheric_residual_plus_sea_ice", True),
        ]:
            estimate = row[f"{prefix}_trend_tw_dec"]
            mde = row[f"{prefix}_mde95_tw_dec"]
            bound = structural if structural_applies else 0.0
            safe = mde + bound
            rows.append(
                {
                    "boundary_deg_n": boundary,
                    "metric": metric_name,
                    "best_estimate_tw_dec": estimate,
                    "ci_low_tw_dec": row[f"{prefix}_ci_low_tw_dec"],
                    "ci_high_tw_dec": row[f"{prefix}_ci_high_tw_dec"],
                    "minimum_detectable_trend_temporal_95_tw_dec": mde,
                    "nonprobabilistic_structural_bound_tw_dec": bound,
                    "conservative_safe_detection_threshold_tw_dec": safe,
                    "signal_to_temporal_mde": abs(estimate) / mde if mde else np.nan,
                    "signal_to_safe_threshold": abs(estimate) / safe if safe else np.nan,
                    "safe_detection": bool(abs(estimate) > safe and row[f"{prefix}_ci_excludes_zero"]),
                }
            )
    table = pd.DataFrame(rows)
    table.to_csv(ROOT / "outputs/transport_detectability.csv", index=False)
    return table


def closure_table() -> pd.DataFrame:
    components = pd.read_csv(ROOT / "outputs/transport_closure_components_60_65_70.csv")
    structural = pd.read_csv(ROOT / "outputs/missing_storage_structural_bounds.csv")
    extra_rows = []
    for boundary in (60.0, 65.0, 70.0):
        q = structural[structural.boundary_deg_n == boundary]
        remaining = q[q.component != "sea_ice_PIOMAS_model"].structural_bound_plus_minus_tw_dec.sum()
        total = q.structural_bound_plus_minus_tw_dec.sum()
        for component, bound, note in [
            ("remaining_missing_storage_bias", remaining, "deep ocean + land + glacier/ice-sheet + OHC mapping; scenario bound, not CI"),
            ("total_structural_bound_including_PIOMAS_model", total, "linear worst-case sum; scenario bound, not CI"),
        ]:
            extra_rows.append(
                {
                    "boundary_deg_n": boundary,
                    "component": component,
                    "mean_pw": np.nan,
                    "mean_tw": np.nan,
                    "mean_wm2_cap": np.nan,
                    "trend_pw_dec": 0.0,
                    "trend_tw_dec": 0.0,
                    "trend_wm2_cap_dec": 0.0,
                    "trend_ci_low_tw_dec": np.nan,
                    "trend_ci_high_tw_dec": np.nan,
                    "direct_or_residual": note,
                    "structural_bound_plus_minus_tw_dec": bound,
                    "structural_bound_plus_minus_wm2_cap_dec": bound * 1e12 / cap_area(boundary),
                }
            )
    components["structural_bound_plus_minus_tw_dec"] = np.nan
    components["structural_bound_plus_minus_wm2_cap_dec"] = np.nan
    table = pd.concat([components, pd.DataFrame(extra_rows)], ignore_index=True)
    table.to_csv(ROOT / "outputs/transport_closure_summary.csv", index=False)
    return table


def technical_validation() -> pd.DataFrame:
    files = [
        ROOT / "outputs/transport_profile_input_diagnostics.csv",
        ROOT / "outputs/transport_profile_diagnostics.csv",
        ROOT / "outputs/sea_ice_storage_diagnostics.csv",
    ]
    tables = []
    for path in files:
        frame = pd.read_csv(path)
        frame.insert(0, "source", path.name)
        tables.append(frame)
    table = pd.concat(tables, ignore_index=True)
    table.to_csv(ROOT / "outputs/transport_technical_validation.csv", index=False)
    if (table.status != "PASS").any():
        raise RuntimeError("transport technical validation contains a failure")
    return table


def main() -> None:
    profile = profile_table()
    detected = detectability(profile)
    closure_table()
    validation = technical_validation()
    print("Technical checks:", len(validation), "all PASS")
    print(
        detected[
            detected.boundary_deg_n.isin([60, 65, 70])
        ].to_string(index=False)
    )


if __name__ == "__main__":
    main()
