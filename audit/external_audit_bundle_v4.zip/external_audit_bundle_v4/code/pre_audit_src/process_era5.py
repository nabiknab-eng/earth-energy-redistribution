"""Convert audited CDS ZIP chunks to compact transport/storage tables."""

from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset, num2date

from src.energy_budget import PW, R_EARTH, cap_area, ols_hac_trend

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw/era5"


def unique_longitudes(lon: np.ndarray) -> np.ndarray:
    """Indices of first occurrence; CDS area 0..360 duplicates longitude 0."""
    lon = np.asarray(np.ma.filled(lon, np.nan), dtype=float)
    _, idx = np.unique(np.mod(lon, 360.0), return_index=True)
    return np.sort(idx)


def read_nc(member: bytes) -> Dataset:
    return Dataset("inmemory.nc", memory=member)


def zip_members(pattern: str):
    for path in sorted(RAW.glob(pattern)):
        with zipfile.ZipFile(path) as zf:
            for name in sorted(zf.namelist()):
                yield path, name, zf.read(name)


def timestamp(ds: Dataset) -> pd.Timestamp:
    tv = ds["time"]
    d = num2date(tv[0], tv.units, getattr(tv, "calendar", "standard"))
    return pd.Timestamp(d.year, d.month, 15)


def integrate_parallel(field_w_per_m: np.ndarray, lat_deg: float, lon: np.ndarray) -> float:
    lon = np.asarray(np.ma.filled(lon, np.nan), dtype=float)
    keep = unique_longitudes(lon)
    unique = np.mod(lon[keep], 360.0)
    order = np.argsort(unique)
    unique = unique[order]
    values = np.asarray(field_w_per_m)[keep][order]
    dlon = np.deg2rad(float(np.median(np.diff(unique))))
    return float(np.sum(values) * R_EARTH * np.cos(np.deg2rad(lat_deg)) * dlon)


def integrate_cap(field_wm2: np.ndarray, lat: np.ndarray, lon: np.ndarray, boundary: float) -> float:
    """Area integrate a regular lat/lon node field, clipping at cap boundary."""
    keep_lon = unique_longitudes(lon)
    lon_count = len(keep_lon)
    total = 0.0
    for j, phi in enumerate(lat):
        lower = max(boundary, float(phi) - 0.125)
        upper = min(90.0, float(phi) + 0.125)
        if upper <= lower:
            continue
        row_area = 2.0 * np.pi * R_EARTH**2 * (np.sin(np.deg2rad(upper)) - np.sin(np.deg2rad(lower)))
        total += float(np.sum(field_wm2[j, keep_lon])) * row_area / lon_count
    return total


def process_boundaries_and_tendency() -> pd.DataFrame:
    out: dict[pd.Timestamp, dict] = {}
    for boundary in (60, 65, 70):
        for _, _, member in zip_members(f"aht{boundary}_*.zip"):
            ds = read_nc(member)
            t = timestamp(ds)
            lat = ds["latitude"][:]
            i = int(np.argmin(np.abs(lat - boundary)))
            h = integrate_parallel(ds["tefln"][0, i, :], float(lat[i]), ds["longitude"][:])
            out.setdefault(t, {"time": t})[f"aht{boundary}_pw"] = h / PW
            ds.close()
    for _, _, member in zip_members("aetend60cap_*.zip"):
        ds = read_nc(member)
        t = timestamp(ds)
        variable = next(v for v in ds.variables if v not in {"time", "latitude", "longitude"})
        field = ds[variable][0]
        for boundary in (60, 65, 70):
            tendency_w = integrate_cap(field, ds["latitude"][:], ds["longitude"][:], boundary)
            out.setdefault(t, {"time": t})[f"ae_tendency{boundary}_pw"] = tendency_w / PW
            out[t][f"ae_tendency{boundary}_wm2"] = tendency_w / cap_area(boundary)
        ds.close()
    frame = pd.DataFrame(out.values()).sort_values("time")
    frame.to_csv(ROOT / "tables/era5_boundary_monthly.csv", index=False)
    return frame


def process_validation_profile() -> tuple[pd.DataFrame, float, float]:
    sums = None
    count = 0
    lats = None
    for _, _, member in zip_members("aht_profile_35-45N_*.zip"):
        ds = read_nc(member)
        lat = np.asarray(ds["latitude"][:], dtype=float)
        lon = ds["longitude"][:]
        profile = np.asarray([integrate_parallel(ds["tefln"][0, j, :], phi, lon) / PW for j, phi in enumerate(lat)])
        if sums is None:
            sums, lats = np.zeros_like(profile), lat
        if not np.allclose(lat, lats):
            raise RuntimeError("inconsistent latitude grid in ERA5 profile chunks")
        sums += profile
        count += 1
        ds.close()
    if count == 0:
        raise FileNotFoundError("ERA5 validation profile chunks are not present")
    mean = sums / count
    table = pd.DataFrame({"latitude": lats, "aht_climatology_pw": mean}).sort_values("latitude")
    table.to_csv(ROOT / "tables/era5_aht_climatology_1985-2018.csv", index=False)
    i = int(np.argmax(mean))
    return table, float(mean[i]), float(lats[i])


def main() -> None:
    frame = process_boundaries_and_tendency()
    print(frame.head().to_string(index=False))
    print(frame.tail().to_string(index=False))
    trends = {}
    for boundary in (60, 65, 70):
        x = frame.dropna(subset=[f"aht{boundary}_pw"])
        use = (x.time >= "2005-01-01") & (x.time <= "2022-12-31")
        tr = ols_hac_trend(x.loc[use, f"aht{boundary}_pw"].to_numpy(), pd.DatetimeIndex(x.loc[use, "time"]))
        trends[boundary] = tr
        print(f"AHT {boundary}N 2005-2022: {tr}")
    try:
        profile, peak, latitude = process_validation_profile()
        print(f"ERA5 AHT peak 1985-2018: {peak:.4f} PW at {latitude:.2f}N")
        validation = pd.DataFrame(
            [
                {
                    "id": "V13",
                    "metric": "ERA5 peak NH AHT 1985-2018 [PW]",
                    "estimate": peak,
                    "target": 4.58,
                    "tolerance": 0.15,
                    "difference": peak - 4.58,
                    "status": "PASS" if abs(peak - 4.58) <= 0.15 else "FAIL",
                    "note": f"peak at {latitude:.2f}N; mass-consistent ERA5 v1.0",
                },
                {
                    "id": "V18_PROXY",
                    "metric": ">=60N ERA5 AHT trend 2005-2022 [PW dec-1]",
                    "estimate": trends[60].slope_per_decade,
                    "target": 0.01,
                    "tolerance": 0.02,
                    "difference": trends[60].slope_per_decade - 0.01,
                    "status": "NOT_ASSESSED_MASK",
                    "note": "fixed 60N boundary is not the Prince & L'Ecuyer AIRS T2m<=0C mask",
                },
            ]
        )
        validation.to_csv(ROOT / "tables/era5_validation.csv", index=False)
        fig, ax = plt.subplots(figsize=(6.4, 4.2))
        ax.plot(profile.latitude, profile.aht_climatology_pw, color="#9c2c2c")
        ax.scatter([latitude], [peak], color="black", s=24, zorder=3)
        ax.axhline(4.58, color="0.45", ls="--", lw=1, label="Mayer target 4.58 PW")
        ax.set(
            xlabel="Latitude (deg N)",
            ylabel="Atmospheric energy transport (PW)",
            title="ERA5 mass-consistent AHT climatology, 1985–2018",
        )
        ax.legend(frameon=False)
        fig.tight_layout()
        fig.savefig(ROOT / "figures/validation_era5_aht_profile.png", dpi=180)
        fig.savefig(ROOT / "outputs/validation_era5_aht_profile.png", dpi=180)
        plt.close(fig)
    except FileNotFoundError as exc:
        print(str(exc))


if __name__ == "__main__":
    main()
