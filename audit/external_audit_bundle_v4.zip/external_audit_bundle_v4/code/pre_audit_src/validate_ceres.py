"""CERES validation before any discovery interpretation."""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from netCDF4 import Dataset, num2date

from src.energy_budget import (
    PW,
    area_weighted_global_mean,
    implied_transport,
    ols_hac_trend,
    zonal_band_areas,
)

ROOT = Path(__file__).resolve().parents[1]
INFILE = ROOT / "raw/ceres/ceres_ebaf_ed4.2.1_zonal_global_200003-202603.nc"


def arr(ds, name):
    x = ds[name][:]
    return x.filled(np.nan) if hasattr(x, "filled") else np.asarray(x)


def period_mask(period, start, end):
    return (period >= start) & (period <= end)


def regional_mean(field, lat, lo, hi):
    area = zonal_band_areas(lat)
    use = (lat >= lo + 0.5) & (lat <= hi - 0.5)
    return np.sum(field[:, use] * area[use], axis=1) / np.sum(area[use])


def hemispheric_mean(field, lat, north):
    area = zonal_band_areas(lat)
    use = lat > 0 if north else lat < 0
    return np.sum(field[:, use] * area[use], axis=1) / np.sum(area[use])


def roots(lat, y):
    out = []
    for i in range(len(y) - 1):
        if y[i] == 0 or y[i] * y[i + 1] < 0:
            out.append(float(lat[i] - y[i] * (lat[i + 1] - lat[i]) / (y[i + 1] - y[i])))
    return out


def main():
    ds = Dataset(INFILE)
    tv = ds["time"]
    dates = num2date(tv[:], tv.units, getattr(tv, "calendar", "standard"))
    index = pd.DatetimeIndex([pd.Timestamp(d.year, d.month, 15) for d in dates])
    period = index.to_period("M")
    lat = arr(ds, "lat")
    zsolar = arr(ds, "zsolar_mon")
    zsw = arr(ds, "ztoa_sw_all_mon")
    zlw = arr(ds, "ztoa_lw_all_mon")
    znet = arr(ds, "ztoa_net_all_mon")
    zswc = arr(ds, "ztoa_sw_clr_t_mon")
    zlwc = arr(ds, "ztoa_lw_clr_t_mon")
    znetc = arr(ds, "ztoa_net_clr_t_mon")
    gasr = arr(ds, "gsolar_mon") - arr(ds, "gtoa_sw_all_mon")
    golr = arr(ds, "gtoa_lw_all_mon")
    gnet = arr(ds, "gtoa_net_all_mon")
    zasr, zasrc = zsolar - zsw, zsolar - zswc

    rows = []

    def add(vid, metric, estimate, target, tolerance, note=""):
        delta = float(estimate - target)
        rows.append(
            {
                "id": vid,
                "metric": metric,
                "estimate": float(estimate),
                "target": float(target),
                "tolerance": float(tolerance),
                "difference": delta,
                "status": "PASS" if abs(delta) <= tolerance else "FAIL",
                "note": note,
            }
        )

    # Loeb et al. (2022), exact publication window but current Ed4.2.1.
    m22 = period_mask(period, "2000-03", "2020-02")
    for vid, name, data, target, tol in [
        ("V01", "global mean ASR [W m-2]", gasr, 241.0, 0.15),
        ("V02", "global mean OLR [W m-2]", golr, 240.2, 0.15),
        ("V03", "global mean NET [W m-2]", gnet, 0.73, 0.08),
    ]:
        add(vid, name, np.mean(data[m22]), target, tol, "Ed4.2.1 tested against Ed4.1 publication")
    for vid, name, data, target in [
        ("V04", "global ASR trend [W m-2 dec-1]", gasr, 0.68),
        ("V05", "global OLR trend [W m-2 dec-1]", golr, 0.26),
        ("V06", "global NET trend [W m-2 dec-1]", gnet, 0.42),
    ]:
        add(vid, name, ols_hac_trend(data[m22], index[m22]).slope_per_decade, target, 0.05, "monthly OLS-HAC; Ed4.2.1")
    shnet = hemispheric_mean(znet, lat, False)
    nhnet = hemispheric_mean(znet, lat, True)
    add("V07_SH", "SH NET trend [W m-2 dec-1]", ols_hac_trend(shnet[m22], index[m22]).slope_per_decade, 0.38, 0.07)
    add("V07_NH", "NH NET trend [W m-2 dec-1]", ols_hac_trend(nhnet[m22], index[m22]).slope_per_decade, 0.46, 0.07)
    _, hmonthly = implied_transport(znet[m22], lat)
    i_eq = 90
    ce = hmonthly[:, i_eq] / PW
    ce_change = abs(ols_hac_trend(ce, index[m22]).slope_per_decade * 2.0)
    add("V08", "magnitude of 20-year CE transport change [PW]", ce_change, 0.02, 0.03, "absolute two-decade change; H itself is northward-positive")

    # Stephens et al. (2015): 13-year analogue, edition difference documented.
    m13 = period_mask(period, "2000-03", "2013-02")
    clim13 = np.mean(znet[m13], axis=0)
    r = roots(lat, clim13)
    add("V09_SH", "southern zero NET latitude [deg]", r[0], -36.9, 1.5, "Ed4.2.1 vs EBAF 2.7r")
    add("V09_NH", "northern zero NET latitude [deg]", r[-1], 35.0, 1.5, "Ed4.2.1 vs EBAF 2.7r")
    edge, h13 = implied_transport(clim13, lat)
    add("V10_SH", "minimum total implied MHT [PW]", np.min(h13) / PW, -5.7, 0.25, "Ed4.2.1 vs EBAF 2.7r")
    add("V10_NH", "maximum total implied MHT [PW]", np.max(h13) / PW, 5.6, 0.25, "Ed4.2.1 vs EBAF 2.7r")

    # Pearce & Bodas-Salcedo (2023), exact window and convention.
    for vid, metric, field, target, tol in [
        ("V11_clear", "clear-sky SW CE implied [PW]", zasrc, 0.83, 0.05),
        ("V11_all", "all-sky SW CE implied [PW]", zasr, -0.01, 0.05),
        ("V12_clear", "clear-sky total CE implied [PW]", znetc, 1.07, 0.06),
        ("V12_all", "all-sky total CE implied [PW]", znet, 0.22, 0.06),
    ]:
        _, h = implied_transport(np.mean(field[m22], axis=0), lat)
        add(vid, metric, h[i_eq] / PW, target, tol, "Ed4.2.1; paper used Ed4.1")

    # Prince targets cannot be exact without their AIRS irregular mask.  The
    # regular >=60N cap is retained as an explicitly non-passing diagnostic.
    mpr = period_mask(period, "2000-03", "2021-02")
    for vid, metric, field, target, tol in [
        ("V14", ">=60N all-sky ASR trend [W m-2 dec-1]", zasr, 0.98, 0.12),
        ("V15", ">=60N all-sky OLR trend [W m-2 dec-1]", zlw, 0.94, 0.12),
        ("V16", ">=60N all-sky NET trend [W m-2 dec-1]", znet, 0.05, 0.12),
        ("V17_ASR", ">=60N clear-sky ASR trend [W m-2 dec-1]", zasrc, 2.01, 0.15),
        ("V17_OLR", ">=60N clear-sky OLR trend [W m-2 dec-1]", zlwc, 1.24, 0.15),
        ("V17_NET", ">=60N clear-sky NET trend [W m-2 dec-1]", znetc, 0.78, 0.15),
    ]:
        estimate = ols_hac_trend(regional_mean(field, lat, 60, 90)[mpr], index[mpr]).slope_per_decade
        add(vid, metric, estimate, target, tol, "DIAGNOSTIC ONLY: >=60N is not the AIRS T2m<=0 C mask")
        rows[-1]["status"] = "NOT_ASSESSED_MASK"

    # Later Ed4.2.1 paper benchmarks.
    for label, start, end, targets, tol in [
        ("V22", "2000-03", "2022-12", (0.71, 0.26, 0.45), 0.06),
        ("V23", "2001-01", "2024-12", (0.83, 0.39, 0.45), 0.07),
    ]:
        use = period_mask(period, start, end)
        for suffix, name, data, target in zip(["ASR", "OLR", "NET"], ["ASR", "OLR", "NET"], [gasr, golr, gnet], targets):
            add(f"{label}_{suffix}", f"global {name} trend {start}/{end} [W m-2 dec-1]", ols_hac_trend(data[use], index[use]).slope_per_decade, target, tol)
    m25 = period_mask(period, "2001-01", "2024-12")
    for suffix, field, target in [("ASR", zasr, 0.34), ("OLR", zlw, 0.21), ("NET", znet, 0.14)]:
        diff = hemispheric_mean(field, lat, True) - hemispheric_mean(field, lat, False)
        add(f"V24_{suffix}", f"NH-SH {suffix} trend [W m-2 dec-1]", ols_hac_trend(diff[m25], index[m25]).slope_per_decade, target, 0.08)
    area = zonal_band_areas(lat)
    band = (lat >= 20.5) & (lat <= 41.5)
    source_scaled = np.sum(zasr[:, band] * area[band], axis=1) / (0.5 * np.sum(area))
    add("V25", "20-42N ASR contribution scaled to NH area [W m-2 dec-1]", ols_hac_trend(source_scaled[m25], index[m25]).slope_per_decade, 0.51, 0.10)

    table = pd.DataFrame(rows)
    table.to_csv(ROOT / "tables/ceres_validation.csv", index=False)

    # Monthly validation/coverage table for downstream reproducibility.
    pd.DataFrame({"time": index, "global_asr_wm2": gasr, "global_olr_wm2": golr, "global_net_wm2": gnet, "nh_net_wm2": nhnet, "sh_net_wm2": shnet}).to_csv(ROOT / "tables/ceres_monthly_metrics.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    axes[0].plot(lat, clim13, color="black")
    axes[0].axhline(0, color="0.6", lw=0.8)
    axes[0].set(xlabel="Latitude (deg)", ylabel="N_TOA (W m$^{-2}$)", title="Zonal TOA NET, 2000-03–2013-02")
    axes[1].plot(edge, h13 / PW, color="#1768ac")
    axes[1].axhline(0, color="0.6", lw=0.8)
    axes[1].set(xlabel="Latitude edge (deg)", ylabel="Raw implied MHT (PW)", title="Mean-removed implied transport")
    fig.suptitle("CERES EBAF Ed4.2.1 validation (northward positive)")
    fig.tight_layout()
    fig.savefig(ROOT / "figures/validation_zonal_mht.png", dpi=180)
    fig.savefig(ROOT / "outputs/validation_zonal_mht.png", dpi=180)
    plt.close(fig)
    ds.close()
    print(table.to_string(index=False))
    print("\nStatus counts:\n", table.status.value_counts().to_string())


if __name__ == "__main__":
    main()
