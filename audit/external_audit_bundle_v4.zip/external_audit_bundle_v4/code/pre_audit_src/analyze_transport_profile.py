"""Continuous 30--85N transport budgets, trends, and detectability.

Primary sign convention for a Northern cap:

    N_cap = dE_cap/dt - H_in
    H_known = dE_ocean(0--2000m)/dt + dE_atmosphere/dt - N_cap

``H_known`` is deliberately not called actual total transport because the
storage inventory remains incomplete.  The non-atmospheric term is a residual,
not an independently observed ocean heat transport.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints
from src.analyze_partial_transport import filter_flux_like_state
from src.energy_budget import PW, cap_area, exact_month_seconds, ols_hac_trend


ROOT = Path(__file__).resolve().parents[1]
BOUNDARIES = np.arange(30.0, 86.0, 1.0)
SEASONS = {"DJF": (12, 1, 2), "MAM": (3, 4, 5), "JJA": (6, 7, 8), "SON": (9, 10, 11)}
METRIC_LABELS = {
    "ntoa_cap": "N_TOA cap",
    "ocean_storage_0_2000": "ocean storage 0–2000 m",
    "atmospheric_storage_total_energy": "atmospheric total-energy storage",
    "known_storage": "known storage",
    "h_known": "H_known",
    "raw_implied": "raw implied",
    "actual_aht": "actual ERA5 AHT",
    "non_atmospheric_residual": "non-atmospheric residual",
    "closure_residual": "algebraic closure residual",
}


def _normalize_era_time(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    period = pd.DatetimeIndex(out.time).to_period("M")
    unique = pd.period_range(period.min(), period.max(), freq="M")
    if len(unique) * len(BOUNDARIES) != len(out):
        raise RuntimeError("ERA5 profile month/boundary grid is incomplete")
    midpoint = dict(zip(unique.astype(str), monthly_midpoints(str(unique[0]), len(unique))))
    out["time"] = period.astype(str).map(midpoint)
    return out


def _align_boundary(boundary: float, ceres: pd.DataFrame, ohc: pd.DataFrame, era: pd.DataFrame):
    c = ceres[ceres.boundary_deg_n == boundary].sort_values("time").reset_index(drop=True)
    o = ohc[ohc.boundary_deg_n == boundary].sort_values("time").reset_index(drop=True)
    e = era[era.boundary_deg_n == boundary].sort_values("time").reset_index(drop=True)
    for frame in (c, o, e):
        frame["month"] = pd.DatetimeIndex(frame.time).to_period("M").astype(str)
    merged = c.drop(columns="time").merge(o.drop(columns=["time", "boundary_deg_n"]), on="month", validate="one_to_one")
    merged = merged.merge(e.drop(columns=["time", "boundary_deg_n"]), on="month", validate="one_to_one")
    merged["time"] = pd.PeriodIndex(merged.month, freq="M").to_timestamp(how="start")
    midpoint = monthly_midpoints(str(pd.Period(merged.month.iloc[0], freq="M")), len(merged))
    merged["time"] = midpoint
    merged = merged.drop(columns="month")
    if len(merged) != 216:
        raise RuntimeError(f"expected 216 common raw months at {boundary}N")
    return merged


def _filtered_components(raw: pd.DataFrame, method: str) -> pd.DataFrame:
    index = pd.DatetimeIndex(raw.time)
    if method == "block_12m_means":
        time, ocean_w = block_mean_tendency(raw.ohc_0_2000_j.to_numpy(), index)
    elif method == "central_12m_endpoints":
        time, ocean_w = central_span_tendency(raw.ohc_0_2000_j.to_numpy(), index)
    else:
        raise ValueError(method)
    outputs = {"ocean_storage_0_2000_pw": ocean_w / PW}
    for input_name, output_name in [
        ("ntoa_cap_pw", "ntoa_cap_pw"),
        ("raw_implied_pw", "raw_implied_pw"),
        ("atmospheric_storage_pw", "atmospheric_storage_total_energy_pw"),
        ("aht_pw", "actual_aht_pw"),
    ]:
        check_time, value_w = filter_flux_like_state(raw[input_name].to_numpy() * PW, index, method)
        if not time.equals(check_time):
            raise RuntimeError("filtered timestamps do not align")
        outputs[output_name] = value_w / PW
    out = pd.DataFrame({"time": time, **outputs})
    out["known_storage_pw"] = out.ocean_storage_0_2000_pw + out.atmospheric_storage_total_energy_pw
    out["h_known_pw"] = out.known_storage_pw - out.ntoa_cap_pw
    out["non_atmospheric_residual_pw"] = out.h_known_pw - out.actual_aht_pw
    out["closure_residual_pw"] = out.ntoa_cap_pw - out.known_storage_pw + out.h_known_pw
    out["partition_residual_pw"] = out.h_known_pw - out.actual_aht_pw - out.non_atmospheric_residual_pw
    return out


def _summary_row(boundary: float, method: str, metric: str, values_pw: np.ndarray, index: pd.DatetimeIndex) -> dict:
    trend = ols_hac_trend(values_pw, index, maxlags=24)
    halfwidth_pw = 0.5 * (trend.ci_high - trend.ci_low)
    area = cap_area(boundary)
    slope_tw = trend.slope_per_decade * 1000.0
    halfwidth_tw = halfwidth_pw * 1000.0
    return {
        "boundary_deg_n": boundary,
        "method": method,
        "metric": metric,
        "definition_label": METRIC_LABELS[metric],
        "start": str(index[0].date()),
        "end": str(index[-1].date()),
        "n_months": len(index),
        "mean_pw": float(np.mean(values_pw)),
        "trend_pw_dec": trend.slope_per_decade,
        "trend_tw_dec": slope_tw,
        "trend_wm2_cap_dec": trend.slope_per_decade * PW / area,
        "trend_se_tw_dec": trend.se_per_decade * 1000.0,
        "trend_ci_low_tw_dec": trend.ci_low * 1000.0,
        "trend_ci_high_tw_dec": trend.ci_high * 1000.0,
        "trend_ci_low_wm2_cap_dec": trend.ci_low * PW / area,
        "trend_ci_high_wm2_cap_dec": trend.ci_high * PW / area,
        "minimum_detectable_trend_tw_dec_95": halfwidth_tw,
        "minimum_detectable_trend_wm2_cap_dec_95": halfwidth_pw * PW / area,
        "signal_to_ci_halfwidth": abs(slope_tw) / halfwidth_tw if halfwidth_tw > 0 else np.nan,
        "ci_excludes_zero": bool(trend.ci_low > 0 or trend.ci_high < 0),
        "uncertainty": "OLS-HAC(24); regression/temporal only, excluding structural storage uncertainty",
    }


def _day_weighted(frame: pd.DataFrame, column: str) -> float:
    weights = exact_month_seconds(pd.DatetimeIndex(frame.time))
    return float(np.average(frame[column].to_numpy(), weights=weights))


def _annual_and_seasonal_aht(era: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    timeseries_rows = []
    summary_rows = []
    for boundary in BOUNDARIES:
        b = era[era.boundary_deg_n == boundary].copy().sort_values("time")
        index = pd.DatetimeIndex(b.time)
        b["year"] = index.year
        b["month_number"] = index.month
        groups = {"Annual": None, **SEASONS}
        for aggregation, months in groups.items():
            if aggregation == "Annual":
                season_year = b.year
                selected_months = np.ones(len(b), dtype=bool)
                centre_month = 7
            else:
                season_year = b.year + ((b.month_number == 12) if aggregation == "DJF" else 0)
                selected_months = b.month_number.isin(months)
                centre_month = {"DJF": 2, "MAM": 5, "JJA": 8, "SON": 11}[aggregation]
            rows = []
            for year in range(2006, 2023):
                group = b[selected_months & (season_year == year)]
                required = 12 if aggregation == "Annual" else 3
                if len(group) != required:
                    raise RuntimeError(f"incomplete {aggregation} {year} at {boundary}N")
                rows.append(
                    {
                        "boundary_deg_n": boundary,
                        "aggregation": aggregation,
                        "year": year,
                        "time": pd.Timestamp(year, centre_month, 15),
                        "aht_pw": _day_weighted(group, "aht_pw"),
                    }
                )
            group_frame = pd.DataFrame(rows)
            timeseries_rows.extend(rows)
            trend = ols_hac_trend(
                group_frame.aht_pw.to_numpy(),
                pd.DatetimeIndex(group_frame.time),
                deseasonalize=False,
                maxlags=2,
            )
            halfwidth = 0.5 * (trend.ci_high - trend.ci_low) * 1000.0
            summary_rows.append(
                {
                    "boundary_deg_n": boundary,
                    "aggregation": aggregation,
                    "start_year": 2006,
                    "end_year": 2022,
                    "n_years": 17,
                    "mean_pw": float(np.mean(group_frame.aht_pw)),
                    "trend_tw_dec": trend.slope_per_decade * 1000.0,
                    "trend_ci_low_tw_dec": trend.ci_low * 1000.0,
                    "trend_ci_high_tw_dec": trend.ci_high * 1000.0,
                    "minimum_detectable_trend_tw_dec_95": halfwidth,
                    "signal_to_ci_halfwidth": abs(trend.slope_per_decade * 1000.0) / halfwidth,
                    "ci_excludes_zero": bool(trend.ci_low > 0 or trend.ci_high < 0),
                    "uncertainty": "OLS-HAC(2) over 17 calendar aggregates",
                }
            )
    return pd.DataFrame(timeseries_rows), pd.DataFrame(summary_rows)


def _state_at(values: np.ndarray, index: pd.DatetimeIndex, target: pd.Timestamp) -> float:
    origin = index[0]
    x = np.asarray([(time - origin).total_seconds() for time in index])
    point = (target - origin).total_seconds()
    if point < x[0] or point > x[-1]:
        raise ValueError("state target outside available midpoint interval")
    return float(np.interp(point, x, values))


def _annual_budget(raw_by_boundary: dict[float, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for boundary in (60.0, 65.0, 70.0):
        raw = raw_by_boundary[boundary]
        index = pd.DatetimeIndex(raw.time)
        for year in range(2006, 2022):
            group = raw[pd.DatetimeIndex(raw.time).year == year]
            if len(group) != 12:
                raise RuntimeError("annual budget group is incomplete")
            start, end = pd.Timestamp(year, 1, 1), pd.Timestamp(year + 1, 1, 1)
            ocean = (
                _state_at(raw.ohc_0_2000_j.to_numpy(), index, end)
                - _state_at(raw.ohc_0_2000_j.to_numpy(), index, start)
            ) / (end - start).total_seconds() / PW
            ntoa = _day_weighted(group, "ntoa_cap_pw")
            atmosphere = _day_weighted(group, "atmospheric_storage_pw")
            aht = _day_weighted(group, "aht_pw")
            required = ocean + atmosphere - ntoa
            residual = required - aht
            rows.append(
                {
                    "boundary_deg_n": boundary,
                    "year": year,
                    "time": pd.Timestamp(year, 7, 1),
                    "ntoa_cap_pw": ntoa,
                    "ocean_storage_0_2000_pw": ocean,
                    "atmospheric_storage_total_energy_pw": atmosphere,
                    "h_known_pw": required,
                    "actual_aht_pw": aht,
                    "non_atmospheric_residual_pw": residual,
                    "closure_residual_pw": ntoa - ocean - atmosphere + required,
                }
            )
    return pd.DataFrame(rows)


def _plot_outputs(summary: pd.DataFrame, block: pd.DataFrame, seasonal: pd.DataFrame, annual_budget: pd.DataFrame) -> None:
    primary = summary[summary.method == "block_12m_means"]
    lat = BOUNDARIES
    colors = {"h_known": "#0b6e99", "actual_aht": "#d95f02", "non_atmospheric_residual": "#1b9e77", "raw_implied": "#777777"}

    # 1. Climatology.
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    for metric, label in [("h_known", "H_known"), ("actual_aht", "actual ERA5 AHT"), ("non_atmospheric_residual", "non-atmospheric residual")]:
        x = primary[primary.metric == metric].set_index("boundary_deg_n").loc[lat]
        ax.plot(lat, x.mean_pw, lw=1.8, color=colors[metric], label=label)
    ax.axhline(0, color="0.6", lw=0.7)
    ax.set(xlabel="Northern cap boundary (°N)", ylabel="Mean northward transport (PW)", title="Climatological transport partition, 2006-01–2022-01")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_01_climatology_vs_latitude.png", dpi=180); plt.close(fig)

    # 2. Raw implied and H_known trends.
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    for metric, label in [("raw_implied", "raw implied"), ("h_known", "H_known")]:
        x = primary[primary.metric == metric].set_index("boundary_deg_n").loc[lat]
        ax.plot(lat, x.trend_tw_dec, lw=1.6, color=colors[metric], label=label)
        ax.fill_between(lat, x.trend_ci_low_tw_dec, x.trend_ci_high_tw_dec, color=colors[metric], alpha=0.16)
    ax.axhline(0, color="black", lw=0.8)
    ax.set(xlabel="Northern cap boundary (°N)", ylabel="Trend (TW decade$^{-1}$)", title="Raw-implied and known-storage-corrected transport trends")
    ax.legend(frameon=False); fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_02_total_hknown_trend_vs_latitude.png", dpi=180); plt.close(fig)

    # 3/4. Individual trend envelopes.
    for number, metric, title in [
        (3, "actual_aht", "Actual ERA5 atmospheric transport trend"),
        (4, "non_atmospheric_residual", "Non-atmospheric residual trend"),
    ]:
        x = primary[primary.metric == metric].set_index("boundary_deg_n").loc[lat]
        fig, ax = plt.subplots(figsize=(8.5, 5.2))
        ax.plot(lat, x.trend_tw_dec, color=colors[metric], lw=1.8)
        ax.fill_between(lat, x.trend_ci_low_tw_dec, x.trend_ci_high_tw_dec, color=colors[metric], alpha=0.2)
        ax.axhline(0, color="black", lw=0.8)
        ax.set(xlabel="Northern cap boundary (°N)", ylabel="Trend (TW decade$^{-1}$)", title=title + "\n95% HAC confidence envelope")
        fig.tight_layout(); fig.savefig(ROOT / f"outputs/transport_{number:02d}_{metric}_trend_vs_latitude.png", dpi=180); plt.close(fig)

    # 5. Temporal uncertainty half-width.
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    for metric, label in [("h_known", "H_known"), ("actual_aht", "actual AHT"), ("non_atmospheric_residual", "non-atmospheric residual")]:
        x = primary[primary.metric == metric].set_index("boundary_deg_n").loc[lat]
        ax.plot(lat, x.minimum_detectable_trend_tw_dec_95, color=colors[metric], lw=1.6, label=label)
    ax.set(xlabel="Northern cap boundary (°N)", ylabel="95% temporal CI half-width (TW decade$^{-1}$)", title="Regression uncertainty envelope by latitude")
    ax.legend(frameon=False); fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_05_uncertainty_envelope_vs_latitude.png", dpi=180); plt.close(fig)

    # 6. Component trend budget.
    metrics = ["ntoa_cap", "ocean_storage_0_2000", "atmospheric_storage_total_energy", "h_known", "actual_aht", "non_atmospheric_residual"]
    labels = ["N_TOA", "OHC 0–2000", "atm storage", "H_known", "AHT", "non-atm residual"]
    fig, axes = plt.subplots(1, 3, figsize=(14, 5.4), sharey=True)
    for ax, boundary in zip(axes, (60.0, 65.0, 70.0)):
        x = primary[(primary.boundary_deg_n == boundary) & primary.metric.isin(metrics)].set_index("metric").loc[metrics]
        position = np.arange(len(metrics))
        ax.bar(position, x.trend_tw_dec, color=["#c17c27", "#287271", "#884ea0", "#0b6e99", "#d95f02", "#1b9e77"])
        ax.errorbar(position, x.trend_tw_dec, yerr=np.vstack([x.trend_tw_dec-x.trend_ci_low_tw_dec, x.trend_ci_high_tw_dec-x.trend_tw_dec]), fmt="none", ecolor="black", capsize=2)
        ax.axhline(0, color="black", lw=0.7); ax.set_title(f"{int(boundary)}°N")
        ax.set_xticks(position, labels, rotation=55, ha="right")
    axes[0].set_ylabel("Trend (TW decade$^{-1}$)")
    fig.suptitle("Known-cap component budgets, 2006-01–2022-01")
    fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_06_component_budget_60_65_70.png", dpi=180); plt.close(fig)

    # 7. Algebraic closure residual (must be numerical zero).
    x = primary[primary.metric == "closure_residual"].set_index("boundary_deg_n").loc[lat]
    fig, ax = plt.subplots(figsize=(8.5, 4.8)); ax.plot(lat, x.trend_tw_dec, color="#5d3a9b", lw=1.6)
    ax.axhline(0, color="black", lw=0.8); ax.set(xlabel="Northern cap boundary (°N)", ylabel="Residual trend (TW decade$^{-1}$)", title="Algebraic closure residual vs latitude\n(structural missing storage is assessed separately)")
    fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_07_closure_residual_vs_latitude.png", dpi=180); plt.close(fig)

    # 8. Minimum detectable trends.
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    for metric, label in [("h_known", "H_known"), ("actual_aht", "actual AHT"), ("non_atmospheric_residual", "non-atmospheric residual")]:
        x = primary[primary.metric == metric].set_index("boundary_deg_n").loc[lat]
        ax.plot(lat, x.minimum_detectable_trend_tw_dec_95, color=colors[metric], lw=1.7, label=label)
        ax.plot(lat, np.abs(x.trend_tw_dec), color=colors[metric], lw=0.9, ls="--", alpha=0.7)
    ax.set(xlabel="Northern cap boundary (°N)", ylabel="Magnitude (TW decade$^{-1}$)", title="Minimum detectable trend (solid) and observed magnitude (dashed)")
    ax.legend(frameon=False); fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_08_minimum_detectable_trend_vs_latitude.png", dpi=180); plt.close(fig)

    # 9. Independent calendar-annual component time series.
    fig, axes = plt.subplots(3, 1, figsize=(10.2, 8.8), sharex=True)
    for ax, boundary in zip(axes, (60.0, 65.0, 70.0)):
        x = annual_budget[annual_budget.boundary_deg_n == boundary]
        ax.plot(x.year, x.h_known_pw, color=colors["h_known"], marker="o", ms=3, label="H_known")
        ax.plot(x.year, x.actual_aht_pw, color=colors["actual_aht"], marker="o", ms=3, label="actual AHT")
        ax.plot(x.year, x.non_atmospheric_residual_pw, color=colors["non_atmospheric_residual"], marker="o", ms=3, label="non-atm residual")
        ax.set(ylabel="PW", title=f"{int(boundary)}°N")
    axes[0].legend(frameon=False, ncol=3); axes[-1].set_xlabel("Calendar year")
    fig.suptitle("Annual transport partition, exact calendar budgets (2006–2021)")
    fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_09_annual_timeseries_60_65_70.png", dpi=180); plt.close(fig)

    # 10. Seasonal actual AHT trend profiles.
    fig, axes = plt.subplots(2, 2, figsize=(11, 8), sharex=True, sharey=True)
    for ax, season in zip(axes.ravel(), SEASONS):
        x = seasonal[seasonal.aggregation == season].set_index("boundary_deg_n").loc[lat]
        ax.plot(lat, x.trend_tw_dec, color=colors["actual_aht"], lw=1.6)
        ax.fill_between(lat, x.trend_ci_low_tw_dec, x.trend_ci_high_tw_dec, color=colors["actual_aht"], alpha=0.18)
        ax.axhline(0, color="black", lw=0.7); ax.set_title(season)
    axes[1, 0].set_xlabel("Boundary (°N)"); axes[1, 1].set_xlabel("Boundary (°N)")
    axes[0, 0].set_ylabel("Trend (TW decade$^{-1}$)"); axes[1, 0].set_ylabel("Trend (TW decade$^{-1}$)")
    fig.suptitle("Seasonal actual ERA5 AHT trends, 2006–2022 (95% HAC CI)")
    fig.tight_layout(); fig.savefig(ROOT / "outputs/transport_10_seasonal_aht_trends.png", dpi=180); plt.close(fig)


def main() -> None:
    ceres = pd.read_csv(ROOT / "tables/ceres_cap_profile_monthly.csv", parse_dates=["time"])
    ohc = pd.read_csv(ROOT / "tables/ohc_cap_profile_monthly_energy.csv", parse_dates=["time"])
    era = _normalize_era_time(pd.read_csv(ROOT / "tables/era5_transport_profile_monthly.csv", parse_dates=["time"]))
    period = pd.DatetimeIndex(era.time).to_period("M")
    era_common = era[(period >= "2005-01") & (period <= "2022-12")].reset_index(drop=True)

    raw_by_boundary = {}
    timeseries = {"block_12m_means": [], "central_12m_endpoints": []}
    summary_rows = []
    max_budget_error = 0.0
    max_partition_error = 0.0
    for boundary in BOUNDARIES:
        raw = _align_boundary(boundary, ceres, ohc, era_common)
        raw_by_boundary[boundary] = raw
        for method in timeseries:
            filtered = _filtered_components(raw, method)
            filtered.insert(1, "boundary_deg_n", boundary)
            timeseries[method].append(filtered)
            max_budget_error = max(max_budget_error, float(np.max(np.abs(filtered.closure_residual_pw))))
            max_partition_error = max(max_partition_error, float(np.max(np.abs(filtered.partition_residual_pw))))
            for column, metric in [
                ("ntoa_cap_pw", "ntoa_cap"),
                ("ocean_storage_0_2000_pw", "ocean_storage_0_2000"),
                ("atmospheric_storage_total_energy_pw", "atmospheric_storage_total_energy"),
                ("known_storage_pw", "known_storage"),
                ("h_known_pw", "h_known"),
                ("raw_implied_pw", "raw_implied"),
                ("actual_aht_pw", "actual_aht"),
                ("non_atmospheric_residual_pw", "non_atmospheric_residual"),
                ("closure_residual_pw", "closure_residual"),
            ]:
                summary_rows.append(_summary_row(boundary, method, metric, filtered[column].to_numpy(), pd.DatetimeIndex(filtered.time)))

    block = pd.concat(timeseries["block_12m_means"], ignore_index=True)
    central = pd.concat(timeseries["central_12m_endpoints"], ignore_index=True)
    summary = pd.DataFrame(summary_rows)
    block.to_csv(ROOT / "tables/transport_profile_block_timeseries.csv", index=False)
    block.to_csv(ROOT / "outputs/transport_profile_block_timeseries.csv", index=False)
    central.to_csv(ROOT / "tables/transport_profile_central_timeseries.csv", index=False)
    summary.to_csv(ROOT / "tables/transport_latitude_profile.csv", index=False)
    summary.to_csv(ROOT / "outputs/transport_latitude_profile.csv", index=False)

    seasonal_timeseries, seasonal_summary = _annual_and_seasonal_aht(era_common)
    seasonal_timeseries.to_csv(ROOT / "tables/aht_annual_seasonal_timeseries.csv", index=False)
    seasonal_summary.to_csv(ROOT / "tables/aht_annual_seasonal_profile.csv", index=False)
    seasonal_summary.to_csv(ROOT / "outputs/aht_annual_seasonal_profile.csv", index=False)
    annual_budget = _annual_budget(raw_by_boundary)
    annual_budget.to_csv(ROOT / "tables/transport_annual_budget_60_65_70.csv", index=False)
    annual_budget.to_csv(ROOT / "outputs/transport_annual_budget_60_65_70.csv", index=False)

    # Compare block-filter and calendar-annual AHT trends on their native spans.
    sensitivity_rows = []
    annual = seasonal_summary[seasonal_summary.aggregation == "Annual"].set_index("boundary_deg_n")
    block_aht = summary[(summary.method == "block_12m_means") & (summary.metric == "actual_aht")].set_index("boundary_deg_n")
    central_aht = summary[(summary.method == "central_12m_endpoints") & (summary.metric == "actual_aht")].set_index("boundary_deg_n")
    for boundary in BOUNDARIES:
        for method, row in [("block_12m_lowpass", block_aht.loc[boundary]), ("central_12m", central_aht.loc[boundary])]:
            sensitivity_rows.append({"boundary_deg_n": boundary, "method": method, "trend_tw_dec": row.trend_tw_dec, "ci_low_tw_dec": row.trend_ci_low_tw_dec, "ci_high_tw_dec": row.trend_ci_high_tw_dec})
        row = annual.loc[boundary]
        sensitivity_rows.append({"boundary_deg_n": boundary, "method": "calendar_annual", "trend_tw_dec": row.trend_tw_dec, "ci_low_tw_dec": row.trend_ci_low_tw_dec, "ci_high_tw_dec": row.trend_ci_high_tw_dec})
    sensitivity = pd.DataFrame(sensitivity_rows)
    sensitivity.to_csv(ROOT / "outputs/aht_filter_sensitivity_profile.csv", index=False)

    diagnostics = pd.DataFrame(
        [
            {"diagnostic": "known-budget algebra max error", "value": max_budget_error, "unit": "PW", "status": "PASS" if max_budget_error < 1e-13 else "FAIL"},
            {"diagnostic": "partition algebra max error", "value": max_partition_error, "unit": "PW", "status": "PASS" if max_partition_error < 1e-13 else "FAIL"},
            {"diagnostic": "profile boundaries", "value": len(BOUNDARIES), "unit": "integer degrees", "status": "PASS" if len(BOUNDARIES) == 56 else "FAIL"},
            {"diagnostic": "primary filtered span", "value": f"{block.time.min():%Y-%m}--{block.time.max():%Y-%m}", "unit": "months", "status": "PASS" if len(block) == 56 * 193 else "FAIL"},
            {"diagnostic": "AHT climatology physically bounded", "value": float(summary[(summary.method == "block_12m_means") & (summary.metric == "actual_aht")].mean_pw.abs().max()), "unit": "PW", "status": "PASS" if summary[(summary.method == "block_12m_means") & (summary.metric == "actual_aht")].mean_pw.abs().max() < 10 else "FAIL"},
        ]
    )
    diagnostics.to_csv(ROOT / "tables/transport_profile_diagnostics.csv", index=False)
    diagnostics.to_csv(ROOT / "outputs/transport_profile_diagnostics.csv", index=False)
    if (diagnostics.status != "PASS").any():
        raise RuntimeError("transport profile diagnostics failed")

    _plot_outputs(summary, block, seasonal_summary, annual_budget)
    key = summary[(summary.method == "block_12m_means") & summary.boundary_deg_n.isin([60, 65, 70]) & summary.metric.isin(["h_known", "actual_aht", "non_atmospheric_residual"])]
    print(diagnostics.to_string(index=False))
    print("\nKey primary results:\n" + key[["boundary_deg_n", "metric", "mean_pw", "trend_tw_dec", "trend_ci_low_tw_dec", "trend_ci_high_tw_dec", "minimum_detectable_trend_tw_dec_95", "signal_to_ci_halfwidth"]].to_string(index=False))


if __name__ == "__main__":
    main()
