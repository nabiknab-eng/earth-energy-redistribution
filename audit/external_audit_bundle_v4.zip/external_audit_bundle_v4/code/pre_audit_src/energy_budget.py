"""Conservative zonal energy-budget utilities.

Sign convention: N_TOA is positive downward; meridional transport is positive
northward.  Latitude inputs are cell centres in degrees and must be ordered
south-to-north.
"""

from __future__ import annotations

import calendar
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.stats import norm

R_EARTH = 6.371e6
EARTH_AREA = 4.0 * np.pi * R_EARTH**2
PW = 1.0e15
TW = 1.0e12


def latitude_edges(lat: np.ndarray) -> np.ndarray:
    """Return bounded latitude edges for monotonic cell centres."""
    lat = np.asarray(lat, dtype=float)
    if lat.ndim != 1 or lat.size < 2 or np.any(np.diff(lat) <= 0):
        raise ValueError("latitude must be a strictly increasing 1-D array")
    edges = np.empty(lat.size + 1)
    edges[1:-1] = 0.5 * (lat[:-1] + lat[1:])
    edges[0], edges[-1] = -90.0, 90.0
    if np.any(edges < -90.0) or np.any(edges > 90.0):
        raise ValueError("latitude edges lie outside the sphere")
    return edges


def zonal_band_areas(lat: np.ndarray, radius: float = R_EARTH) -> np.ndarray:
    """Exact spherical area of each complete longitude band, in m2."""
    e = np.deg2rad(latitude_edges(lat))
    return 2.0 * np.pi * radius**2 * (np.sin(e[1:]) - np.sin(e[:-1]))


def area_weighted_global_mean(field: np.ndarray, lat: np.ndarray) -> np.ndarray:
    """Global mean of zonal means, preserving leading dimensions."""
    field = np.asarray(field, dtype=float)
    a = zonal_band_areas(lat)
    if field.shape[-1] != a.size:
        raise ValueError("last field dimension must match latitude")
    return np.sum(field * a, axis=-1) / np.sum(a)


def implied_transport(
    source_wm2: np.ndarray,
    lat: np.ndarray,
    *,
    remove_global_mean: bool = True,
    radius: float = R_EARTH,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate zonal source to northward MHT at latitude edges.

    Returns `(edge_latitude_deg, H_watts)`.  The southern boundary is exactly
    zero.  If the source is conservative, the northern boundary is also zero.
    """
    src = np.asarray(source_wm2, dtype=float)
    if src.shape[-1] != len(lat):
        raise ValueError("last source dimension must match latitude")
    area = zonal_band_areas(lat, radius)
    if remove_global_mean:
        gm = np.sum(src * area, axis=-1, keepdims=True) / np.sum(area)
        src = src - gm
    h = np.concatenate(
        [np.zeros(src.shape[:-1] + (1,)), np.cumsum(src * area, axis=-1)], axis=-1
    )
    return latitude_edges(lat), h


def implied_transport_from_north(
    source_wm2: np.ndarray,
    lat: np.ndarray,
    *,
    remove_global_mean: bool = True,
    radius: float = R_EARTH,
) -> tuple[np.ndarray, np.ndarray]:
    """Independent north-to-south integration of northward transport."""
    src = np.asarray(source_wm2, dtype=float)
    area = zonal_band_areas(lat, radius)
    if src.shape[-1] != area.size:
        raise ValueError("last source dimension must match latitude")
    if remove_global_mean:
        gm = np.sum(src * area, axis=-1, keepdims=True) / np.sum(area)
        src = src - gm
    north_cap_source = np.cumsum((src * area)[..., ::-1], axis=-1)[..., ::-1]
    h = np.concatenate([-north_cap_source, np.zeros(src.shape[:-1] + (1,))], axis=-1)
    return latitude_edges(lat), h


def source_from_transport(transport_w: np.ndarray, lat: np.ndarray) -> np.ndarray:
    """Forward finite-volume source reconstructed from edge transport."""
    h = np.asarray(transport_w, dtype=float)
    area = zonal_band_areas(lat)
    if h.shape[-1] != area.size + 1:
        raise ValueError("transport must be defined on all latitude edges")
    return np.diff(h, axis=-1) / area


def cap_area(boundary_deg: float, radius: float = R_EARTH) -> float:
    """Area north of the boundary latitude."""
    p = np.deg2rad(boundary_deg)
    return 2.0 * np.pi * radius**2 * (1.0 - np.sin(p))


def cap_integral_from_zonal(
    field_wm2: np.ndarray, lat: np.ndarray, boundary_deg: float
) -> np.ndarray:
    """Area integral over complete cells north of an edge-aligned boundary."""
    edges = latitude_edges(lat)
    idx = np.flatnonzero(np.isclose(edges, boundary_deg, atol=1e-10))
    if idx.size != 1:
        raise ValueError("boundary must coincide with a latitude cell edge")
    i = int(idx[0])
    area = zonal_band_areas(lat)
    return np.sum(np.asarray(field_wm2)[..., i:] * area[i:], axis=-1)


def exact_month_seconds(index: pd.DatetimeIndex) -> np.ndarray:
    return np.asarray(
        [calendar.monthrange(t.year, t.month)[1] * 86400.0 for t in index], dtype=float
    )


def decimal_year(index: pd.DatetimeIndex) -> np.ndarray:
    """Decimal year at the timestamp, respecting leap-year duration."""
    out = []
    for t in index:
        y0 = pd.Timestamp(t.year, 1, 1)
        y1 = pd.Timestamp(t.year + 1, 1, 1)
        out.append(t.year + (t - y0) / (y1 - y0))
    return np.asarray(out, dtype=float)


@dataclass(frozen=True)
class Trend:
    slope_per_decade: float
    se_per_decade: float
    ci_low: float
    ci_high: float
    n: int


def ols_hac_trend(
    values: np.ndarray,
    index: pd.DatetimeIndex,
    *,
    deseasonalize: bool = True,
    maxlags: int = 12,
    alpha: float = 0.05,
) -> Trend:
    """Linear monthly trend with Newey-West/HAC uncertainty."""
    y = np.asarray(values, dtype=float)
    ok = np.isfinite(y)
    y, idx = y[ok], index[ok]
    if deseasonalize:
        month_mean = pd.Series(y, index=idx).groupby(idx.month).transform("mean").to_numpy()
        y = y - month_mean + np.mean(y)
    x = decimal_year(idx)
    x = x - np.mean(x)
    design = np.column_stack([np.ones_like(x), x])
    xtx_inv = np.linalg.inv(design.T @ design)
    beta = xtx_inv @ design.T @ y
    resid = y - design @ beta
    # Newey-West covariance with Bartlett weights.  The n/(n-k) factor is a
    # transparent finite-sample correction; no IID uncertainty is reported.
    score = design * resid[:, None]
    meat = score.T @ score
    for lag in range(1, min(maxlags, len(y) - 1) + 1):
        weight = 1.0 - lag / (maxlags + 1.0)
        gamma = score[lag:].T @ score[:-lag]
        meat += weight * (gamma + gamma.T)
    cov = (len(y) / (len(y) - design.shape[1])) * xtx_inv @ meat @ xtx_inv
    se = float(np.sqrt(max(cov[1, 1], 0.0)))
    z = float(norm.ppf(1.0 - alpha / 2.0))
    lo, hi = beta[1] - z * se, beta[1] + z * se
    return Trend(float(beta[1] * 10), se * 10, float(lo * 10), float(hi * 10), len(y))


def day_weighted_mean(values: np.ndarray, index: pd.DatetimeIndex) -> float:
    v = np.asarray(values, dtype=float)
    w = exact_month_seconds(index)
    ok = np.isfinite(v)
    return float(np.sum(v[ok] * w[ok]) / np.sum(w[ok]))
