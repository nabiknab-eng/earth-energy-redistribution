"""Build observed global TOA and meridional-transport context figures.

CERES supplies full-globe solar and TOA radiation.  The mass-consistent ERA5
derived product supplies actual atmospheric total-energy transport globally.
The existing known-budget plus sea-ice estimate is overlaid only on its valid
30--85N domain; no Southern Hemisphere storage correction is inferred.
"""

from __future__ import annotations

import io
from pathlib import Path
import zipfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset, num2date
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import monthly_midpoints
from src.analyze_partial_transport import filter_flux_like_state
from src.energy_budget import (
    PW,
    area_weighted_global_mean,
    exact_month_seconds,
    implied_transport,
    implied_transport_from_north,
    ols_hac_trend,
    source_from_transport,
)
from src.process_era5 import integrate_parallel


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
TABLES = ROOT / "tables"
CERES = ROOT / "raw/ceres/ceres_ebaf_ed4.2.1_zonal_global_200003-202603.nc"
CLIM_START, CLIM_END = "2001-01", "2025-12"
COMMON_RAW_START, COMMON_RAW_END = "2005-01", "2022-12"
COMMON_FILTER_LABEL = "2006-01--2022-01"
GLOBAL_EDGES = np.arange(-90.0, 91.0)
TABLE_LATITUDES = (-60.0, -70.0, 0.0, 60.0, 70.0)


def _arr(ds: Dataset, name: str) -> np.ndarray:
    return np.asarray(np.ma.filled(ds[name][:], np.nan), dtype=float)


def _ceres_time(ds: Dataset) -> pd.DatetimeIndex:
    variable = ds["time"]
    dates = num2date(variable[:], variable.units, getattr(variable, "calendar", "standard"))
    return pd.DatetimeIndex([pd.Timestamp(date.year, date.month, 15) for date in dates])


def _roots(x: np.ndarray, y: np.ndarray) -> list[float]:
    roots = []
    for i in range(len(y) - 1):
        if y[i] == 0:
            roots.append(float(x[i]))
        elif y[i] * y[i + 1] < 0:
            roots.append(float(x[i] - y[i] * (x[i + 1] - x[i]) / (y[i + 1] - y[i])))
    return roots


def _day_weighted(field: np.ndarray, index: pd.DatetimeIndex) -> np.ndarray:
    return np.average(np.asarray(field), axis=0, weights=exact_month_seconds(index))


def _interpolate_profile(lat: np.ndarray, values: np.ndarray, target: float) -> float:
    return float(np.interp(target, lat, values))


def _interpolate_timeseries(lat: np.ndarray, values: np.ndarray, target: float) -> np.ndarray:
    i = int(np.searchsorted(lat, target))
    if i == 0:
        return values[:, 0]
    if i == len(lat):
        return values[:, -1]
    left, right = lat[i - 1], lat[i]
    weight = (target - left) / (right - left)
    return values[:, i - 1] * (1.0 - weight) + values[:, i] * weight


def load_ceres() -> dict:
    with Dataset(CERES) as ds:
        index = _ceres_time(ds)
        period = index.to_period("M")
        lat = _arr(ds, "lat")
        solar = _arr(ds, "zsolar_mon")
        sw_out = _arr(ds, "ztoa_sw_all_mon")
        olr = _arr(ds, "ztoa_lw_all_mon")
        net = _arr(ds, "ztoa_net_all_mon")

    climate_mask = (period >= CLIM_START) & (period <= CLIM_END)
    climate_index = index[climate_mask]
    if climate_mask.sum() != 300:
        raise RuntimeError("CERES complete-year climatology must contain 300 months")
    solar_clim = _day_weighted(solar[climate_mask], climate_index)
    sw_out_clim = _day_weighted(sw_out[climate_mask], climate_index)
    asr_clim = solar_clim - sw_out_clim
    olr_clim = _day_weighted(olr[climate_mask], climate_index)
    net_product_clim = _day_weighted(net[climate_mask], climate_index)
    net_clim = asr_clim - olr_clim
    net_component_closure_error = float(np.max(np.abs(net_product_clim - net_clim)))
    # CERES stores component and NET fields separately at packed precision.
    # The 25-year means agree much more closely than 0.01 W m-2, while the
    # plotted definition is kept algebraically exact as ASR - OLR.
    if net_component_closure_error > 0.005:
        raise RuntimeError("CERES packed NET versus ASR-OLR closure failed")

    long_edge, long_h_w = implied_transport(net_clim, lat, remove_global_mean=True)
    _, long_h_north_w = implied_transport_from_north(net_clim, lat, remove_global_mean=True)
    pre_clamp_north_pw = float(long_h_w[-1] / PW)
    long_h_w[[0, -1]] = 0.0

    common_mask = (period >= COMMON_RAW_START) & (period <= COMMON_RAW_END)
    common_net = net[common_mask]
    common_index = monthly_midpoints(COMMON_RAW_START, int(common_mask.sum()))
    raw_edge, raw_monthly_w = implied_transport(common_net, lat, remove_global_mean=True)
    if not np.array_equal(raw_edge, GLOBAL_EDGES):
        raise RuntimeError("CERES implied transport does not use integer latitude edges")
    pre_clamp_monthly_north_pw = float(np.max(np.abs(raw_monthly_w[:, -1] / PW)))
    raw_monthly_w[:, [0, -1]] = 0.0
    filtered_rows = []
    raw_summary_rows = []
    for column, boundary in enumerate(raw_edge):
        ftime, filtered_w = filter_flux_like_state(
            raw_monthly_w[:, column], common_index, "block_12m_means"
        )
        trend = ols_hac_trend(filtered_w / PW, ftime, maxlags=24)
        filtered_rows.extend(
            {"time": time, "latitude_deg": boundary, "raw_implied_pw": value / PW}
            for time, value in zip(ftime, filtered_w)
        )
        raw_summary_rows.append(
            {
                "latitude_deg": boundary,
                "mean_pw": float(np.mean(filtered_w / PW)),
                "trend_tw_dec": trend.slope_per_decade * 1000.0,
                "ci_low_tw_dec": trend.ci_low * 1000.0,
                "ci_high_tw_dec": trend.ci_high * 1000.0,
            }
        )
    raw_filtered = pd.DataFrame(filtered_rows)
    raw_summary = pd.DataFrame(raw_summary_rows)
    raw_filtered.to_csv(TABLES / "ceres_global_raw_implied_block_timeseries.csv", index=False)
    raw_summary.to_csv(TABLES / "ceres_global_raw_implied_summary.csv", index=False)

    ntoa_trends = []
    for target in TABLE_LATITUDES:
        series = _interpolate_timeseries(lat, net[climate_mask], target)
        trend = ols_hac_trend(series, climate_index, maxlags=24)
        ntoa_trends.append(
            {
                "latitude_deg": target,
                "trend_wm2_dec": trend.slope_per_decade,
                "ci_low_wm2_dec": trend.ci_low,
                "ci_high_wm2_dec": trend.ci_high,
            }
        )

    return {
        "lat": lat,
        "solar_clim": solar_clim,
        "asr_clim": asr_clim,
        "olr_clim": olr_clim,
        "net_clim": net_clim,
        "net_component_closure_error": net_component_closure_error,
        "global_net_clim": float(area_weighted_global_mean(net_clim, lat)),
        "zero_crossings": _roots(lat, net_clim),
        "effective_zero_crossings": _roots(lat, net_clim - area_weighted_global_mean(net_clim, lat)),
        "long_edge": long_edge,
        "long_h_pw": long_h_w / PW,
        "long_h_north_pw": long_h_north_w / PW,
        "pre_clamp_north_pw": pre_clamp_north_pw,
        "pre_clamp_monthly_north_pw": pre_clamp_monthly_north_pw,
        "raw_filtered": raw_filtered,
        "raw_summary": raw_summary,
        "ntoa_trends": pd.DataFrame(ntoa_trends),
    }


def _member_time(ds: Dataset) -> pd.Timestamp:
    variable = ds["time"]
    date = num2date(variable[0], variable.units, getattr(variable, "calendar", "standard"))
    return pd.Timestamp(date.year, date.month, 15)


def _zip_members(pattern: str):
    for path in sorted((ROOT / "raw/era5").glob(pattern)):
        with zipfile.ZipFile(path) as archive:
            for name in sorted(archive.namelist()):
                yield path, name, archive.read(name)


def reduce_global_era5_aht() -> tuple[pd.DataFrame, pd.DataFrame, float]:
    configurations = (
        ("aht_profile_90S_30N_*.zip", np.arange(-90.0, 30.0)),
        ("aht_profile_30_85N_*.zip", np.arange(30.0, 86.0)),
        ("aht_profile_85_90N_*.zip", np.arange(86.0, 91.0)),
    )
    records = []
    member_counts = []
    for pattern, targets in configurations:
        count = 0
        for _, _, payload in _zip_members(pattern):
            ds = Dataset("inmemory.nc", memory=payload)
            time = _member_time(ds)
            lat = _arr(ds, "latitude")
            lon = _arr(ds, "longitude")
            field = _arr(ds, "tefln")[0]
            for target in targets:
                latitude_index = int(np.argmin(np.abs(lat - target)))
                if abs(float(lat[latitude_index]) - target) > 1e-8:
                    raise RuntimeError(f"ERA5 subset {pattern} lacks {target} degree row")
                value = integrate_parallel(field[latitude_index], target, lon) / PW
                if abs(target) == 90.0:
                    value = 0.0
                records.append(
                    {"time": time, "latitude_deg": target, "actual_aht_pw": value}
                )
            count += 1
            ds.close()
        member_counts.append(count)
    if member_counts != [276, 276, 276]:
        raise RuntimeError(f"ERA5 global AHT member counts are incomplete: {member_counts}")
    monthly = pd.DataFrame(records).sort_values(["latitude_deg", "time"]).reset_index(drop=True)
    if len(monthly) != 276 * 181 or monthly.duplicated(["time", "latitude_deg"]).any():
        raise RuntimeError("ERA5 global AHT month/latitude grid is incomplete")
    midpoint = dict(
        zip(
            pd.period_range("2000-01", "2022-12", freq="M").astype(str),
            monthly_midpoints("2000-01", 276),
        )
    )
    monthly["time"] = pd.DatetimeIndex(monthly.time).to_period("M").astype(str).map(midpoint)
    monthly.to_csv(TABLES / "era5_global_aht_monthly.csv", index=False)

    existing = pd.read_csv(TABLES / "era5_transport_profile_monthly.csv", parse_dates=["time"])
    existing["month"] = pd.DatetimeIndex(existing.time).to_period("M").astype(str)
    compare = monthly[monthly.latitude_deg.between(30, 85)].copy()
    compare["month"] = pd.DatetimeIndex(compare.time).to_period("M").astype(str)
    merged = compare.merge(
        existing[["month", "boundary_deg_n", "aht_pw"]],
        left_on=["month", "latitude_deg"],
        right_on=["month", "boundary_deg_n"],
        validate="one_to_one",
    )
    overlap_error = float(np.max(np.abs(merged.actual_aht_pw - merged.aht_pw)))

    common = monthly[
        (pd.DatetimeIndex(monthly.time).to_period("M") >= COMMON_RAW_START)
        & (pd.DatetimeIndex(monthly.time).to_period("M") <= COMMON_RAW_END)
    ]
    series_rows = []
    summary_rows = []
    for latitude in GLOBAL_EDGES:
        b = common[common.latitude_deg == latitude].sort_values("time")
        index = pd.DatetimeIndex(b.time)
        ftime, filtered_w = filter_flux_like_state(
            b.actual_aht_pw.to_numpy() * PW, index, "block_12m_means"
        )
        trend = ols_hac_trend(filtered_w / PW, ftime, maxlags=24)
        series_rows.extend(
            {"time": time, "latitude_deg": latitude, "actual_aht_pw": value / PW}
            for time, value in zip(ftime, filtered_w)
        )
        summary_rows.append(
            {
                "latitude_deg": latitude,
                "mean_pw": float(np.mean(filtered_w / PW)),
                "trend_tw_dec": trend.slope_per_decade * 1000.0,
                "ci_low_tw_dec": trend.ci_low * 1000.0,
                "ci_high_tw_dec": trend.ci_high * 1000.0,
            }
        )
    filtered = pd.DataFrame(series_rows)
    summary = pd.DataFrame(summary_rows)
    filtered.to_csv(TABLES / "era5_global_aht_block_timeseries.csv", index=False)
    summary.to_csv(TABLES / "era5_global_aht_summary.csv", index=False)
    return filtered, summary, overlap_error


def build_context_table(ceres: dict, era: pd.DataFrame, hsi: pd.DataFrame) -> pd.DataFrame:
    raw = ceres["raw_summary"].set_index("latitude_deg")
    era = era.set_index("latitude_deg")
    hsi = hsi.set_index("boundary_deg_n")
    ntoa_trends = ceres["ntoa_trends"].set_index("latitude_deg")
    rows = []
    for latitude in TABLE_LATITUDES:
        ntoa = _interpolate_profile(ceres["lat"], ceres["net_clim"], latitude)
        solar = _interpolate_profile(ceres["lat"], ceres["solar_clim"], latitude)
        asr = _interpolate_profile(ceres["lat"], ceres["asr_clim"], latitude)
        olr = _interpolate_profile(ceres["lat"], ceres["olr_clim"], latitude)
        actual_available = latitude in era.index
        hsi_available = latitude in hsi.index
        rows.append(
            {
                "latitude_label": "Equator" if latitude == 0 else f"{abs(int(latitude))}deg{'N' if latitude > 0 else 'S'}",
                "latitude_deg": latitude,
                "incoming_solar_climatology_wm2": solar,
                "asr_climatology_wm2": asr,
                "olr_climatology_wm2": olr,
                "ntoa_climatology_wm2": ntoa,
                "ntoa_trend_wm2_dec": ntoa_trends.loc[latitude].trend_wm2_dec,
                "ntoa_trend_ci_low_wm2_dec": ntoa_trends.loc[latitude].ci_low_wm2_dec,
                "ntoa_trend_ci_high_wm2_dec": ntoa_trends.loc[latitude].ci_high_wm2_dec,
                "ntoa_period": f"{CLIM_START}--{CLIM_END}",
                "raw_implied_climatology_pw": raw.loc[latitude].mean_pw,
                "raw_implied_trend_tw_dec": raw.loc[latitude].trend_tw_dec,
                "raw_implied_trend_ci_low_tw_dec": raw.loc[latitude].ci_low_tw_dec,
                "raw_implied_trend_ci_high_tw_dec": raw.loc[latitude].ci_high_tw_dec,
                "actual_aht_climatology_pw": era.loc[latitude].mean_pw if actual_available else np.nan,
                "actual_aht_trend_tw_dec": era.loc[latitude].trend_tw_dec if actual_available else np.nan,
                "actual_aht_trend_ci_low_tw_dec": era.loc[latitude].ci_low_tw_dec if actual_available else np.nan,
                "actual_aht_trend_ci_high_tw_dec": era.loc[latitude].ci_high_tw_dec if actual_available else np.nan,
                "h_known_plus_sea_ice_climatology_pw": hsi.loc[latitude].h_known_plus_sea_ice_mean_pw if hsi_available else np.nan,
                "h_known_plus_sea_ice_trend_tw_dec": hsi.loc[latitude].h_known_plus_sea_ice_trend_tw_dec if hsi_available else np.nan,
                "h_known_plus_sea_ice_trend_ci_low_tw_dec": hsi.loc[latitude].h_known_plus_sea_ice_ci_low_tw_dec if hsi_available else np.nan,
                "h_known_plus_sea_ice_trend_ci_high_tw_dec": hsi.loc[latitude].h_known_plus_sea_ice_ci_high_tw_dec if hsi_available else np.nan,
                "transport_period": COMMON_FILTER_LABEL,
                "actual_aht_availability": "global ERA5 available",
                "h_known_plus_sea_ice_availability": "available only for 30--85N" if hsi_available else "not computed outside 30--85N",
                "transport_sign_convention": "positive northward; negative southward",
            }
        )
    table = pd.DataFrame(rows)
    table.to_csv(OUT / "global_energy_context_table.csv", index=False)
    return table


def _global_axis(ax) -> None:
    ticks = [-90, -60, -30, 0, 30, 60, 90]
    labels = ["90°S", "60°S", "30°S", "0°", "30°N", "60°N", "90°N"]
    ax.set_xlim(-90, 90)
    ax.set_xticks(ticks, labels)
    ax.axvline(0, color="0.75", lw=0.7)


def make_figures(ceres: dict, era: pd.DataFrame, hsi: pd.DataFrame) -> None:
    raw = ceres["raw_summary"].set_index("latitude_deg").loc[GLOBAL_EDGES]
    era = era.set_index("latitude_deg").loc[GLOBAL_EDGES]
    hsi = hsi.set_index("boundary_deg_n")
    hlat = hsi.index.to_numpy()
    zero_crossings = ceres["zero_crossings"]

    fig, axes = plt.subplots(3, 1, figsize=(12.5, 14), sharex=True)
    ax = axes[0]
    ax.plot(ceres["lat"], ceres["solar_clim"], color="#e69f00", lw=2.3)
    ax.fill_between(ceres["lat"], 0, ceres["solar_clim"], color="#f6c85f", alpha=0.22)
    ax.set_ylabel(r"$S_{in}$ (W m$^{-2}$)")
    ax.set_title("A — Incoming solar flux at TOA before reflection\nCERES EBAF Ed4.2.1, 2001–2025 complete-year climatology")
    ax.text(0.01, 0.05, "Not ASR: geometrically incident solar power at the top of atmosphere", transform=ax.transAxes, fontsize=9)

    ax = axes[1]
    ax.plot(ceres["lat"], ceres["asr_clim"], color="#d89000", lw=1.9, label="ASR = incoming solar − reflected SW")
    ax.plot(ceres["lat"], ceres["olr_clim"], color="#6a3d9a", lw=1.9, label="OLR")
    ax.plot(ceres["lat"], ceres["net_clim"], color="black", lw=2.0, label=r"$N_{TOA}$ = ASR − OLR")
    ax.fill_between(ceres["lat"], 0, ceres["net_clim"], where=ceres["net_clim"] >= 0, color="#d73027", alpha=0.18, label="radiative surplus")
    ax.fill_between(ceres["lat"], 0, ceres["net_clim"], where=ceres["net_clim"] < 0, color="#4575b4", alpha=0.18, label="radiative deficit")
    ax.axhline(0, color="0.35", lw=0.8)
    for root in zero_crossings:
        ax.axvline(root, color="0.25", lw=0.8, ls=":")
        ax.annotate(f"N=0 at {root:+.1f}°", (root, 0), xytext=(4, 7), textcoords="offset points", rotation=90, fontsize=8)
    ax.set_ylabel(r"TOA flux (W m$^{-2}$)")
    ax.set_title("B — Observed zonal TOA radiation budget")
    ax.legend(frameon=False, ncol=2, fontsize=8.5)

    ax = axes[2]
    ax.plot(GLOBAL_EDGES, raw.mean_pw, color="#555555", lw=2.2, label="CERES raw implied total transport")
    ax.plot(GLOBAL_EDGES, era.mean_pw, color="#d95f02", lw=2.0, label="actual ERA5 atmospheric transport")
    ax.plot(hlat, hsi.h_known_plus_sea_ice_mean_pw, color="#08306b", lw=2.0, ls="--", label=r"$H_{known+SI}$ (30–85°N only)")
    ax.axhline(0, color="black", lw=0.8)
    raw_min = raw.mean_pw.idxmin(); raw_max = raw.mean_pw.idxmax()
    ax.scatter([raw_min, raw_max, 0], [raw.loc[raw_min].mean_pw, raw.loc[raw_max].mean_pw, raw.loc[0].mean_pw], color="#555555", s=25, zorder=4)
    ax.annotate(f"{raw.loc[raw_min].mean_pw:.2f} PW at {abs(raw_min):.0f}°S", (raw_min, raw.loc[raw_min].mean_pw), xytext=(-55, -16), textcoords="offset points", fontsize=8)
    ax.annotate(f"{raw.loc[raw_max].mean_pw:.2f} PW at {raw_max:.0f}°N", (raw_max, raw.loc[raw_max].mean_pw), xytext=(6, 8), textcoords="offset points", fontsize=8)
    ax.annotate(f"CE {raw.loc[0].mean_pw:+.2f} PW", (0, raw.loc[0].mean_pw), xytext=(7, 9), textcoords="offset points", fontsize=8)
    ax.set_ylabel("Transport across latitude (PW)")
    ax.set_xlabel("Latitude")
    ax.set_title("C — Climatological meridional energy transport, common 2006-01–2022-01 block-filtered period\nPositive = northward, negative = southward; H is a total flux across a parallel")
    ax.legend(frameon=False, ncol=2, fontsize=8.5)
    for panel in axes:
        _global_axis(panel)
    fig.suptitle("Observed global zonal energy budget and meridional redistribution", fontsize=16, y=0.995)
    fig.tight_layout()
    fig.savefig(OUT / "global_energy_budget_three_panel.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(2, 1, figsize=(12, 9), sharex=True)
    ax = axes[0]
    ax.plot(GLOBAL_EDGES, raw.mean_pw, color="#555555", lw=2.2, label="CERES raw implied total")
    ax.plot(GLOBAL_EDGES, era.mean_pw, color="#d95f02", lw=2.0, label="actual ERA5 AHT")
    ax.plot(hlat, hsi.h_known_plus_sea_ice_mean_pw, color="#08306b", lw=2.0, ls="--", label=r"$H_{known+SI}$ (30–85°N)")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_ylabel("Climatological transport (PW)")
    ax.set_title("Large background flow: common-period climatology")
    ax.legend(frameon=False, ncol=3, fontsize=8.5)
    ax.text(0.01, 0.05, "1 PW = 1000 TW", transform=ax.transAxes, fontsize=11, weight="bold")

    ax = axes[1]
    ax.plot(GLOBAL_EDGES, raw.trend_tw_dec, color="#555555", lw=2.0, label="CERES raw implied trend")
    ax.plot(GLOBAL_EDGES, era.trend_tw_dec, color="#d95f02", lw=1.9, label="actual ERA5 AHT trend")
    ax.plot(hlat, hsi.h_known_plus_sea_ice_trend_tw_dec, color="#08306b", lw=2.0, ls="--", label=r"$H_{known+SI}$ trend (30–85°N)")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_ylabel(r"Trend (TW decade$^{-1}$)")
    ax.set_xlabel("Latitude")
    ax.set_title("Small perturbation: 2006-01–2022-01 OLS-HAC best-estimate trends")
    ax.legend(frameon=False, ncol=3, fontsize=8.5)
    for panel in axes:
        _global_axis(panel)
    fig.suptitle("Climatological transport versus CERES-era trend\nPositive = northward; negative = southward", fontsize=15, y=0.995)
    fig.tight_layout()
    fig.savefig(OUT / "climatology_vs_trend_transport.png", dpi=200)
    plt.close(fig)


def diagnostics(ceres: dict, era: pd.DataFrame, hsi: pd.DataFrame, overlap_error: float) -> pd.DataFrame:
    long_h = ceres["long_h_pw"]
    north_h = ceres["long_h_north_pw"]
    effective_source = ceres["net_clim"] - ceres["global_net_clim"]
    reconstruction = source_from_transport(long_h * PW, ceres["lat"])
    raw = ceres["raw_summary"].set_index("latitude_deg")
    era_idx = era.set_index("latitude_deg")
    rows = [
        {"diagnostic": "CERES packed NET versus ASR-OLR climatology", "value": ceres["net_component_closure_error"], "unit": "W m-2", "status": "PASS" if ceres["net_component_closure_error"] < 0.005 else "FAIL"},
        {"diagnostic": "CERES raw implied south pole", "value": long_h[0], "unit": "PW", "status": "PASS" if long_h[0] == 0 else "FAIL"},
        {"diagnostic": "CERES raw implied north pole", "value": long_h[-1], "unit": "PW", "status": "PASS" if long_h[-1] == 0 else "FAIL"},
        {"diagnostic": "CERES pre-clamp north-pole roundoff", "value": abs(ceres["pre_clamp_north_pw"]), "unit": "PW", "status": "PASS" if abs(ceres["pre_clamp_north_pw"]) < 1e-12 else "FAIL"},
        {"diagnostic": "CERES monthly pre-clamp north-pole max roundoff", "value": ceres["pre_clamp_monthly_north_pw"], "unit": "PW", "status": "PASS" if ceres["pre_clamp_monthly_north_pw"] < 1e-12 else "FAIL"},
        {"diagnostic": "south-to-north versus north-to-south integration", "value": float(np.max(np.abs(long_h - north_h))), "unit": "PW", "status": "PASS" if np.max(np.abs(long_h - north_h)) < 1e-12 else "FAIL"},
        {"diagnostic": "finite-volume derivative/source reconstruction", "value": float(np.max(np.abs(reconstruction - effective_source))), "unit": "W m-2", "status": "PASS" if np.max(np.abs(reconstruction - effective_source)) < 1e-10 else "FAIL"},
        {"diagnostic": "ERA5 global profile overlap with validated 30-85N subset", "value": overlap_error, "unit": "PW", "status": "PASS" if overlap_error < 1e-10 else "FAIL"},
        {"diagnostic": "ERA5 AHT south pole", "value": era_idx.loc[-90.0].mean_pw, "unit": "PW", "status": "PASS" if era_idx.loc[-90.0].mean_pw == 0 else "FAIL"},
        {"diagnostic": "ERA5 AHT north pole", "value": era_idx.loc[90.0].mean_pw, "unit": "PW", "status": "PASS" if era_idx.loc[90.0].mean_pw == 0 else "FAIL"},
    ]
    hsi_idx = hsi.set_index("boundary_deg_n")
    for latitude in (30.0, 60.0, 70.0, 85.0):
        difference = abs(raw.loc[latitude].mean_pw - pd.read_csv(OUT / "transport_profile_best_estimates.csv").set_index("boundary_deg_n").loc[latitude].raw_implied_mean_pw)
        rows.append({"diagnostic": f"global CERES versus existing NH raw mean at {latitude:g}N", "value": difference, "unit": "PW", "status": "PASS" if difference < 1e-10 else "FAIL"})
        if not np.isfinite(hsi_idx.loc[latitude].h_known_plus_sea_ice_mean_pw):
            raise RuntimeError("H_known+SI overlay contains non-finite data")
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "global_energy_context_diagnostics.csv", index=False)
    if (out.status != "PASS").any():
        raise RuntimeError("global energy context technical diagnostics failed")
    return out


def summary_metrics(ceres: dict, era: pd.DataFrame) -> pd.DataFrame:
    raw = ceres["raw_summary"].set_index("latitude_deg")
    era = era.set_index("latitude_deg")
    metrics = []
    for name, frame in [("CERES raw implied total", raw), ("actual ERA5 atmospheric", era)]:
        minimum_lat = float(frame.mean_pw.idxmin())
        maximum_lat = float(frame.mean_pw.idxmax())
        metrics.extend(
            [
                {"metric": f"{name}: maximum southward transport", "value": float(frame.loc[minimum_lat].mean_pw), "unit": "PW", "latitude_deg": minimum_lat, "period": COMMON_FILTER_LABEL},
                {"metric": f"{name}: maximum northward transport", "value": float(frame.loc[maximum_lat].mean_pw), "unit": "PW", "latitude_deg": maximum_lat, "period": COMMON_FILTER_LABEL},
                {"metric": f"{name}: cross-equatorial transport", "value": float(frame.loc[0.0].mean_pw), "unit": "PW", "latitude_deg": 0.0, "period": COMMON_FILTER_LABEL},
            ]
        )
    for i, root in enumerate(ceres["zero_crossings"], 1):
        metrics.append({"metric": f"CERES N_TOA zero crossing {i}", "value": root, "unit": "degrees latitude", "latitude_deg": root, "period": f"{CLIM_START}--{CLIM_END}"})
    for i, root in enumerate(ceres["effective_zero_crossings"], 1):
        metrics.append({"metric": f"CERES mean-removed N_TOA zero crossing {i}", "value": root, "unit": "degrees latitude", "latitude_deg": root, "period": f"{CLIM_START}--{CLIM_END}"})
    metrics.append({"metric": "CERES global mean N_TOA", "value": ceres["global_net_clim"], "unit": "W m-2", "latitude_deg": np.nan, "period": f"{CLIM_START}--{CLIM_END}"})
    table = pd.DataFrame(metrics)
    table.to_csv(OUT / "global_energy_context_summary_metrics.csv", index=False)
    return table


def main() -> None:
    ceres = load_ceres()
    _, era_summary, overlap_error = reduce_global_era5_aht()
    hsi = pd.read_csv(OUT / "transport_profile_best_estimates.csv")
    build_context_table(ceres, era_summary, hsi)
    make_figures(ceres, era_summary, hsi)
    check = diagnostics(ceres, era_summary, hsi, overlap_error)
    metrics = summary_metrics(ceres, era_summary)
    print(check.to_string(index=False))
    print("\nGlobal energy context metrics:\n" + metrics.to_string(index=False))


if __name__ == "__main__":
    main()
