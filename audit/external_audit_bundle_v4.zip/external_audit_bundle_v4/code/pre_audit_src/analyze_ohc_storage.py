"""Stage 2: regional 0-2000 m ocean-heat storage and its tendency."""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset
import numpy as np
import pandas as pd

from src.energy_budget import EARTH_AREA, ols_hac_trend, zonal_band_areas


ROOT = Path(__file__).resolve().parents[1]
INFILE = ROOT / "raw/ohc/heat_content_anomaly_0-2000_monthly_20260707.nc"
SECONDS_PER_DAY = 86400.0
BANDS = [
    ("band_90S_60S", -90.0, -60.0),
    ("band_60S_42S", -60.0, -42.0),
    ("band_42S_20S", -42.0, -20.0),
    ("band_20S_0", -20.0, 0.0),
    ("band_0_20N", 0.0, 20.0),
    ("band_20_42N", 20.0, 42.0),
    ("band_42_60N", 42.0, 60.0),
    ("band_60_65N", 60.0, 65.0),
    ("band_65_70N", 65.0, 70.0),
    ("band_70_90N", 70.0, 90.0),
]


def monthly_midpoints(start: str, count: int) -> pd.DatetimeIndex:
    periods = pd.period_range(start, periods=count, freq="M")
    starts = periods.to_timestamp(how="start")
    ends = (periods + 1).to_timestamp(how="start")
    return pd.DatetimeIndex([a + (b - a) / 2 for a, b in zip(starts, ends)])


def _mean_timestamp(index: pd.DatetimeIndex) -> pd.Timestamp:
    """Mean timestamp without assuming pandas' internal datetime resolution."""
    origin = index[0]
    mean_seconds = float(np.mean([(stamp - origin).total_seconds() for stamp in index]))
    return origin + pd.to_timedelta(mean_seconds, unit="s")


def block_mean_tendency(values_j: np.ndarray, index: pd.DatetimeIndex, block: int = 12) -> tuple[pd.DatetimeIndex, np.ndarray]:
    """Mayer-style difference of following and preceding block means in W."""
    y = np.asarray(values_j, dtype=float)
    dates, out = [], []
    for t in range(block, len(y) - block + 1):
        previous = y[t - block : t]
        following = y[t : t + block]
        previous_center = _mean_timestamp(index[t - block : t])
        following_center = _mean_timestamp(index[t : t + block])
        dt_seconds = (following_center - previous_center).total_seconds()
        out.append((np.mean(following) - np.mean(previous)) / dt_seconds)
        # Associate the filtered derivative with the named month whose
        # following 12-month block begins here, matching Mayer et al.
        dates.append(index[t])
    return pd.DatetimeIndex(dates), np.asarray(out)


def central_span_tendency(values_j: np.ndarray, index: pd.DatetimeIndex, halfspan: int = 6) -> tuple[pd.DatetimeIndex, np.ndarray]:
    """Unsmoothed centered endpoint difference over a 12-month span, in W."""
    y = np.asarray(values_j, dtype=float)
    dates, out = [], []
    for t in range(halfspan, len(y) - halfspan):
        dt_seconds = (index[t + halfspan] - index[t - halfspan]).total_seconds()
        out.append((y[t + halfspan] - y[t - halfspan]) / dt_seconds)
        dates.append(index[t])
    return pd.DatetimeIndex(dates), np.asarray(out)


def region_mask(lat: np.ndarray, valid: np.ndarray, lo: float, hi: float) -> np.ndarray:
    return valid & ((lat[:, None] >= lo) & (lat[:, None] < hi))


def main() -> None:
    with Dataset(INFILE) as ds:
        time_raw = np.asarray(ds["time"][:], dtype=float)
        bounds = np.asarray(ds["climatology_bounds"][:], dtype=float)
        lat = np.asarray(ds["lat"][:], dtype=float)
        lon = np.asarray(ds["lon"][:], dtype=float)
        basin = np.asarray(np.ma.filled(ds["basin_mask"][:], -100), dtype=int)
        h_ma = ds["h18_hc"][:, 0, :, :]
        mask = np.ma.getmaskarray(h_ma)
        h18 = np.asarray(np.ma.filled(h_ma, 0.0), dtype=float)
        native_global_h22 = np.asarray(ds["month_h22_WO"][:], dtype=float)

    if len(time_raw) != 255 or not np.allclose(time_raw, np.arange(255) + 0.5):
        raise RuntimeError("unexpected NCEI monthly time coordinate")
    if not np.allclose(bounds[:, 0], np.arange(255)) or not np.allclose(bounds[:, 1], np.arange(255) + 1):
        raise RuntimeError("unexpected NCEI monthly time bounds")
    index = monthly_midpoints("2005-01", len(time_raw))
    if str(index[0].to_period("M")) != "2005-01" or str(index[-1].to_period("M")) != "2026-03":
        raise RuntimeError("manually decoded NCEI coverage is wrong")
    if np.any(mask != mask[0]):
        raise RuntimeError("NCEI OHC valid-cell mask changes with time")
    valid = ~mask[0]

    # Product-integral unit test: h18_hc is extensive cell energy.  Basin mask
    # 1-3 excludes 500 valid marginal/Arctic-sea cells used in regional budgets.
    major_basins = np.isin(basin, [1, 2, 3])
    reconstructed_h22 = np.sum(h18[:, major_basins], axis=1) * 1e-4
    basin_residual_h22 = reconstructed_h22 - native_global_h22
    basin_residual_rms = float(np.sqrt(np.mean(basin_residual_h22**2)))
    basin_scale = float(np.std(native_global_h22))
    if basin_residual_rms / basin_scale > 0.003:
        raise RuntimeError("cell-energy sum does not reproduce supplied global integral")

    lat_band_area = zonal_band_areas(lat)
    cell_area = np.repeat((lat_band_area / len(lon))[:, None], len(lon), axis=1)
    all_grid_energy_j = np.sum(h18, axis=(1, 2)) * 1e18

    specs: list[dict] = []
    for name, lo, hi in BANDS:
        specs.append({"region": name, "kind": "band", "lo": lo, "hi": hi})
    for boundary in (60.0, 65.0, 70.0):
        specs.append({"region": f"cap_{int(boundary)}N", "kind": "cap", "lo": boundary, "hi": 90.0})
    specs.append({"region": "global_ocean", "kind": "global", "lo": -90.0, "hi": 90.0})

    monthly = pd.DataFrame({"time": index})
    metadata_rows = []
    region_energy: dict[str, np.ndarray] = {}
    for spec in specs:
        rmask = region_mask(lat, valid, spec["lo"], spec["hi"])
        full_lat = (lat >= spec["lo"]) & (lat < spec["hi"])
        total_area = float(lat_band_area[full_lat].sum())
        sampled_ocean_area = float(cell_area[rmask].sum())
        energy = np.sum(h18[:, rmask], axis=1) * 1e18
        region_energy[spec["region"]] = energy
        monthly[f"{spec['region']}_j"] = energy
        metadata_rows.append(
            {
                **spec,
                "total_region_area_m2": total_area,
                "sampled_ocean_area_m2": sampled_ocean_area,
                "sampled_ocean_fraction_of_region": sampled_ocean_area / total_area,
                "valid_cells": int(rmask.sum()),
            }
        )
    metadata = pd.DataFrame(metadata_rows)

    band_names = [x[0] for x in BANDS]
    band_sum = np.sum(np.column_stack([region_energy[x] for x in band_names]), axis=1)
    relative_band_closure = float(np.max(np.abs(band_sum - all_grid_energy_j)) / np.max(np.abs(all_grid_energy_j)))
    if relative_band_closure > 1e-12:
        raise RuntimeError("latitude bands do not reconstruct gridded OHC")

    monthly.to_csv(ROOT / "tables/ohc_region_monthly_energy_j.csv", index=False)
    metadata.to_csv(ROOT / "tables/ohc_region_metadata.csv", index=False)
    metadata.to_csv(ROOT / "outputs/ohc_region_metadata.csv", index=False)

    block_frame = None
    central_frame = None
    summary_rows = []
    sensitivity_rows = []
    for spec in specs:
        name = spec["region"]
        meta = metadata.loc[metadata.region == name].iloc[0]
        btime, bw = block_mean_tendency(region_energy[name], index)
        ctime, cw = central_span_tendency(region_energy[name], index)
        if block_frame is None:
            block_frame = pd.DataFrame({"time": btime})
            central_frame = pd.DataFrame({"time": ctime})
        if not btime.equals(pd.DatetimeIndex(block_frame.time)) or not ctime.equals(pd.DatetimeIndex(central_frame.time)):
            raise RuntimeError("inconsistent tendency timestamps")
        block_frame[f"{name}_pw"] = bw / 1e15
        block_frame[f"{name}_wm2_total_area"] = bw / meta.total_region_area_m2
        block_frame[f"{name}_wm2_sampled_ocean"] = bw / meta.sampled_ocean_area_m2
        central_frame[f"{name}_pw"] = cw / 1e15
        central_frame[f"{name}_wm2_total_area"] = cw / meta.total_region_area_m2

        for window, start, end in [
            ("full_OHC_filter", "2006-01-01", "2025-12-31"),
            ("common_ERA5", "2006-01-01", "2022-12-31"),
        ]:
            for method_name, times, watts in [("block_12m_means", btime, bw), ("central_12m_endpoints", ctime, cw)]:
                selected = (times >= start) & (times <= end)
                values = watts[selected] / meta.total_region_area_m2
                method_trend = ols_hac_trend(values, times[selected], maxlags=24)
                sensitivity_rows.append(
                    {
                        "region": name,
                        "window": window,
                        "method": method_name,
                        "start": str(times[selected][0].date()),
                        "end": str(times[selected][-1].date()),
                        "n_months": int(selected.sum()),
                        "mean_storage_wm2_total_area": float(np.mean(values)),
                        "storage_trend_wm2_dec": method_trend.slope_per_decade,
                        "storage_trend_ci_low_wm2_dec": method_trend.ci_low,
                        "storage_trend_ci_high_wm2_dec": method_trend.ci_high,
                    }
                )

        for window, start, end in [
            ("full_OHC_filter", "2006-01-01", "2025-12-31"),
            ("common_ERA5", "2006-01-01", "2022-12-31"),
        ]:
            use = (btime >= start) & (btime <= end)
            values_wm2 = bw[use] / meta.total_region_area_m2
            tr = ols_hac_trend(values_wm2, btime[use], maxlags=24)
            summary_rows.append(
                {
                    "region": name,
                    "kind": spec["kind"],
                    "window": window,
                    "start": str(btime[use][0].date()),
                    "end": str(btime[use][-1].date()),
                    "n_months": int(use.sum()),
                    "mean_storage_pw": float(np.mean(bw[use]) / 1e15),
                    "mean_storage_wm2_total_area": float(np.mean(values_wm2)),
                    "mean_storage_wm2_sampled_ocean": float(np.mean(bw[use]) / meta.sampled_ocean_area_m2),
                    "storage_trend_wm2_dec": tr.slope_per_decade,
                    "storage_trend_se_wm2_dec": tr.se_per_decade,
                    "storage_trend_ci_low_wm2_dec": tr.ci_low,
                    "storage_trend_ci_high_wm2_dec": tr.ci_high,
                    "storage_trend_tw_dec": tr.slope_per_decade * meta.total_region_area_m2 / 1e12,
                    "method": "difference of following and preceding 12-month mean OHC; exact centroid dt; OLS-HAC(24)",
                }
            )

    assert block_frame is not None and central_frame is not None
    block_frame.to_csv(ROOT / "tables/ohc_block_tendency.csv", index=False)
    block_frame.to_csv(ROOT / "outputs/ohc_block_tendency.csv", index=False)
    central_frame.to_csv(ROOT / "tables/ohc_central12_tendency.csv", index=False)
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(ROOT / "tables/ohc_storage_summary.csv", index=False)
    summary.to_csv(ROOT / "outputs/ohc_storage_summary.csv", index=False)
    sensitivity = pd.DataFrame(sensitivity_rows)
    sensitivity.to_csv(ROOT / "tables/ohc_storage_method_sensitivity.csv", index=False)
    sensitivity.to_csv(ROOT / "outputs/ohc_storage_method_sensitivity.csv", index=False)

    diagnostics = pd.DataFrame(
        [
            {"diagnostic": "fixed valid-cell mask", "value": int(valid.sum()), "unit": "cells", "status": "PASS"},
            {"diagnostic": "major-basin cell sum vs native global integral RMS", "value": basin_residual_rms, "unit": "1e22 J", "status": "PASS"},
            {"diagnostic": "major-basin closure RMS / native temporal SD", "value": basin_residual_rms / basin_scale, "unit": "fraction", "status": "PASS"},
            {"diagnostic": "all latitude bands vs full finite grid max relative residual", "value": relative_band_closure, "unit": "fraction", "status": "PASS"},
        ]
    )
    diagnostics.to_csv(ROOT / "tables/ohc_technical_diagnostics.csv", index=False)
    diagnostics.to_csv(ROOT / "outputs/ohc_technical_diagnostics.csv", index=False)

    # Global and Arctic time series in a common whole-region W m-2 convention.
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.2), sharex=True)
    axes[0].plot(block_frame.time, block_frame.global_ocean_wm2_total_area, color="black", lw=1.2)
    axes[0].axhline(0, color="0.6", lw=0.8)
    axes[0].set(ylabel="W m$^{-2}$ Earth area", title="NCEI 0–2000 m global ocean storage tendency")
    for name, color in [("cap_60N", "#1f77b4"), ("cap_65N", "#2a9d8f"), ("cap_70N", "#6a4c93")]:
        axes[1].plot(block_frame.time, block_frame[f"{name}_wm2_total_area"], label=name.replace("cap_", "≥"), color=color, lw=1.1)
    axes[1].axhline(0, color="0.6", lw=0.8)
    axes[1].set(xlabel="Tendency reference month", ylabel="W m$^{-2}$ cap area", title="Arctic-cap ocean storage tendency")
    axes[1].legend(frameon=False, ncol=3)
    fig.suptitle("Mayer-style 12-month block-mean difference; NCEI monthly OHC")
    fig.tight_layout()
    for path in [ROOT / "figures/ohc_storage_tendency_timeseries.png", ROOT / "outputs/ohc_storage_tendency_timeseries.png"]:
        fig.savefig(path, dpi=180)
    plt.close(fig)

    band_full = summary[(summary.kind == "band") & (summary.window == "full_OHC_filter")].copy()
    labels = [x.replace("band_", "").replace("_", "–") for x in band_full.region]
    x = np.arange(len(band_full))
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.4), sharex=True)
    axes[0].bar(x, band_full.mean_storage_pw * 1000, color="#287271")
    axes[0].axhline(0, color="0.6", lw=0.8)
    axes[0].set(ylabel="Mean storage rate (TW)", title="Mean 0–2000 m ocean heat uptake by latitude band")
    y = band_full.storage_trend_tw_dec.to_numpy()
    # Use asymmetric CI converted with region areas from metadata.
    areas = band_full.region.map(metadata.set_index("region").total_region_area_m2).to_numpy()
    ci_lo_tw = band_full.storage_trend_ci_low_wm2_dec.to_numpy() * areas / 1e12
    ci_hi_tw = band_full.storage_trend_ci_high_wm2_dec.to_numpy() * areas / 1e12
    axes[1].bar(x, y, color="#d17a22")
    axes[1].errorbar(x, y, yerr=np.vstack([y - ci_lo_tw, ci_hi_tw - y]), fmt="none", ecolor="black", capsize=3)
    axes[1].axhline(0, color="0.6", lw=0.8)
    axes[1].set(ylabel="Trend in storage rate\n(TW decade$^{-1}$)", title="Change in ocean storage tendency (HAC 95% CI)")
    axes[1].set_xticks(x, labels, rotation=35, ha="right")
    fig.suptitle("NCEI 0–2000 m OHC, block filter, 2006-01–2025-04")
    fig.tight_layout()
    for path in [ROOT / "figures/ohc_band_storage.png", ROOT / "outputs/ohc_band_storage.png"]:
        fig.savefig(path, dpi=180)
    plt.close(fig)

    print(f"coverage: {index[0]:%Y-%m} to {index[-1]:%Y-%m}; n={len(index)}")
    print(f"fixed valid cells: {valid.sum()}; marginal/Arctic valid cells outside major basin mask: {(valid & ~major_basins).sum()}")
    print(f"major-basin closure RMS: {basin_residual_rms:.6f} x10^22 J ({basin_residual_rms / basin_scale:.6%} of temporal SD)")
    print(f"block tendency coverage: {block_frame.time.iloc[0]:%Y-%m} to {block_frame.time.iloc[-1]:%Y-%m}; n={len(block_frame)}")
    show = summary[(summary.window == "full_OHC_filter") & summary.region.isin(["global_ocean", "cap_60N", "cap_65N", "cap_70N", "band_20_42N"])]
    print("\nKey storage summary:\n" + show.to_string(index=False))


if __name__ == "__main__":
    main()
