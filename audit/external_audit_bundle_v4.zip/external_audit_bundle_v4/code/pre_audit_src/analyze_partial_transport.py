"""Stage 3: OHC-storage-corrected partial meridional transport into Arctic caps."""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset, num2date
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints
from src.energy_budget import PW, cap_area, implied_transport, ols_hac_trend, zonal_band_areas


ROOT = Path(__file__).resolve().parents[1]
CERES = ROOT / "raw/ceres/ceres_ebaf_ed4.2.1_zonal_global_200003-202603.nc"
OHC_MONTHLY = ROOT / "tables/ohc_region_monthly_energy_j.csv"
BOUNDARIES = (60.0, 65.0, 70.0)


def arr(ds: Dataset, name: str) -> np.ndarray:
    return np.asarray(np.ma.filled(ds[name][:], np.nan), dtype=float)


def monthly_flux_to_midpoint_energy(flux_w: np.ndarray, index: pd.DatetimeIndex) -> np.ndarray:
    """Accumulate monthly-mean power to an energy state at each month midpoint."""
    power = np.asarray(flux_w, dtype=float)
    if len(power) != len(index):
        raise ValueError("flux and time lengths differ")
    periods = index.to_period("M")
    starts = periods.to_timestamp(how="start")
    ends = (periods + 1).to_timestamp(how="start")
    seconds = np.asarray([(b - a).total_seconds() for a, b in zip(starts, ends)])
    prior = np.concatenate([[0.0], np.cumsum(power[:-1] * seconds[:-1])])
    return prior + 0.5 * power * seconds


def filter_flux_like_state(flux_w: np.ndarray, index: pd.DatetimeIndex, method: str) -> tuple[pd.DatetimeIndex, np.ndarray]:
    energy = monthly_flux_to_midpoint_energy(flux_w, index)
    if method == "block_12m_means":
        return block_mean_tendency(energy, index)
    if method == "central_12m_endpoints":
        return central_span_tendency(energy, index)
    raise ValueError(f"unknown method {method}")


def ceres_index(ds: Dataset) -> pd.DatetimeIndex:
    tv = ds["time"]
    dates = num2date(tv[:], tv.units, getattr(tv, "calendar", "standard"))
    return pd.DatetimeIndex([pd.Timestamp(d.year, d.month, 15) for d in dates])


def summarize_metric(
    rows: list[dict],
    boundary: float,
    window: str,
    method: str,
    metric: str,
    values_pw: np.ndarray,
    index: pd.DatetimeIndex,
    use: np.ndarray,
) -> None:
    trend = ols_hac_trend(values_pw[use], index[use], maxlags=24)
    area = cap_area(boundary)
    rows.append(
        {
            "boundary_deg_n": boundary,
            "window": window,
            "filter": method,
            "metric": metric,
            "start": str(index[use][0].date()),
            "end": str(index[use][-1].date()),
            "n_months": int(use.sum()),
            "mean_pw": float(np.mean(values_pw[use])),
            "trend_pw_dec": trend.slope_per_decade,
            "trend_tw_dec": trend.slope_per_decade * 1000.0,
            "trend_ci_low_tw_dec": trend.ci_low * 1000.0,
            "trend_ci_high_tw_dec": trend.ci_high * 1000.0,
            "trend_wm2_cap_dec": trend.slope_per_decade * PW / area,
            "trend_ci_low_wm2_cap_dec": trend.ci_low * PW / area,
            "trend_ci_high_wm2_cap_dec": trend.ci_high * PW / area,
            "uncertainty": "OLS-HAC(24), temporal/regression only",
        }
    )


def main() -> None:
    with Dataset(CERES) as ds:
        original_index = ceres_index(ds)
        period = original_index.to_period("M")
        use_ceres = (period >= "2005-01") & (period <= "2026-03")
        lat = arr(ds, "lat")
        znet = arr(ds, "ztoa_net_all_mon")[use_ceres]
        selected_periods = period[use_ceres]
    if len(selected_periods) != 255:
        raise RuntimeError("CERES/OHC monthly overlap must contain 255 months")
    index = monthly_midpoints("2005-01", 255)

    ohc = pd.read_csv(OHC_MONTHLY, parse_dates=["time"])
    ohc_index = pd.DatetimeIndex(ohc.time)
    if not index.equals(ohc_index):
        raise RuntimeError("CERES and OHC monthly midpoint axes differ")

    area = zonal_band_areas(lat)
    edge, raw_monthly_w = implied_transport(znet, lat, remove_global_mean=True)
    global_mean = np.sum(znet * area[None, :], axis=1) / np.sum(area)

    summary_rows: list[dict] = []
    block_output = None
    central_output = None
    identity_errors = []
    closure_errors = []

    for boundary in BOUNDARIES:
        cap_mask = lat >= boundary
        ntoa_cap_w = np.sum(znet[:, cap_mask] * area[cap_mask][None, :], axis=1)
        edge_i = int(np.flatnonzero(np.isclose(edge, boundary))[0])
        raw_monthly_pw = raw_monthly_w[:, edge_i] / PW
        expected_raw_pw = (global_mean * cap_area(boundary) - ntoa_cap_w) / PW
        identity_errors.append(float(np.max(np.abs(raw_monthly_pw - expected_raw_pw))))

        ohc_energy_j = ohc[f"cap_{int(boundary)}N_j"].to_numpy(dtype=float)
        for method in ("block_12m_means", "central_12m_endpoints"):
            if method == "block_12m_means":
                ftime, storage_w = block_mean_tendency(ohc_energy_j, index)
            else:
                ftime, storage_w = central_span_tendency(ohc_energy_j, index)
            ntime, ntoa_filtered_w = filter_flux_like_state(ntoa_cap_w, index, method)
            rtime, raw_filtered_w = filter_flux_like_state(raw_monthly_pw * PW, index, method)
            if not ftime.equals(ntime) or not ftime.equals(rtime):
                raise RuntimeError("filtered CERES and OHC timestamps differ")

            storage_pw = storage_w / PW
            ntoa_pw = ntoa_filtered_w / PW
            raw_pw = raw_filtered_w / PW
            no_storage_pw = -ntoa_pw
            partial_pw = storage_pw - ntoa_pw
            alias_pw = partial_pw - raw_pw
            closure_errors.append(float(np.max(np.abs(partial_pw - (storage_pw - ntoa_pw)))))

            frame = block_output if method == "block_12m_means" else central_output
            if frame is None:
                frame = pd.DataFrame({"time": ftime})
                if method == "block_12m_means":
                    block_output = frame
                else:
                    central_output = frame
            prefix = f"{int(boundary)}N"
            frame[f"storage_{prefix}_pw"] = storage_pw
            frame[f"ntoa_cap_{prefix}_pw"] = ntoa_pw
            frame[f"no_storage_{prefix}_pw"] = no_storage_pw
            frame[f"raw_implied_{prefix}_pw"] = raw_pw
            frame[f"partial_transport_{prefix}_pw"] = partial_pw
            frame[f"storage_alias_{prefix}_pw"] = alias_pw

            metrics = {
                "ocean_storage_tendency": storage_pw,
                "N_TOA_cap": ntoa_pw,
                "no_storage_transport": no_storage_pw,
                "raw_implied_transport": raw_pw,
                "ocean_storage_corrected_partial_transport": partial_pw,
                "partial_minus_raw_storage_alias": alias_pw,
            }
            for window, start, end in [
                ("full_CERES_OHC", "2006-01-01", "2025-04-30"),
                ("common_ERA5", "2006-01-01", "2022-12-31"),
            ]:
                selected = (ftime >= start) & (ftime <= end)
                for metric, values in metrics.items():
                    summarize_metric(summary_rows, boundary, window, method, metric, values, ftime, selected)

    assert block_output is not None and central_output is not None
    block_output.to_csv(ROOT / "tables/partial_transport_block_timeseries.csv", index=False)
    block_output.to_csv(ROOT / "outputs/partial_transport_block_timeseries.csv", index=False)
    central_output.to_csv(ROOT / "tables/partial_transport_central_timeseries.csv", index=False)
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(ROOT / "tables/partial_transport_summary.csv", index=False)
    summary.to_csv(ROOT / "outputs/partial_transport_summary.csv", index=False)

    diagnostics = pd.DataFrame(
        [
            {"diagnostic": "raw implied cap identity max error", "value": max(identity_errors), "unit": "PW", "status": "PASS" if max(identity_errors) < 1e-12 else "FAIL"},
            {"diagnostic": "partial budget algebra max error", "value": max(closure_errors), "unit": "PW", "status": "PASS" if max(closure_errors) < 1e-14 else "FAIL"},
            {"diagnostic": "CERES/OHC overlap", "value": len(index), "unit": "months", "status": "PASS"},
        ]
    )
    diagnostics.to_csv(ROOT / "tables/partial_transport_technical_diagnostics.csv", index=False)
    diagnostics.to_csv(ROOT / "outputs/partial_transport_technical_diagnostics.csv", index=False)
    if (diagnostics.status != "PASS").any():
        raise RuntimeError("partial-transport technical diagnostics failed")

    # Time series: raw implied and partial corrected transport.
    fig, axes = plt.subplots(3, 1, figsize=(10.5, 9.0), sharex=True)
    for ax, boundary in zip(axes, BOUNDARIES):
        p = f"{int(boundary)}N"
        ax.plot(block_output.time, block_output[f"raw_implied_{p}_pw"], color="#777777", lw=1.0, label="raw implied")
        ax.plot(block_output.time, block_output[f"partial_transport_{p}_pw"], color="#0b6e99", lw=1.25, label="OHC-corrected partial")
        ax.set(ylabel="PW", title=f"Transport into cap ≥{int(boundary)}°N")
        ax.legend(frameon=False, ncol=2)
    axes[-1].set_xlabel("Filtered reference month")
    fig.suptitle("Northward-positive Arctic transport: raw implied vs ocean-storage-corrected partial\nCERES Ed4.2.1 + NCEI 0–2000 m OHC; 12-month block filter")
    fig.tight_layout()
    for path in [ROOT / "figures/partial_transport_timeseries.png", ROOT / "outputs/partial_transport_timeseries.png"]:
        fig.savefig(path, dpi=180)
    plt.close(fig)

    # Trend comparison on full period.
    full = summary[(summary.window == "full_CERES_OHC") & (summary["filter"] == "block_12m_means")]
    metrics_order = ["raw_implied_transport", "no_storage_transport", "ocean_storage_corrected_partial_transport"]
    colors = ["#777777", "#c17c27", "#0b6e99"]
    labels = ["raw implied", "no regional storage", "OHC-corrected partial"]
    fig, ax = plt.subplots(figsize=(9.5, 5.4))
    x = np.arange(len(BOUNDARIES))
    width = 0.23
    for k, (metric, color, label) in enumerate(zip(metrics_order, colors, labels)):
        rows = full[full.metric == metric].set_index("boundary_deg_n").loc[list(BOUNDARIES)]
        y = rows.trend_tw_dec.to_numpy()
        lo = rows.trend_ci_low_tw_dec.to_numpy()
        hi = rows.trend_ci_high_tw_dec.to_numpy()
        pos = x + (k - 1) * width
        ax.bar(pos, y, width, color=color, label=label)
        ax.errorbar(pos, y, yerr=np.vstack([y - lo, hi - y]), fmt="none", ecolor="black", capsize=3)
    ax.axhline(0, color="0.55", lw=0.8)
    ax.set_xticks(x, [f"{int(b)}°N" for b in BOUNDARIES])
    ax.set(ylabel="Transport trend (TW decade$^{-1}$)", title="Change in transport into Arctic caps, 2006-01–2025-04")
    ax.legend(frameon=False)
    fig.tight_layout()
    for path in [ROOT / "figures/partial_transport_trends.png", ROOT / "outputs/partial_transport_trends.png"]:
        fig.savefig(path, dpi=180)
    plt.close(fig)

    key = full[full.metric.isin(["ocean_storage_tendency", "N_TOA_cap", "raw_implied_transport", "ocean_storage_corrected_partial_transport", "partial_minus_raw_storage_alias"])]
    print("Technical diagnostics:\n" + diagnostics.to_string(index=False))
    print("\nFull-period key trends:\n" + key[["boundary_deg_n", "metric", "mean_pw", "trend_tw_dec", "trend_ci_low_tw_dec", "trend_ci_high_tw_dec", "trend_wm2_cap_dec"]].to_string(index=False))


if __name__ == "__main__":
    main()
