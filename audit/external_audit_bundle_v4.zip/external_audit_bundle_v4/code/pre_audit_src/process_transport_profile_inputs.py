"""Reduce CERES and NCEI OHC and validate the independent ERA5 reduction.

The immutable source files remain in ``raw``.  Output tables contain only the
monthly quantities needed for cap budgets at integer boundaries 30--85N.
"""

from __future__ import annotations

from pathlib import Path

from netCDF4 import Dataset, num2date
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import monthly_midpoints
from src.analyze_partial_transport import ceres_index
from src.energy_budget import PW, R_EARTH, cap_area, implied_transport, zonal_band_areas


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
BOUNDARIES = np.arange(30.0, 86.0, 1.0)
CERES = RAW / "ceres/ceres_ebaf_ed4.2.1_zonal_global_200003-202603.nc"
OHC = RAW / "ohc/heat_content_anomaly_0-2000_monthly_20260707.nc"


def _arr(ds: Dataset, name: str) -> np.ndarray:
    return np.asarray(np.ma.filled(ds[name][:], np.nan), dtype=float)


def _cap_weights(lat: np.ndarray, boundary: float) -> np.ndarray:
    """Exact spherical row weights for a regular 0.25-degree node grid."""
    lat = np.asarray(lat, dtype=float)
    if len(lat) < 2:
        raise ValueError("latitude grid is too short")
    half = abs(float(np.median(np.diff(np.sort(lat))))) / 2.0
    lower = np.maximum(boundary, lat - half)
    upper = np.minimum(90.0, lat + half)
    weights = 2.0 * np.pi * R_EARTH**2 * (
        np.sin(np.deg2rad(upper)) - np.sin(np.deg2rad(lower))
    )
    return np.where(upper > lower, weights, 0.0)


def process_era5() -> tuple[pd.DataFrame, list[dict]]:
    # The clean raw reducer in code/era5 creates this table directly from all
    # monthly 0.25-degree fields. It imports none of the production reducers.
    path = ROOT / "tables/era5_transport_profile_monthly.csv"
    frame = pd.read_csv(path, parse_dates=["time"]).sort_values(
        ["time", "boundary_deg_n"]
    ).reset_index(drop=True)
    expected = 276 * len(BOUNDARIES)
    if len(frame) != expected or frame[["aht_pw", "atmospheric_storage_pw"]].isna().any().any():
        raise RuntimeError("independent ERA5 profile reduction is incomplete")
    if frame.groupby("boundary_deg_n").size().nunique() != 1:
        raise RuntimeError("independent ERA5 profile has uneven latitude coverage")
    diagnostics = [
        {
            "diagnostic": "independent ERA5 profile rows",
            "value": len(frame),
            "unit": "month-latitude rows",
            "status": "PASS" if len(frame) == expected else "FAIL",
        },
    ]
    return frame, diagnostics


def process_ceres() -> tuple[pd.DataFrame, list[dict]]:
    with Dataset(CERES) as ds:
        original_index = ceres_index(ds)
        period = original_index.to_period("M")
        use = (period >= "2005-01") & (period <= "2022-12")
        lat = _arr(ds, "lat")
        net = _arr(ds, "ztoa_net_all_mon")[use]
    index = monthly_midpoints("2005-01", int(use.sum()))
    area = zonal_band_areas(lat)
    edges, raw_implied = implied_transport(net, lat, remove_global_mean=True)
    records = []
    identity_errors = []
    global_mean = np.sum(net * area[None, :], axis=1) / np.sum(area)
    for boundary in BOUNDARIES:
        edge_index = np.flatnonzero(np.isclose(edges, boundary))
        if len(edge_index) != 1:
            raise RuntimeError(f"CERES grid has no exact {boundary}N edge")
        cap = lat >= boundary
        ntoa_w = np.sum(net[:, cap] * area[cap][None, :], axis=1)
        raw_w = raw_implied[:, int(edge_index[0])]
        expected = global_mean * cap_area(boundary) - ntoa_w
        identity_errors.append(float(np.max(np.abs(raw_w - expected)) / PW))
        records.extend(
            {
                "time": time,
                "boundary_deg_n": boundary,
                "ntoa_cap_pw": n / PW,
                "raw_implied_pw": h / PW,
            }
            for time, n, h in zip(index, ntoa_w, raw_w)
        )
    frame = pd.DataFrame(records).sort_values(["time", "boundary_deg_n"]).reset_index(drop=True)
    frame.to_csv(ROOT / "tables/ceres_cap_profile_monthly.csv", index=False)
    diagnostics = [
        {
            "diagnostic": "CERES raw-implied cap identity max error",
            "value": max(identity_errors),
            "unit": "PW",
            "status": "PASS" if max(identity_errors) < 1e-11 else "FAIL",
        }
    ]
    return frame, diagnostics


def process_ohc() -> tuple[pd.DataFrame, pd.DataFrame, list[dict]]:
    with Dataset(OHC) as ds:
        lat = _arr(ds, "lat")
        lon = _arr(ds, "lon")
        values_ma = ds["h18_hc"][:, 0]
        mask = np.ma.getmaskarray(values_ma)
        values = np.asarray(np.ma.filled(values_ma, 0.0), dtype=float)
    if np.any(mask != mask[0]):
        raise RuntimeError("NCEI OHC valid-cell mask changes with time")
    valid = ~mask[0]
    index_all = monthly_midpoints("2005-01", len(values))
    use = index_all.to_period("M") <= "2022-12"
    values = values[use]
    index = index_all[use]

    latitude_area = zonal_band_areas(lat)
    cell_area = np.repeat((latitude_area / len(lon))[:, None], len(lon), axis=1)
    records = []
    metadata = []
    for boundary in BOUNDARIES:
        cap = (lat[:, None] >= boundary) & valid
        energy = np.sum(values[:, cap], axis=1) * 1e18
        total_area = cap_area(boundary)
        sampled_area = float(np.sum(cell_area[cap]))
        records.extend(
            {"time": time, "boundary_deg_n": boundary, "ohc_0_2000_j": value}
            for time, value in zip(index, energy)
        )
        metadata.append(
            {
                "boundary_deg_n": boundary,
                "total_cap_area_m2": total_area,
                "sampled_ocean_area_m2": sampled_area,
                "sampled_ocean_fraction_of_cap": sampled_area / total_area,
                "valid_cells": int(cap.sum()),
            }
        )
    frame = pd.DataFrame(records).sort_values(["time", "boundary_deg_n"]).reset_index(drop=True)
    meta = pd.DataFrame(metadata)
    frame.to_csv(ROOT / "tables/ohc_cap_profile_monthly_energy.csv", index=False)
    meta.to_csv(ROOT / "tables/ohc_cap_profile_coverage.csv", index=False)
    meta.to_csv(ROOT / "outputs/ohc_cap_profile_coverage.csv", index=False)

    diagnostics = [
        {
            "diagnostic": "OHC profile finite cap states",
            "value": bool(np.isfinite(frame.ohc_0_2000_j).all()),
            "unit": "boolean",
            "status": "PASS" if np.isfinite(frame.ohc_0_2000_j).all() else "FAIL",
        },
        {
            "diagnostic": "OHC sampled cap fraction within physical range",
            "value": bool(((meta.sampled_ocean_fraction_of_cap > 0) & (meta.sampled_ocean_fraction_of_cap <= 1 + 1e-12)).all()),
            "unit": "boolean",
            "status": "PASS" if ((meta.sampled_ocean_fraction_of_cap > 0) & (meta.sampled_ocean_fraction_of_cap <= 1 + 1e-12)).all() else "FAIL",
        },
    ]
    return frame, meta, diagnostics


def main() -> None:
    era, era_diagnostics = process_era5()
    ceres, ceres_diagnostics = process_ceres()
    ohc, coverage, ohc_diagnostics = process_ohc()
    diagnostics = pd.DataFrame(era_diagnostics + ceres_diagnostics + ohc_diagnostics)
    diagnostics.to_csv(ROOT / "tables/transport_profile_input_diagnostics.csv", index=False)
    diagnostics.to_csv(ROOT / "outputs/transport_profile_input_diagnostics.csv", index=False)
    if (diagnostics.status != "PASS").any():
        raise RuntimeError("transport-profile input diagnostics failed")
    print(diagnostics.to_string(index=False))
    print(
        f"reduced rows: ERA5={len(era)}, CERES={len(ceres)}, OHC={len(ohc)}; "
        f"boundaries={len(coverage)}"
    )


if __name__ == "__main__":
    main()
