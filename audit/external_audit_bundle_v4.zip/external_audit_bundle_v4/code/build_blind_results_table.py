#!/usr/bin/env python3
"""Create the reviewer's sealed raw-reproduction result table.

The module contains no author reference values and never reads the sealed
comparison directory.  It only extracts quantities from artifacts generated
inside the reviewer's clean raw-data workspace.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import pandas as pd


SEALED = "SEALED_UNTIL_BLIND_REPRODUCTION_IS_COMPLETE"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace-dir", type=Path, required=True)
    parser.add_argument("--output-file", type=Path)
    args = parser.parse_args()
    workspace = args.workspace_dir.resolve()
    output = workspace / "outputs"
    target = args.output_file.resolve() if args.output_file else output / "INDEPENDENT_RAW_REPRODUCTION.csv"
    rows: list[dict] = []

    def add(qid: str, description: str, dataset: str, period: str, unit: str, value: float, evidence: str) -> None:
        rows.append(
            {
                "quantity": qid,
                "authors_reference": SEALED,
                "reviewer_raw_result": float(value),
                "absolute_difference": "",
                "relative_difference": "",
                "units": unit,
                "status": "SEALED_PENDING_COMPARISON",
                "probable_cause": "",
                "description": description,
                "dataset": dataset,
                "period": period,
                "evidence_file": evidence,
            }
        )

    validation = pd.read_csv(workspace / "tables" / "ceres_validation.csv").set_index("id")
    for qid, vid, name in (
        ("CERES_GLOBAL_ASR", "V01", "global mean absorbed solar radiation"),
        ("CERES_GLOBAL_OLR", "V02", "global mean outgoing longwave radiation"),
        ("CERES_GLOBAL_NET", "V03", "global mean TOA net downward flux"),
    ):
        add(qid, name, "CERES EBAF Ed4.2.1", "2000-03--2020-02", "W m-2", validation.loc[vid].estimate, "tables/ceres_validation.csv")

    summary = pd.read_csv(output / "global_energy_context_summary_metrics.csv")
    def summary_row(metric: str) -> pd.Series:
        match = summary[summary.metric == metric]
        if len(match) != 1:
            raise RuntimeError(f"expected one summary metric: {metric}")
        return match.iloc[0]

    absolute_metrics = (
        ("CERES_H_MIN", "CERES raw implied total: maximum southward transport", "CERES raw implied total minimum", "PW"),
        ("CERES_H_MAX", "CERES raw implied total: maximum northward transport", "CERES raw implied total maximum", "PW"),
        ("CERES_H_EQUATOR", "CERES raw implied total: cross-equatorial transport", "CERES cross-equatorial raw implied transport", "PW"),
        ("ERA5_AHT_MIN", "actual ERA5 atmospheric: maximum southward transport", "ERA5 atmospheric transport minimum", "PW"),
        ("ERA5_AHT_MAX", "actual ERA5 atmospheric: maximum northward transport", "ERA5 atmospheric transport maximum", "PW"),
        ("ERA5_AHT_EQUATOR", "actual ERA5 atmospheric: cross-equatorial transport", "ERA5 cross-equatorial atmospheric transport", "PW"),
        ("CERES_NET_ZERO_SH", "CERES N_TOA zero crossing 1", "southern CERES TOA-net zero crossing", "degree_north"),
        ("CERES_NET_ZERO_NH", "CERES N_TOA zero crossing 2", "northern CERES TOA-net zero crossing", "degree_north"),
        ("CERES_GLOBAL_NET_2001_2025", "CERES global mean N_TOA", "global mean CERES TOA net downward flux", "W m-2"),
    )
    for qid, metric, description, unit in absolute_metrics:
        row = summary_row(metric)
        add(qid, description, "CERES EBAF Ed4.2.1" if qid.startswith("CERES") else "ERA5 energy-moisture budget v1.0", str(row.period), unit, row.value, "outputs/global_energy_context_summary_metrics.csv")
        if qid in {"CERES_H_MIN", "CERES_H_MAX", "ERA5_AHT_MIN", "ERA5_AHT_MAX"}:
            add(qid + "_LAT", description + " latitude", "CERES EBAF Ed4.2.1" if qid.startswith("CERES") else "ERA5 energy-moisture budget v1.0", str(row.period), "degree_north", row.latitude_deg, "outputs/global_energy_context_summary_metrics.csv")

    context = pd.read_csv(output / "global_energy_context_table.csv").set_index("latitude_deg")
    for latitude in (-70.0, -60.0, 0.0, 60.0, 70.0):
        row = context.loc[latitude]
        tag = ("M" + str(abs(int(latitude))) + "S") if latitude < 0 else ("EQ" if latitude == 0 else "P" + str(int(latitude)) + "N")
        add(f"CERES_H_{tag}", f"CERES raw implied transport at {latitude:g} degrees", "CERES EBAF Ed4.2.1", str(row.transport_period), "PW", row.raw_implied_climatology_pw, "outputs/global_energy_context_table.csv")
        add(f"ERA5_AHT_{tag}", f"ERA5 atmospheric transport at {latitude:g} degrees", "ERA5 energy-moisture budget v1.0", str(row.transport_period), "PW", row.actual_aht_climatology_pw, "outputs/global_energy_context_table.csv")

    profile = pd.read_csv(output / "storage_corrected_transport_profile.csv")
    climatology = profile[(profile.hemisphere == "NH") & (profile.method == "block_12m_means") & (profile.metric == "h_known_plus_sea_ice")].set_index("boundary_abs_deg")
    post = pd.read_csv(output / "POST_AUDIT_KEY_RESULTS.csv").set_index("boundary_deg_n")
    for latitude in (60.0, 65.0, 70.0):
        p = post.loc[latitude]
        tag = str(int(latitude)) + "N"
        add(f"HCORR_CLIM_{tag}", f"known-storage-corrected required transport climatology at {tag}", "CERES+NCEI OHC+ERA5 storage+PIOMAS", "2006-01--2022-01", "PW", climatology.loc[latitude].mean_pw, "outputs/storage_corrected_transport_profile.csv")
        for suffix, description, column in (
            ("HCORR_TREND", "H_corr trend", "h_corr_trend_tw_dec"),
            ("HCORR_CI_LOW", "H_corr calibrated CI lower", "h_corr_calibrated_ci_low_tw_dec"),
            ("HCORR_CI_HIGH", "H_corr calibrated CI upper", "h_corr_calibrated_ci_high_tw_dec"),
            ("HCORR_DETECTION", "H_corr empirical temporal detection half-width", "h_corr_empirical_detection_limit_tw_dec"),
            ("STORAGE_ALIAS_TREND", "storage-alias trend", "storage_alias_trend_tw_dec"),
            ("STORAGE_ALIAS_CI_LOW", "storage-alias calibrated CI lower", "storage_alias_ci_low_tw_dec"),
            ("STORAGE_ALIAS_CI_HIGH", "storage-alias calibrated CI upper", "storage_alias_ci_high_tw_dec"),
            ("ERA5_AHT_TREND", "ERA5 AHT trend", "era5_aht_trend_tw_dec"),
            ("ERA5_AHT_CI_LOW", "ERA5 AHT calibrated CI lower", "era5_aht_ci_low_tw_dec"),
            ("ERA5_AHT_CI_HIGH", "ERA5 AHT calibrated CI upper", "era5_aht_ci_high_tw_dec"),
            ("REMAINDER_TREND", "unresolved remainder trend", "unresolved_remainder_trend_tw_dec"),
            ("PIOMAS_SCALE_SENS", "maximum PIOMAS scaling scenario sensitivity", "quantified_piomas_rescaling_scenario_plus_minus_tw_dec"),
        ):
            add(f"{suffix}_{tag}", f"{description} at {tag}", "combined post-audit branch", "2006-01--2022-01", "TW decade-1", p[column], "outputs/POST_AUDIT_KEY_RESULTS.csv")

    metadata = json.loads((output / "monte_carlo_calibration_metadata.json").read_text())
    for estimator, value in metadata["calibrated_critical_values"].items():
        add(f"MC_CRITICAL_{estimator.upper()}", f"maximum-DGP calibrated critical value for {estimator}", "synthetic Monte Carlo", "216 synthetic months", "dimensionless", value, "outputs/monte_carlo_calibration_metadata.json")

    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"blind raw-reproduction table: {target} ({len(rows)} quantities; author values remain sealed)")


if __name__ == "__main__":
    main()
