#!/usr/bin/env python3
"""Install fresh raw-to-zonal ERA5 reductions into a clean analysis workspace."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

import pandas as pd


MAPPING = {
    "independent_era5_global_aht_monthly.csv": "era5_global_aht_monthly.csv",
    "independent_era5_transport_profile_monthly.csv": "era5_transport_profile_monthly.csv",
    "independent_era5_sh_atmospheric_storage_monthly.csv": "era5_sh_atmospheric_storage_monthly.csv",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--independent-dir", type=Path, required=True)
    parser.add_argument("--workspace-dir", type=Path, required=True)
    args = parser.parse_args()
    tables = args.workspace_dir.resolve() / "tables"
    tables.mkdir(parents=True, exist_ok=True)
    for source_name, target_name in MAPPING.items():
        source = args.independent_dir.resolve() / source_name
        frame = pd.read_csv(source)
        if frame.empty or frame.select_dtypes(include="number").isna().any().any():
            raise RuntimeError(f"invalid independent ERA5 reduction: {source}")
        shutil.copy2(source, tables / target_name)
        print(f"{source_name} -> tables/{target_name} ({len(frame)} rows)")


if __name__ == "__main__":
    main()
