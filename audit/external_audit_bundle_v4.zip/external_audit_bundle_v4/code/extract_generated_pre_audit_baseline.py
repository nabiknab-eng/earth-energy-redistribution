#!/usr/bin/env python3
"""Freeze a baseline generated from raw inputs before installing Stage 10 code.

This utility never reads the bundle's reference_results directory.  The two
files it creates are inputs to the post-audit *comparison* code, but their
numbers originate in the reviewer's own raw-data run.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

import pandas as pd


KEY_LATITUDES = (50.0, 60.0, 65.0, 70.0, 75.0, 80.0)


def build_key_table(output: Path) -> pd.DataFrame:
    profile = pd.read_csv(output / "storage_corrected_transport_profile.csv")
    detection = pd.read_csv(output / "storage_corrected_detection_limits.csv")
    closure = pd.read_csv(output / "closure_residual_profile.csv")
    nh = profile[(profile.hemisphere == "NH") & (profile.method == "block_12m_means")]

    def metric(name: str) -> pd.Series:
        return nh[nh.metric == name].set_index("boundary_abs_deg").trend_tw_dec

    d = detection[detection.hemisphere == "NH"].set_index("boundary_abs_deg")
    c = closure[closure.hemisphere == "NH"].set_index("boundary_abs_deg")
    raw = metric("raw_implied")
    known = metric("h_known")
    ice = metric("h_known_plus_sea_ice")
    return pd.DataFrame(
        {
            "boundary_deg_n": KEY_LATITUDES,
            "raw_ceres_trend_tw_dec": [raw.loc[x] for x in KEY_LATITUDES],
            "h_known_trend_tw_dec": [known.loc[x] for x in KEY_LATITUDES],
            "h_known_plus_si_trend_tw_dec": [ice.loc[x] for x in KEY_LATITUDES],
            "storage_alias_tw_dec": [raw.loc[x] - ice.loc[x] for x in KEY_LATITUDES],
            "temporal_ci_low_tw_dec": [d.loc[x].ci_low_tw_dec for x in KEY_LATITUDES],
            "temporal_ci_high_tw_dec": [d.loc[x].ci_high_tw_dec for x in KEY_LATITUDES],
            "temporal_mde95_tw_dec": [d.loc[x].temporal_mde95_tw_dec for x in KEY_LATITUDES],
            "structural_bound_tw_dec": [d.loc[x].structural_bound_tw_dec for x in KEY_LATITUDES],
            "conservative_safe_threshold_tw_dec": [d.loc[x].conservative_safe_threshold_tw_dec for x in KEY_LATITUDES],
            "era5_actual_aht_trend_tw_dec": [metric("actual_aht_poleward").loc[x] for x in KEY_LATITUDES],
            "unresolved_remainder_trend_tw_dec": [c.loc[x].unresolved_remainder_trend_tw_dec for x in KEY_LATITUDES],
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace-dir", type=Path, required=True)
    args = parser.parse_args()
    output = args.workspace_dir.resolve() / "outputs"
    generated = build_key_table(output)
    generated.to_csv(output / "audit_pre_correction_key_results.csv", index=False)
    snapshot = output / "audit_pre_correction_snapshot_20260808" / "results"
    snapshot.mkdir(parents=True, exist_ok=True)
    shutil.copy2(output / "storage_annual_difference_profile.csv", snapshot / "storage_annual_difference_profile.csv")
    print("raw-generated pre-audit baseline frozen; no author reference was read")


if __name__ == "__main__":
    main()
