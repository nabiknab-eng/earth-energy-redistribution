#!/usr/bin/env python3
"""Independent raw ERA5 spatial reduction for the external audit.

This implementation intentionally imports none of the production ERA5
reduction code.  It reads coordinate and variable metadata from every monthly
NetCDF member and stops if units, product version, ordering, grid, or coverage
do not match the predefined audit contract.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import zipfile

from netCDF4 import Dataset, num2date
import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
BUNDLE_ROOT = HERE.parents[1]
R_EARTH_M = 6_371_000.0
PW_W = 1.0e15
GRID_DEG = 0.25
EXPECTED_VERSION = "v1.0"


def array(variable) -> np.ndarray:
    return np.asarray(np.ma.filled(variable[:], np.nan), dtype=float)


def month_key(ds: Dataset) -> str:
    time = ds["time"]
    if time.shape != (1,) or getattr(time, "units", "") != "hours since 1900-01-01 00:00:00.0":
        raise RuntimeError("unexpected ERA5 time coordinate")
    date = num2date(time[0], time.units, getattr(time, "calendar", "standard"))
    return f"{date.year:04d}-{date.month:02d}"


def validate_coordinates(ds: Dataset) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    lat_v, lon_v = ds["latitude"], ds["longitude"]
    if getattr(lat_v, "units", "") != "degrees_north" or getattr(lon_v, "units", "") != "degrees_east":
        raise RuntimeError("ERA5 coordinate units changed")
    lat, lon = array(lat_v), array(lon_v)
    if not np.all(np.diff(lat) > 0) or not np.allclose(np.diff(lat), GRID_DEG, rtol=0, atol=1e-12):
        raise RuntimeError("latitude must be strictly south-to-north on the 0.25 degree grid")
    normalized = np.mod(lon, 360.0)
    _, first = np.unique(np.round(normalized, 10), return_index=True)
    first = first[np.argsort(normalized[first])]
    unique_lon = normalized[first]
    expected = np.arange(0.0, 360.0, GRID_DEG)
    if len(lon) != 1441 or len(first) != 1440 or not np.allclose(unique_lon, expected, rtol=0, atol=1e-12):
        raise RuntimeError("longitude grid/duplicate endpoint is not the expected 0..359.75 plus repeated 0")
    dlon_rad = np.deg2rad(GRID_DEG)
    return lat, lon, first, dlon_rad


def validate_variable(ds: Dataset, variable_name: str) -> None:
    if getattr(ds, "version", "") != EXPECTED_VERSION or getattr(ds, "Conventions", "") != "CF-1.6":
        raise RuntimeError("ERA5 product version or CF convention differs from original")
    if ds.data_model != "NETCDF4":
        raise RuntimeError(f"unexpected NetCDF model {ds.data_model}")
    expected = {
        "tefln": ("W m**-1", "Vertical integral of northward total energy flux"),
        "tetend": ("W m**-2", "Tendency of vertical integral of total energy"),
    }
    units, long_name = expected[variable_name]
    variable = ds[variable_name]
    if getattr(variable, "units", "") != units or getattr(variable, "long_name", "") != long_name:
        raise RuntimeError(f"metadata mismatch for {variable_name}")
    if variable.ndim != 3 or variable.shape[0] != 1:
        raise RuntimeError(f"unexpected shape for {variable_name}: {variable.shape}")


def zonal_energy_transport_w(field_w_per_m: np.ndarray, lat_deg: np.ndarray, lon_keep: np.ndarray, dlon_rad: float) -> np.ndarray:
    """Integrate W m-1 around each latitude circle.

    Input ``tefln`` is vertically integrated northward energy flux in W m-1.
    Multiplication by the zonal arc length of each longitude cell,
    ``R*cos(latitude)*dlambda`` [m], gives W.  Summing unique longitude cells
    yields total northward transport through the complete parallel.  Output is
    divided by 1e15 only when exported to PW.
    """
    values = np.asarray(field_w_per_m, dtype=float)[:, lon_keep]
    if not np.isfinite(values).all():
        raise RuntimeError("non-finite tefln values")
    arc_m = R_EARTH_M * np.cos(np.deg2rad(lat_deg)) * dlon_rad
    watts = np.sum(values, axis=1, dtype=np.float64) * arc_m
    watts[np.isclose(np.abs(lat_deg), 90.0, atol=1e-12)] = 0.0
    return watts


def cap_ring_weights_m2(lat_deg: np.ndarray, boundaries_abs: np.ndarray, hemisphere: str) -> np.ndarray:
    """Exact spherical areas for node-centred 0.25 degree rows clipped to caps."""
    center = np.asarray(lat_deg, dtype=float)
    lower_node = np.maximum(-90.0, center - GRID_DEG / 2.0)
    upper_node = np.minimum(90.0, center + GRID_DEG / 2.0)
    weights = []
    for boundary in boundaries_abs:
        if hemisphere == "NH":
            lower = np.maximum(boundary, lower_node)
            upper = upper_node
        elif hemisphere == "SH":
            lower = lower_node
            upper = np.minimum(-boundary, upper_node)
        else:
            raise ValueError(hemisphere)
        area = 2.0 * np.pi * R_EARTH_M**2 * (np.sin(np.deg2rad(upper)) - np.sin(np.deg2rad(lower)))
        weights.append(np.where(upper > lower, area, 0.0))
    return np.asarray(weights)


def cap_storage_tendency_w(field_wm2: np.ndarray, lon_keep: np.ndarray, weights_m2: np.ndarray) -> np.ndarray:
    """W m-2 zonal mean times exact ring area m2 equals cap-integrated W."""
    values = np.asarray(field_wm2, dtype=float)[:, lon_keep]
    if not np.isfinite(values).all():
        raise RuntimeError("non-finite tetend values")
    zonal_mean_wm2 = np.mean(values, axis=1, dtype=np.float64)
    return weights_m2 @ zonal_mean_wm2


def midpoint(month: str) -> pd.Timestamp:
    period = pd.Period(month, freq="M")
    start = period.to_timestamp(how="start")
    end = (period + 1).to_timestamp(how="start")
    return start + (end - start) / 2


def member_payloads(path: Path):
    with zipfile.ZipFile(path) as archive:
        for name in sorted(archive.namelist()):
            yield name, archive.read(name)


def exact_rows(lat: np.ndarray, targets: np.ndarray) -> np.ndarray:
    indices = np.searchsorted(lat, targets)
    if np.any(indices >= len(lat)) or not np.allclose(lat[indices], targets, rtol=0, atol=1e-12):
        raise RuntimeError("requested integer latitude row is absent")
    return indices


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=HERE / "independent_reduction")
    args = parser.parse_args()
    raw_dir, out = args.raw_dir.resolve(), args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    spec = json.loads((BUNDLE_ROOT / "download_specs" / "era5_requests.json").read_text())
    global_rows, profile_rows, nh_storage_rows, sh_storage_rows, metadata = [], [], [], [], []
    seen_months: dict[str, set[str]] = {}
    for request in spec["requests"]:
        path = raw_dir / request["download_filename"]
        if not path.is_file():
            raise FileNotFoundError(path)
        component = request["component"]
        count = 0
        versions, units_seen, shapes = set(), set(), set()
        lat_min = lat_max = np.nan
        for member_name, payload in member_payloads(path):
            ds = Dataset("independent-era5.nc", memory=payload)
            variable_name = "tefln" if request["variable"] == "vertical_integral_of_northward_total_energy_flux" else "tetend"
            validate_variable(ds, variable_name)
            lat, lon, keep, dlon = validate_coordinates(ds)
            month = month_key(ds)
            expected_years = range(request["years"][0], request["years"][1] + 1)
            if int(month[:4]) not in expected_years or month[5:] not in request["months"]:
                raise RuntimeError(f"member time outside request: {member_name}")
            key = request["request_id"]
            if month in seen_months.setdefault(key, set()):
                raise RuntimeError(f"duplicate member month {month} in {key}")
            seen_months[key].add(month)
            field = array(ds[variable_name])[0]
            if component == "actual_aht_global_90S_29N":
                targets = np.arange(-90.0, 30.0)
                indices = exact_rows(lat, targets)
                pw = zonal_energy_transport_w(field, lat, keep, dlon)[indices] / PW_W
                global_rows.extend({"month": month, "latitude_deg": phi, "actual_aht_pw": value} for phi, value in zip(targets, pw))
            elif component == "actual_aht_global_and_profile_30_85N":
                targets = np.arange(30.0, 86.0)
                indices = exact_rows(lat, targets)
                pw = zonal_energy_transport_w(field, lat, keep, dlon)[indices] / PW_W
                global_rows.extend({"month": month, "latitude_deg": phi, "actual_aht_pw": value} for phi, value in zip(targets, pw))
                profile_rows.extend({"month": month, "boundary_deg_n": phi, "aht_pw": value} for phi, value in zip(targets, pw))
            elif component == "actual_aht_global_86_90N":
                targets = np.arange(86.0, 91.0)
                indices = exact_rows(lat, targets)
                pw = zonal_energy_transport_w(field, lat, keep, dlon)[indices] / PW_W
                global_rows.extend({"month": month, "latitude_deg": phi, "actual_aht_pw": value} for phi, value in zip(targets, pw))
            elif component == "atmospheric_storage_NH_30_85N":
                boundaries = np.arange(30.0, 86.0)
                weights = cap_ring_weights_m2(lat, boundaries, "NH")
                pw = cap_storage_tendency_w(field, keep, weights) / PW_W
                nh_storage_rows.extend({"month": month, "boundary_deg_n": phi, "atmospheric_storage_pw": value} for phi, value in zip(boundaries, pw))
            elif component == "atmospheric_storage_SH_50_80S":
                boundaries = np.arange(50.0, 81.0)
                weights = cap_ring_weights_m2(lat, boundaries, "SH")
                pw = cap_storage_tendency_w(field, keep, weights) / PW_W
                sh_storage_rows.extend({"month": month, "hemisphere": "SH", "boundary_abs_deg": phi, "atmospheric_storage_pw": value} for phi, value in zip(boundaries, pw))
            else:
                raise RuntimeError(f"unknown component {component}")
            versions.add(getattr(ds, "version", "")); units_seen.add(getattr(ds[variable_name], "units", "")); shapes.add(str(ds[variable_name].shape))
            lat_min, lat_max = float(lat.min()), float(lat.max())
            ds.close(); count += 1
        if count != request["expected_monthly_members"]:
            raise RuntimeError(f"wrong member count for {request['request_id']}: {count}")
        metadata.append({
            "request_id": request["request_id"], "archive": path.name, "members": count,
            "product_versions": ";".join(sorted(versions)), "variable_units": ";".join(sorted(units_seen)),
            "variable_shapes": ";".join(sorted(shapes)), "latitude_min": lat_min, "latitude_max": lat_max,
            "longitude_nodes": 1441, "unique_longitudes": 1440, "grid_deg": GRID_DEG, "status": "PASS",
        })
    global_frame = pd.DataFrame(global_rows).sort_values(["month", "latitude_deg"]).reset_index(drop=True)
    aht_profile = pd.DataFrame(profile_rows).sort_values(["month", "boundary_deg_n"]).reset_index(drop=True)
    nh_storage = pd.DataFrame(nh_storage_rows).sort_values(["month", "boundary_deg_n"]).reset_index(drop=True)
    profile = aht_profile.merge(nh_storage, on=["month", "boundary_deg_n"], validate="one_to_one")
    sh = pd.DataFrame(sh_storage_rows).sort_values(["month", "boundary_abs_deg"]).reset_index(drop=True)
    if len(global_frame) != 276 * 181 or len(profile) != 276 * 56 or len(sh) != 216 * 31:
        raise RuntimeError("independent reduced grids are incomplete")
    global_frame.insert(0, "time", global_frame.month.map(midpoint))
    profile.insert(0, "time", profile.month.map(lambda value: pd.Timestamp(f"{value}-15")))
    sh.insert(0, "time", sh.month.map(midpoint))
    global_frame.drop(columns="month").to_csv(out / "independent_era5_global_aht_monthly.csv", index=False)
    profile.drop(columns="month").to_csv(out / "independent_era5_transport_profile_monthly.csv", index=False)
    sh.drop(columns="month").to_csv(out / "independent_era5_sh_atmospheric_storage_monthly.csv", index=False)
    pd.DataFrame(metadata).to_csv(out / "ERA5_RAW_METADATA.csv", index=False)
    print(f"independent ERA5 reduction complete: global={len(global_frame)}, NH={len(profile)}, SH={len(sh)}")


if __name__ == "__main__":
    main()
