#!/usr/bin/env python3
"""Download or audit only the exact ERA5 archives used by this project.

No credentials are embedded.  In ``download`` mode cdsapi reads the user's
normal CDS configuration.  The request dictionaries are passed exactly as
recorded in the original provenance: no new format or grid parameter is added.
"""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys


HERE = Path(__file__).resolve().parent
REQUEST_FILE = HERE.parents[1] / "download_specs" / "era5_requests.json"
HEADROOM_BYTES = 512 * 2**20


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_and_validate_spec() -> dict:
    spec = json.loads(REQUEST_FILE.read_text())
    requests = spec["requests"]
    if spec["request_count"] != 15 or len(requests) != 15:
        raise RuntimeError("ERA5 audit must contain exactly the 15 original chunks")
    seen = set()
    for row in requests:
        source = HERE / row["original_request_source"]
        original = json.loads(source.read_text())
        matches = [item for item in original if Path(item["path"]).name == row["download_filename"]]
        if len(matches) != 1:
            raise RuntimeError(f"cannot uniquely recover original request for {row['request_id']}")
        if matches[0]["request"] != row["cds_api_request_exact"]:
            raise RuntimeError(f"summary request differs from immutable original: {row['request_id']}")
        if row["download_filename"] in seen:
            raise RuntimeError(f"duplicate target filename: {row['download_filename']}")
        seen.add(row["download_filename"])
        if set(row["cds_api_request_exact"]) != {"variable", "year", "month", "area"}:
            raise RuntimeError("request contains parameters absent from the original workflow")
    return spec


def write_reports(records: list[dict], *, mode: str, raw_dir: Path, report_dir: Path, free_before: int, required: int) -> None:
    report_dir.mkdir(parents=True, exist_ok=True)
    report_csv = report_dir / "ERA5_REDOWNLOAD_CHECKSUMS.csv"
    report_md = report_dir / "ERA5_REDOWNLOAD_REPORT.md"
    columns = [
        "request_id", "dataset", "variable", "filename", "bytes",
        "sha256", "original_bytes", "original_sha256", "size_matches_original",
        "sha256_matches_original", "status",
    ]
    with report_csv.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows({key: row.get(key, "") for key in columns} for row in records)
    passed = all(row["status"] in {
        "EXISTING_ORIGINAL_MATCH", "DOWNLOADED_ORIGINAL_MATCH",
        "DOWNLOADED_REPACKAGED_OR_CHANGED", "EXISTING_REPACKAGED_OR_CHANGED",
    } for row in records)
    lines = [
        "# ERA5 re-download report", "",
        f"- UTC run time: {datetime.now(timezone.utc).isoformat()}",
        f"- Mode: `{mode}`",
        f"- Raw directory: `{raw_dir}`",
        f"- Requests: {len(records)}",
        f"- Expected original archive volume: {sum(row['original_bytes'] for row in records):,} bytes",
        "- Estimated fully extracted monthly members: 1,757,373,624 bytes (not extracted by this workflow)",
        f"- Additional bytes estimated before run: {required:,}",
        f"- Free disk before run: {free_before:,} bytes",
        f"- Archive/availability audit: **{'PASS' if passed else 'FAIL'}**", "",
        "Byte-level SHA256 mismatch after a fresh CDS retrieval is reported but is not",
        "silently repaired: server-side repackaging can change an archive while decoded",
        "fields remain identical. Product metadata and numerical fields are tested by the",
        "independent reduction step.", "",
        "| request | status | bytes | original SHA256 match |", "|---|---|---:|:---:|",
    ]
    for row in records:
        lines.append(f"| {row['request_id']} | {row['status']} | {row['bytes']} | {row['sha256_matches_original']} |")
    report_md.write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["download", "existing", "dry-run"], default="download")
    parser.add_argument("--raw-dir", type=Path, default=HERE / "downloads" / "raw" / "era5")
    parser.add_argument("--report-dir", type=Path, default=HERE)
    args = parser.parse_args()
    spec = load_and_validate_spec()
    raw_dir = args.raw_dir.expanduser().resolve()
    raw_dir.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(raw_dir)
    missing_expected = sum(
        row["original_archive_bytes"]
        for row in spec["requests"]
        if not (raw_dir / row["download_filename"]).exists()
    )
    required = missing_expected + (HEADROOM_BYTES if missing_expected else 0)
    print(f"ERA5 requests: {len(spec['requests'])}")
    print(f"Expected total: {spec['expected_total_archive_bytes']:,} bytes ({spec['expected_total_archive_gib']:.3f} GiB)")
    print(
        "Estimated fully extracted members: "
        f"{spec['expected_total_member_bytes_if_fully_extracted']:,} bytes "
        f"({spec['expected_total_member_gib_if_fully_extracted']:.3f} GiB); reducer streams ZIP members"
    )
    print(f"Missing estimate + headroom: {required:,} bytes; free: {usage.free:,} bytes")
    for row in spec["requests"]:
        print(f"{row['request_sequence']:02d} {row['dataset']} {row['variable']} {row['years']} area={row['area_north_west_south_east']} -> {row['download_filename']}")
    if usage.free < required:
        raise SystemExit("insufficient free disk for the exact ERA5 chunk set")
    if args.mode == "dry-run":
        print("DRY RUN: request payload and disk audit passed; no network call made")
        return
    client = None
    if args.mode == "download":
        try:
            import cdsapi
        except ImportError as exc:
            raise SystemExit("cdsapi is required only for Level 2 download; install it in the chosen runtime") from exc
        client = cdsapi.Client(quiet=False, progress=True)
    records = []
    failure = False
    for row in spec["requests"]:
        target = raw_dir / row["download_filename"]
        downloaded = False
        if not target.exists():
            if args.mode == "existing":
                records.append({
                    "request_id": row["request_id"], "dataset": row["dataset"], "variable": row["variable"],
                    "filename": target.name, "bytes": 0, "sha256": "", "original_bytes": row["original_archive_bytes"],
                    "original_sha256": row["original_archive_sha256"], "size_matches_original": False,
                    "sha256_matches_original": False, "status": "MISSING",
                })
                failure = True
                continue
            partial = target.with_suffix(target.suffix + ".partial")
            if partial.exists():
                raise SystemExit(f"partial download already exists; inspect it first: {partial}")
            client.retrieve(row["dataset"], row["cds_api_request_exact"], str(partial))
            partial.replace(target)
            downloaded = True
        actual_hash = digest(target)
        size_match = target.stat().st_size == row["original_archive_bytes"]
        hash_match = actual_hash == row["original_archive_sha256"]
        if hash_match:
            status = "DOWNLOADED_ORIGINAL_MATCH" if downloaded else "EXISTING_ORIGINAL_MATCH"
        elif downloaded:
            status = "DOWNLOADED_REPACKAGED_OR_CHANGED"
        else:
            status = "EXISTING_REPACKAGED_OR_CHANGED"
        records.append({
            "request_id": row["request_id"], "dataset": row["dataset"], "variable": row["variable"],
            "filename": target.name, "bytes": target.stat().st_size, "sha256": actual_hash,
            "original_bytes": row["original_archive_bytes"], "original_sha256": row["original_archive_sha256"],
            "size_matches_original": size_match, "sha256_matches_original": hash_match, "status": status,
        })
    write_reports(records, mode=args.mode, raw_dir=raw_dir, report_dir=args.report_dir.resolve(), free_before=usage.free, required=required)
    if failure:
        raise SystemExit("ERA5 archive availability/checksum audit failed; see ERA5_REDOWNLOAD_REPORT.md")


if __name__ == "__main__":
    main()
