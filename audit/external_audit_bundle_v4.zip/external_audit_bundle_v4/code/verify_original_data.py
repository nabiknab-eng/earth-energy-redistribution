#!/usr/bin/env python3
"""Validate product identity and decoded metadata after a fresh download."""

from __future__ import annotations

import argparse
import csv
import gzip
import json
from pathlib import Path
import zipfile

from netCDF4 import Dataset
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SPECS = ROOT / "download_specs"


def finite_sample(variable) -> bool:
    selection = (0,) + tuple(slice(None) for _ in variable.shape[1:]) if variable.ndim else ()
    values = np.asarray(np.ma.filled(variable[selection], np.nan), dtype=float)
    return bool(np.isfinite(values).any())


def check_ceres(workspace: Path) -> list[dict]:
    spec = json.loads((SPECS / "ceres_ebaf_ed4.2.1.json").read_text())
    path = workspace / "raw" / "ceres" / spec["local_subset_filename"]
    required = set(spec["variables"])
    with Dataset(path) as ds:
        missing = required - set(ds.variables)
        valid = (
            not missing
            and len(ds.dimensions["lat"]) == 180
            and len(ds.dimensions["time"]) == 313
            and all(getattr(ds[name], "units", "") == "W m-2" for name in required if name.startswith(("z", "g")))
            and finite_sample(ds["ztoa_net_all_mon"])
        )
        detail = f"time={len(ds.dimensions['time'])}, lat={len(ds.dimensions['lat'])}, missing={sorted(missing)}"
    return [{"dataset": "CERES", "check": "Edition4.2.1 zonal subset contract", "status": "PASS" if valid else "FAIL", "detail": detail}]


def check_ohc(workspace: Path) -> list[dict]:
    spec = json.loads((SPECS / "ncei_ohc_0_2000_monthly.json").read_text())
    path = workspace / "raw" / "ohc" / spec["local_original_filename"]
    with Dataset(path) as ds:
        title = getattr(ds, "title", "")
        variable = ds["h18_hc"]
        valid = (
            "0-2000 m monthly 1.00 degree" in title
            and variable.shape[1:] == (1, 180, 360)
            and variable.shape[0] >= 216
            and getattr(variable, "units", "") == "10^18_joules"
            and finite_sample(variable)
        )
        detail = f"title={title}; shape={variable.shape}; units={getattr(variable, 'units', '')}"
    return [{"dataset": "NCEI_OHC", "check": "0-2000m monthly decoded contract", "status": "PASS" if valid else "FAIL", "detail": detail}]


def check_piomas(workspace: Path) -> list[dict]:
    records = []
    root = workspace / "raw" / "sea_ice"
    csv_path = root / "PIOMAS.monthly.Current.v2.1.csv"
    header = csv_path.read_text(errors="replace").splitlines()[0]
    records.append({"dataset": "PIOMAS", "check": "official monthly v2.1 CSV", "status": "PASS" if "year" in header.lower() else "FAIL", "detail": header})
    for year in range(2005, 2023):
        path = root / "piomas_heff" / f"heff.H{year}.nc.gz"
        payload = gzip.decompress(path.read_bytes())
        ds = Dataset("piomas.nc", memory=payload)
        needed = {"heff", "lat_scaler", "kmt", "dxt", "dyt"}
        valid = (
            needed <= set(ds.variables)
            and ds["heff"].shape == (12, 120, 360)
            and getattr(ds["heff"], "units", "") == "m"
            and "PIOMAS" in getattr(ds, "Model", "")
            and finite_sample(ds["heff"])
        )
        records.append({"dataset": "PIOMAS", "check": f"heff.H{year}.nc.gz decoded contract", "status": "PASS" if valid else "FAIL", "detail": f"shape={ds['heff'].shape}; model={getattr(ds, 'Model', '')}"})
        ds.close()
    return records


def check_era5(workspace: Path) -> list[dict]:
    spec = json.loads((SPECS / "era5_requests.json").read_text())
    records = []
    for request in spec["requests"]:
        path = workspace / "raw" / "era5" / request["download_filename"]
        with zipfile.ZipFile(path) as archive:
            names = sorted(archive.namelist())
            first = Dataset("era5.nc", memory=archive.read(names[0]))
            variable_name = "tefln" if request["variable"].startswith("vertical_integral_of_northward") else "tetend"
            expected_units = "W m**-1" if variable_name == "tefln" else "W m**-2"
            valid = (
                len(names) == request["expected_monthly_members"]
                and getattr(first, "version", "") == "v1.0"
                and variable_name in first.variables
                and getattr(first[variable_name], "units", "") == expected_units
                and first[variable_name].shape[0] == 1
                and finite_sample(first[variable_name])
            )
            detail = f"members={len(names)}; version={getattr(first, 'version', '')}; shape={first[variable_name].shape}; units={getattr(first[variable_name], 'units', '')}"
            first.close()
        records.append({"dataset": "ERA5", "check": request["request_id"], "status": "PASS" if valid else "FAIL", "detail": detail})
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace-dir", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace_dir.resolve()
    records = check_ceres(workspace) + check_ohc(workspace) + check_piomas(workspace) + check_era5(workspace)
    target = workspace / "provenance" / "metadata_validation.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["dataset", "check", "status", "detail"])
        writer.writeheader(); writer.writerows(records)
    failed = [row for row in records if row["status"] != "PASS"]
    print(f"metadata checks: {len(records) - len(failed)}/{len(records)} PASS -> {target}")
    if failed:
        raise SystemExit("decoded product metadata validation failed")


if __name__ == "__main__":
    main()
