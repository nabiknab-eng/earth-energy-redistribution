#!/usr/bin/env python3
"""Download every original climate input from its official source.

The bundle intentionally contains no climate data. SHA256 and original byte
counts are historical references: a mismatch is reported, never treated as a
scientific failure by itself. Product metadata and decoded numerical fields are
validated separately by ``verify_original_data.py`` and the raw reducers.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request

from netCDF4 import Dataset, num2date


ROOT = Path(__file__).resolve().parents[1]
SPECS = ROOT / "download_specs"
EXPECTED_TOTAL = 1_843_950_436
HEADROOM = 1 * 2**30


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def copy_attrs(source, target) -> None:
    for name in source.ncattrs():
        if name != "_FillValue":
            setattr(target, name, getattr(source, name))


def retrieve_url(url: str, target: Path) -> None:
    if target.exists():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_suffix(target.suffix + ".partial")
    if partial.exists():
        raise RuntimeError(f"partial download already exists: {partial}")
    request = urllib.request.Request(url, headers={"User-Agent": "external-audit-bundle-v4/1"})
    with urllib.request.urlopen(request, timeout=180) as response, partial.open("wb") as out:
        shutil.copyfileobj(response, out, length=1024 * 1024)
    partial.replace(target)


def download_ceres(workspace: Path) -> Path:
    spec = json.loads((SPECS / "ceres_ebaf_ed4.2.1.json").read_text())
    target = workspace / "raw" / "ceres" / spec["local_subset_filename"]
    if target.exists():
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    source = Dataset(spec["official_opendap_url"])
    time = source["time"][:]
    time_var = source["time"]
    dates = num2date(time, time_var.units, getattr(time_var, "calendar", "standard"))
    stop = max(i for i, date in enumerate(dates) if (date.year, date.month) <= (2026, 3)) + 1
    base = [
        "toa_sw_all_mon", "toa_lw_all_mon", "toa_net_all_mon",
        "toa_sw_clr_t_mon", "toa_lw_clr_t_mon", "toa_net_clr_t_mon",
        "toa_cre_sw_mon", "toa_cre_lw_mon", "toa_cre_net_mon", "solar_mon",
    ]
    partial = target.with_suffix(target.suffix + ".partial")
    with Dataset(partial, "w", format="NETCDF4") as output:
        output.createDimension("time", stop)
        output.createDimension("lat", len(source.dimensions["lat"]))
        output.source_url = spec["official_opendap_url"]
        output.subset_note = "Native CERES global and zonal monthly variables only; 2000-03 through 2026-03."
        for coordinate in ("time", "lat"):
            variable = source[coordinate]
            copy = output.createVariable(coordinate, variable.dtype, (coordinate,))
            copy_attrs(variable, copy)
            copy[:] = variable[:stop] if coordinate == "time" else variable[:]
        for prefix, dimensions in (("z", ("time", "lat")), ("g", ("time",))):
            for suffix in base:
                name = prefix + suffix
                variable = source[name]
                options = {"zlib": True, "complevel": 4, "shuffle": True}
                if hasattr(variable, "_FillValue"):
                    options["fill_value"] = variable._FillValue
                copy = output.createVariable(name, variable.dtype, dimensions, **options)
                copy_attrs(variable, copy)
                copy[:] = variable[:stop]
    source.close()
    partial.replace(target)
    return target


def download_ohc(workspace: Path) -> Path:
    spec = json.loads((SPECS / "ncei_ohc_0_2000_monthly.json").read_text())
    target = workspace / "raw" / "ohc" / spec["local_original_filename"]
    retrieve_url(spec["official_url"], target)
    return target


def download_piomas(workspace: Path) -> list[Path]:
    spec = json.loads((SPECS / "piomas_v2.1.json").read_text())
    historical = json.loads((SPECS / "piomas_original_files.json").read_text())
    targets = []
    for row in historical:
        relative = Path(row["path"])
        target = workspace / relative
        if target.name == "PIOMAS.monthly.Current.v2.1.csv":
            url = spec["official_monthly_volume_url"]
        else:
            url = spec["official_heff_base_url"] + target.name
        retrieve_url(url, target)
        targets.append(target)
    return targets


def run_era5(workspace: Path, mode: str) -> None:
    command = [
        sys.executable,
        str(ROOT / "code" / "era5" / "download_era5_for_independent_audit.py"),
        "--mode", mode,
        "--raw-dir", str(workspace / "raw" / "era5"),
        "--report-dir", str(workspace / "provenance"),
    ]
    subprocess.run(command, check=True)


def historical_rows(workspace: Path) -> list[dict]:
    rows = []
    ceres = json.loads((SPECS / "ceres_ebaf_ed4.2.1.json").read_text())
    ohc = json.loads((SPECS / "ncei_ohc_0_2000_monthly.json").read_text())
    rows.extend([
        {"dataset": "CERES", "path": f"raw/ceres/{ceres['local_subset_filename']}", "original_bytes": ceres["original_local_bytes"], "original_sha256": ceres["original_local_sha256"]},
        {"dataset": "NCEI_OHC", "path": f"raw/ohc/{ohc['local_original_filename']}", "original_bytes": ohc["original_local_bytes"], "original_sha256": ohc["original_local_sha256"]},
    ])
    for row in json.loads((SPECS / "piomas_original_files.json").read_text()):
        rows.append({"dataset": "PIOMAS", "path": row["path"], "original_bytes": row["bytes"], "original_sha256": row["sha256"]})
    era = json.loads((SPECS / "era5_requests.json").read_text())
    for row in era["requests"]:
        rows.append({"dataset": "ERA5", "path": f"raw/era5/{row['download_filename']}", "original_bytes": row["original_archive_bytes"], "original_sha256": row["original_archive_sha256"]})
    return rows


def write_report(workspace: Path) -> None:
    target = workspace / "provenance" / "download_report.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    records = []
    for row in historical_rows(workspace):
        path = workspace / row["path"]
        exists = path.is_file()
        actual_size = path.stat().st_size if exists else 0
        actual_hash = digest(path) if exists else ""
        records.append({
            **row,
            "actual_bytes": actual_size,
            "actual_sha256": actual_hash,
            "byte_size_matches_historical": exists and actual_size == row["original_bytes"],
            "sha256_matches_historical": exists and actual_hash == row["original_sha256"],
            "status": "PRESENT_METADATA_VALIDATION_PENDING" if exists else "MISSING",
        })
    with target.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    if any(row["status"] == "MISSING" for row in records):
        raise RuntimeError(f"download incomplete; see {target}")
    print(f"Historical SHA matches: {sum(r['sha256_matches_historical'] for r in records)}/{len(records)}")
    print("SHA mismatches are informational; decoded metadata and fields are checked next.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace-dir", type=Path, default=ROOT / "work" / "reproduction_workspace")
    parser.add_argument("--mode", choices=("download", "existing", "dry-run"), default="download")
    args = parser.parse_args()
    workspace = args.workspace_dir.resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(workspace).free
    print(f"Expected original input volume: {EXPECTED_TOTAL:,} bytes ({EXPECTED_TOTAL / 2**30:.3f} GiB)")
    print(f"Recommended free space including 1 GiB headroom: {EXPECTED_TOTAL + HEADROOM:,} bytes")
    print(f"Free space: {free:,} bytes")
    if free < EXPECTED_TOTAL + HEADROOM:
        raise SystemExit("insufficient disk space for raw inputs and processing headroom")
    if args.mode == "dry-run":
        run_era5(workspace, "dry-run")
        print("DRY RUN PASS: no network call and no climate calculation was performed")
        return
    if args.mode == "existing":
        run_era5(workspace, "existing")
        write_report(workspace)
        return
    download_ceres(workspace)
    download_ohc(workspace)
    download_piomas(workspace)
    run_era5(workspace, "download")
    write_report(workspace)


if __name__ == "__main__":
    main()
