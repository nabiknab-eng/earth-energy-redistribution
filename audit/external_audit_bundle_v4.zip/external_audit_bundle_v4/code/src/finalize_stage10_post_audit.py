"""Finalize Stage 10 post-audit inference from existing reduced data only."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import block_mean_tendency
from src.energy_budget import PW, decimal_year
from src.post_audit_statistics import strict_hac_trend


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
KEY_LATITUDES = (50.0, 60.0, 65.0, 70.0, 75.0, 80.0)
RHO_ICE = 917.0
LATENT_HEAT_FUSION = 334_000.0
SECONDS_PER_YEAR = 365.2425 * 86400.0


def load_calibration() -> tuple[dict, pd.DataFrame]:
    metadata = json.loads((OUT / "monte_carlo_calibration_metadata.json").read_text())
    matrix = pd.read_csv(OUT / "monte_carlo_calibration_matrix.csv")
    return metadata, matrix


def calibrated_trend(values: np.ndarray, index: pd.DatetimeIndex, estimator: str, metadata: dict):
    lag = 2 if estimator == "annual_difference" else 24
    critical = float(metadata["calibrated_critical_values"][estimator])
    return strict_hac_trend(values, index, maxlags=lag, critical_value=critical)


def piomas_rescaling_audit(metadata: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    ice = pd.read_csv(OUT / "sea_ice_cap_monthly_energy.csv", parse_dates=["time"])
    factor_series = (
        ice[ice.boundary_deg_n == 50.0][["time", "grid_to_official_scale"]]
        .drop_duplicates("time")
        .sort_values("time")
    )
    index = pd.DatetimeIndex(factor_series.time)
    factor = factor_series.grid_to_official_scale.to_numpy(float)
    x = decimal_year(index)
    xc = x - x.mean()
    quad = np.polyfit(xc, factor, 2)
    factor_trend_dec = float(quad[1] * 10.0)
    factor_second_derivative_dec2 = float(2.0 * quad[0] * 100.0)
    ftime, df_dt_s = block_mean_tendency(factor, index)
    df_dt_year = df_dt_s * SECONDS_PER_YEAR

    stage = pd.read_csv(OUT / "storage_corrected_transport_timeseries.csv", parse_dates=["time"])
    stage = stage[(stage.hemisphere == "NH") & (stage.method == "block_12m_means")]
    rows = []
    diagnostics = []
    constant_factor = float(np.mean(factor))
    for boundary in sorted(ice.boundary_deg_n.unique()):
        b = ice[ice.boundary_deg_n == boundary].sort_values("time")
        bindex = pd.DatetimeIndex(b.time)
        scale = b.grid_to_official_scale.to_numpy(float)
        corrected_volume = b.sea_ice_volume_1000_km3.to_numpy(float)
        unscaled_volume = corrected_volume / scale
        volumes = {
            "monthly_official_scaling": corrected_volume,
            "constant_mean_scaling": unscaled_volume * constant_factor,
            "no_scaling": unscaled_volume,
        }
        hbase = stage[stage.boundary_abs_deg == boundary].sort_values("time")
        if hbase.empty:
            continue
        index_h = pd.DatetimeIndex(hbase.time)
        method_trends = {}
        ice_tendency_current = None
        for method, volume in volumes.items():
            energy = -volume * 1e12 * RHO_ICE * LATENT_HEAT_FUSION
            dtime, tendency_w = block_mean_tendency(energy, bindex)
            if not dtime.equals(index_h):
                raise RuntimeError("PIOMAS sensitivity and transport timestamps do not align")
            tendency_pw = tendency_w / PW
            hcorr = hbase.h_known_pw.to_numpy(float) + tendency_pw
            ice_tr = calibrated_trend(tendency_pw, dtime, "block_12m_means", metadata)
            h_tr = calibrated_trend(hcorr, dtime, "block_12m_means", metadata)
            method_trends[method] = h_tr.slope_tw_dec
            if method == "monthly_official_scaling":
                ice_tendency_current = tendency_pw
            rows.append(
                {
                    "boundary_deg_n": boundary,
                    "scaling_method": method,
                    "sea_ice_storage_trend_tw_dec": ice_tr.slope_tw_dec,
                    "h_corr_trend_tw_dec": h_tr.slope_tw_dec,
                    "h_corr_ci_low_tw_dec": h_tr.ci_low_tw_dec,
                    "h_corr_ci_high_tw_dec": h_tr.ci_high_tw_dec,
                    "calibrated_ci_halfwidth_tw_dec": 0.5 * (h_tr.ci_high_tw_dec - h_tr.ci_low_tw_dec),
                }
            )
        if ice_tendency_current is None:
            raise RuntimeError("current PIOMAS tendency was not built")
        diagnostics.append(
            {
                "boundary_deg_n": boundary,
                "factor_min": float(factor.min()),
                "factor_max": float(factor.max()),
                "factor_mean": constant_factor,
                "factor_linear_trend_per_decade": factor_trend_dec,
                "factor_quadratic_second_derivative_per_decade2": factor_second_derivative_dec2,
                "correlation_factor_tendency_vs_sea_ice_storage": float(np.corrcoef(df_dt_year, ice_tendency_current)[0, 1]),
                "monthly_minus_constant_hcorr_trend_tw_dec": method_trends["monthly_official_scaling"] - method_trends["constant_mean_scaling"],
                "monthly_minus_unscaled_hcorr_trend_tw_dec": method_trends["monthly_official_scaling"] - method_trends["no_scaling"],
                "maximum_abs_rescaling_sensitivity_tw_dec": float(max(abs(method_trends["monthly_official_scaling"] - method_trends["constant_mean_scaling"]), abs(method_trends["monthly_official_scaling"] - method_trends["no_scaling"]))),
                "interpretation": "quantified method sensitivity, not independent PIOMAS structural uncertainty",
            }
        )
    detail = pd.DataFrame(rows)
    diag = pd.DataFrame(diagnostics)
    detail.to_csv(OUT / "piomas_rescaling_sensitivity.csv", index=False)
    diag.to_csv(OUT / "piomas_rescaling_diagnostics.csv", index=False)
    return detail, diag


def structural_rebuild(piomas_diag: pd.DataFrame) -> pd.DataFrame:
    old = pd.read_csv(OUT / "missing_storage_structural_bounds.csv")
    old_sum = old.groupby("boundary_deg_n").structural_bound_plus_minus_tw_dec.sum()
    piomas = piomas_diag.set_index("boundary_deg_n")
    rows = []
    components = [
        ("ocean_below_2000m", "UNQUANTIFIED", "No cap-resolved independent deep-ocean trend uncertainty is available in the current data."),
        ("OHC_mapping_sampling", "UNQUANTIFIED", "The product supplies global/hemispheric standard errors, not cap-resolved spatial error covariance; an MDE floor is not independent."),
        ("sea_ice_PIOMAS_model", "UNQUANTIFIED", "Only one sea-ice reanalysis is used; Earth-area scaling is physically inapplicable."),
        ("land_heat", "UNQUANTIFIED", "No cap-resolved land heat inventory with an independent trend uncertainty is present."),
        ("glacier_and_ice_sheet_enthalpy", "UNQUANTIFIED", "The former 3.0/1.5 TW per decade step had no data or geometric basis."),
        ("ERA5_AHT_structural", "UNQUANTIFIED", "Formal time-series uncertainty does not quantify observing-system/reanalysis structural uncertainty."),
    ]
    for boundary in sorted(piomas.index):
        rows.append(
            {
                "boundary_deg_n": boundary,
                "component": "PIOMAS_uniform_rescaling_method_sensitivity",
                "status": "QUANTIFIED_METHOD_SCENARIO",
                "plus_minus_tw_dec": float(piomas.loc[boundary].maximum_abs_rescaling_sensitivity_tw_dec),
                "independent_physical_bound": False,
                "basis": "maximum absolute H_corr trend change among monthly, constant-mean, and no gridded-volume rescaling",
                "retired_original_total_structural_bound_tw_dec": float(old_sum.loc[boundary]),
            }
        )
        for component, status, basis in components:
            rows.append(
                {
                    "boundary_deg_n": boundary,
                    "component": component,
                    "status": status,
                    "plus_minus_tw_dec": np.nan,
                    "independent_physical_bound": False,
                    "basis": basis,
                    "retired_original_total_structural_bound_tw_dec": float(old_sum.loc[boundary]),
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "post_audit_structural_uncertainty.csv", index=False)
    return out


def post_audit_inference(metadata: dict, matrix: pd.DataFrame, piomas_diag: pd.DataFrame):
    ts = pd.read_csv(OUT / "storage_corrected_transport_timeseries.csv", parse_dates=["time"])
    ts = ts[(ts.hemisphere == "NH") & (ts.method == "block_12m_means")]
    pre = pd.read_csv(OUT / "audit_pre_correction_key_results.csv").set_index("boundary_deg_n")
    piomas = piomas_diag.set_index("boundary_deg_n")
    metric_columns = {
        "raw_ceres": "raw_implied_pw",
        "h_known": "h_known_pw",
        "h_corr": "h_known_plus_sea_ice_pw",
        "storage_alias": "storage_alias_known_plus_sea_ice_pw",
        "era5_aht": "actual_aht_poleward_pw",
        "unresolved_remainder": "unresolved_closure_remainder_pw",
    }
    selected = matrix[matrix.inference_method == "MC_envelope_calibrated_selected_HAC"]
    coverage_min = float(selected[selected.estimator == "block_12m_means"].coverage.min())
    coverage_max = float(selected[selected.estimator == "block_12m_means"].coverage.max())
    critical_full = float(metadata["calibrated_critical_values"]["block_12m_means"])
    dgp_crit = metadata["calibrated_critical_values_by_dgp"]["block_12m_means"]
    critical_nonextreme = max(v for k, v in dgp_crit.items() if k != "ar1_0.9")
    uncertainty_rows = []
    wide_rows = []
    alias_rows = []
    unquantified = "deep ocean >2000 m; cap-resolved OHC mapping/sampling; PIOMAS model structure; land heat; glacier/ice-sheet enthalpy; ERA5 structural trend error"
    for boundary, group in ts.groupby("boundary_abs_deg"):
        group = group.sort_values("time")
        index = pd.DatetimeIndex(group.time)
        results = {}
        for metric, column in metric_columns.items():
            tr = calibrated_trend(group[column].to_numpy(float), index, "block_12m_means", metadata)
            results[metric] = tr
            uncertainty_rows.append(
                {
                    "boundary_deg_n": boundary,
                    "metric": metric,
                    "best_estimate_tw_dec": tr.slope_tw_dec,
                    "reported_se_hac24_tw_dec": tr.se_tw_dec,
                    "calibrated_critical_value": critical_full,
                    "calibrated_ci_low_tw_dec": tr.ci_low_tw_dec,
                    "calibrated_ci_high_tw_dec": tr.ci_high_tw_dec,
                    "empirical_detection_limit_tw_dec": 0.5 * (tr.ci_high_tw_dec - tr.ci_low_tw_dec),
                    "nonextreme_dgp_sensitivity_halfwidth_tw_dec": tr.se_tw_dec * critical_nonextreme,
                    "calibration_empirical_coverage_range": f"{coverage_min:.3f}--{coverage_max:.3f}",
                    "quantified_piomas_rescaling_scenario_plus_minus_tw_dec": float(piomas.loc[boundary].maximum_abs_rescaling_sensitivity_tw_dec) if metric in {"h_corr", "storage_alias", "unresolved_remainder"} else 0.0,
                    "unquantified_structural_limitations": unquantified,
                    "combined_safe_threshold": np.nan,
                }
            )
        h = results["h_corr"]
        mean_h = float(group.h_known_plus_sea_ice_pw.mean())
        robust = pd.read_csv(OUT / "storage_trend_robustness_summary.csv")
        robust_row = robust[(robust.hemisphere == "NH") & (robust.boundary_abs_deg == boundary) & (robust.metric == "h_known_plus_sea_ice")]
        sign_stability = float(robust_row.fraction_same_sign_as_full.iloc[0]) if len(robust_row) else np.nan
        if h.ci_low_tw_dec <= 0 <= h.ci_high_tw_dec:
            decision = "NOT DETECTED"
        else:
            decision = "PHYSICALLY INDETERMINATE"
        row = {
            "boundary_deg_n": boundary,
            "raw_ceres_trend_tw_dec": results["raw_ceres"].slope_tw_dec,
            "h_known_trend_tw_dec": results["h_known"].slope_tw_dec,
            "h_corr_trend_tw_dec": h.slope_tw_dec,
            "h_corr_calibrated_ci_low_tw_dec": h.ci_low_tw_dec,
            "h_corr_calibrated_ci_high_tw_dec": h.ci_high_tw_dec,
            "h_corr_empirical_detection_limit_tw_dec": 0.5 * (h.ci_high_tw_dec - h.ci_low_tw_dec),
            "h_corr_nonextreme_dgp_halfwidth_tw_dec": h.se_tw_dec * critical_nonextreme,
            "detection_limit_percent_of_climatological_transport_per_decade": (0.5 * (h.ci_high_tw_dec - h.ci_low_tw_dec)) / abs(mean_h * 1000.0) * 100.0,
            "storage_alias_trend_tw_dec": results["storage_alias"].slope_tw_dec,
            "storage_alias_ci_low_tw_dec": results["storage_alias"].ci_low_tw_dec,
            "storage_alias_ci_high_tw_dec": results["storage_alias"].ci_high_tw_dec,
            "era5_aht_trend_tw_dec": results["era5_aht"].slope_tw_dec,
            "era5_aht_ci_low_tw_dec": results["era5_aht"].ci_low_tw_dec,
            "era5_aht_ci_high_tw_dec": results["era5_aht"].ci_high_tw_dec,
            "unresolved_remainder_trend_tw_dec": results["unresolved_remainder"].slope_tw_dec,
            "unresolved_remainder_ci_low_tw_dec": results["unresolved_remainder"].ci_low_tw_dec,
            "unresolved_remainder_ci_high_tw_dec": results["unresolved_remainder"].ci_high_tw_dec,
            "quantified_piomas_rescaling_scenario_plus_minus_tw_dec": float(piomas.loc[boundary].maximum_abs_rescaling_sensitivity_tw_dec),
            "unquantified_structural_uncertainty": unquantified,
            "window_fraction_same_sign": sign_stability,
            "post_audit_decision": decision,
            "safe_threshold_retired": True,
        }
        if boundary in pre.index:
            old = pre.loc[boundary]
            row.update(
                {
                    "pre_audit_h_corr_trend_tw_dec": old.h_known_plus_si_trend_tw_dec,
                    "point_estimate_change_tw_dec": h.slope_tw_dec - old.h_known_plus_si_trend_tw_dec,
                    "pre_audit_temporal_mde95_tw_dec": old.temporal_mde95_tw_dec,
                    "pre_audit_structural_bound_tw_dec": old.structural_bound_tw_dec,
                    "pre_audit_safe_threshold_tw_dec": old.conservative_safe_threshold_tw_dec,
                }
            )
        wide_rows.append(row)
        alias_rows.append(
            {
                "boundary_deg_n": boundary,
                "alias_best_estimate_tw_dec": results["storage_alias"].slope_tw_dec,
                "calibrated_ci_low_tw_dec": results["storage_alias"].ci_low_tw_dec,
                "calibrated_ci_high_tw_dec": results["storage_alias"].ci_high_tw_dec,
                "calibrated_temporal_halfwidth_tw_dec": 0.5 * (results["storage_alias"].ci_high_tw_dec - results["storage_alias"].ci_low_tw_dec),
                "ci_excludes_zero": bool(results["storage_alias"].ci_low_tw_dec > 0 or results["storage_alias"].ci_high_tw_dec < 0),
                "joint_series_covariance_treatment": "trend and interval computed directly from monthly alias time series; covariance is retained",
                "interpretation": "difference between uniform global-storage proxy and known regional storage, not independent transport evidence",
            }
        )
    uncertainty = pd.DataFrame(uncertainty_rows)
    wide = pd.DataFrame(wide_rows)
    alias = pd.DataFrame(alias_rows)
    uncertainty.to_csv(OUT / "POST_AUDIT_UNCERTAINTY.csv", index=False)
    wide[wide.boundary_deg_n.isin(KEY_LATITUDES)].to_csv(OUT / "POST_AUDIT_KEY_RESULTS.csv", index=False)
    alias.to_csv(OUT / "STORAGE_ALIAS_WITH_CI.csv", index=False)
    return uncertainty, wide, alias


def derivative_recalibration(metadata: dict) -> pd.DataFrame:
    ts = pd.read_csv(OUT / "storage_corrected_transport_timeseries.csv", parse_dates=["time"])
    annual = pd.read_csv(OUT / "storage_annual_difference_timeseries.csv", parse_dates=["time"])
    old_annual = pd.read_csv(OUT / "audit_pre_correction_snapshot_20260808/results/storage_annual_difference_profile.csv")
    rows = []
    for estimator in ("block_12m_means", "central_12m_endpoints"):
        source = ts[(ts.hemisphere == "NH") & (ts.method == estimator)]
        for boundary, group in source.groupby("boundary_abs_deg"):
            group = group.sort_values("time")
            tr = calibrated_trend(group.h_known_plus_sea_ice_pw.to_numpy(float), pd.DatetimeIndex(group.time), estimator, metadata)
            rows.append({"boundary_deg_n": boundary, "estimator": estimator, "best_estimate_tw_dec": tr.slope_tw_dec, "calibrated_ci_low_tw_dec": tr.ci_low_tw_dec, "calibrated_ci_high_tw_dec": tr.ci_high_tw_dec, "old_ci_invalid": False})
    source = annual[annual.hemisphere == "NH"]
    for boundary, group in source.groupby("boundary_abs_deg"):
        group = group.sort_values("time")
        tr = calibrated_trend(group.h_known_plus_sea_ice_pw.to_numpy(float), pd.DatetimeIndex(group.time), "annual_difference", metadata)
        old = old_annual[(old_annual.hemisphere == "NH") & (old_annual.boundary_abs_deg == boundary) & (old_annual.metric == "h_known_plus_sea_ice")].iloc[0]
        rows.append({"boundary_deg_n": boundary, "estimator": "annual_difference", "best_estimate_tw_dec": tr.slope_tw_dec, "calibrated_ci_low_tw_dec": tr.ci_low_tw_dec, "calibrated_ci_high_tw_dec": tr.ci_high_tw_dec, "old_ci_low_tw_dec": old.ci_low_tw_dec, "old_ci_high_tw_dec": old.ci_high_tw_dec, "old_ci_invalid": True})
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "post_audit_derivative_sensitivity.csv", index=False)
    return out


def diagnostic_classification() -> pd.DataFrame:
    rows = [
        ("raw-minus-corrected equals storage alias", "ALGEBRAIC_IDENTITY", "Checks implementation arithmetic only; not independent evidence."),
        ("N_cap - storage + corrected = 0", "ALGEBRAIC_IDENTITY", "Must hold because corrected is defined as storage - N_cap."),
        ("global-mean cancellation from H_corr", "ALGEBRAIC_IDENTITY", "Symbolic cancellation; numerical test guards column wiring."),
        ("sphere and cap areas", "NUMERICAL_IMPLEMENTATION_TEST", "Independent analytic geometry can detect area-weight errors."),
        ("south-to-north and north-to-south integration", "NUMERICAL_IMPLEMENTATION_TEST", "Independent integration directions can diverge if signs/weights are wrong."),
        ("NCEI OHC mask static", "DATA_INTEGRITY_TEST", "Can detect a changing product mask, but cannot detect changing Argo sampling/mapping error."),
        ("ERA5 duplicate longitude handling", "DATA_IMPLEMENTATION_TEST", "Can detect 0/360 double counting."),
        ("PIOMAS gridded total rescaled to official total", "ALGEBRAIC_IDENTITY", "Validates rescaling arithmetic, not spatial validity of uniform scaling."),
        ("Monte Carlo interval coverage", "INDEPENDENT_STATISTICAL_TEST", "Can falsify nominal interval calibration."),
        ("synthetic derivative exactness", "INDEPENDENT_NUMERICAL_TEST", "Known state/tendency exposes derivative bias and unit errors."),
    ]
    out = pd.DataFrame(rows, columns=["diagnostic", "class", "interpretation"])
    out.to_csv(OUT / "post_audit_diagnostic_classification.csv", index=False)
    return out


def make_plots(wide: pd.DataFrame, alias: pd.DataFrame, uncertainty: pd.DataFrame, piomas_diag: pd.DataFrame) -> None:
    key = wide[wide.boundary_deg_n.isin(KEY_LATITUDES)].copy()
    x = np.arange(len(key))
    pre_half = key.pre_audit_temporal_mde95_tw_dec.to_numpy(float)
    post_half = key.h_corr_empirical_detection_limit_tw_dec.to_numpy(float)
    fig, ax = plt.subplots(figsize=(9.2, 5.4))
    ax.errorbar(x - 0.10, key.pre_audit_h_corr_trend_tw_dec, yerr=pre_half, fmt="o", capsize=3, color="#888888", label="Před auditem: nominální HAC(24) 95%")
    ax.errorbar(x + 0.10, key.h_corr_trend_tw_dec, yerr=post_half, fmt="o", capsize=3, color="#0b6e99", label="Po auditu: MC-kalibrovaný 95% obal")
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xticks(x, [f"{int(v)}°N" for v in key.boundary_deg_n])
    ax.set_ylabel("Trend H_corr (TW/dekádu)")
    ax.set_title("Stejné bodové trendy, kalibrovaná temporální nejistota")
    ax.legend(frameon=False)
    fig.tight_layout(); fig.savefig(OUT / "pre_vs_post_audit_ci.png", dpi=200); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9.2, 5.4))
    ax.plot(wide.boundary_deg_n, wide.pre_audit_temporal_mde95_tw_dec, color="#888888", label="Původní nominální MDE95")
    ax.plot(wide.boundary_deg_n, wide.h_corr_nonextreme_dgp_halfwidth_tw_dec, color="#e69f00", label="MC citlivost bez AR(1) φ=0,9")
    ax.plot(wide.boundary_deg_n, wide.h_corr_empirical_detection_limit_tw_dec, color="#0b6e99", lw=2.2, label="Deklarovaný plný MC obal")
    ax.set(xlabel="Severní hranice čepičky", ylabel="Temporální 95% půlšířka (TW/dekádu)", title="Empirický detekční limit required transportu")
    ax.legend(frameon=False); fig.tight_layout(); fig.savefig(OUT / "calibrated_detection_limit_vs_latitude.png", dpi=200); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9.2, 5.4))
    half = 0.5 * (alias.calibrated_ci_high_tw_dec - alias.calibrated_ci_low_tw_dec)
    ax.plot(alias.boundary_deg_n, alias.alias_best_estimate_tw_dec, color="#6a4c93", lw=2)
    ax.fill_between(alias.boundary_deg_n, alias.alias_best_estimate_tw_dec - half, alias.alias_best_estimate_tw_dec + half, color="#6a4c93", alpha=0.18, label="MC-kalibrovaný temporální 95% obal")
    ax.axhline(0, color="black", lw=0.8)
    ax.set(xlabel="Severní hranice čepičky", ylabel="Trend storage alias (TW/dekádu)", title="Storage alias: společná časová řada zachovává kovarianci")
    ax.legend(frameon=False); fig.tight_layout(); fig.savefig(OUT / "storage_alias_with_ci.png", dpi=200); plt.close(fig)

    fig, (ax_top, ax_bottom) = plt.subplots(2, 1, figsize=(9.6, 7.0), sharex=True, gridspec_kw={"height_ratios": [2.0, 1.0]})
    p = piomas_diag.set_index("boundary_deg_n").loc[key.boundary_deg_n]
    ax_top.bar(x, key.h_corr_empirical_detection_limit_tw_dec, width=0.58, color="#0b6e99", label="Temporální MC 95% půlšířka")
    ax_top.set_ylabel("TW/dekádu")
    ax_top.set_title("Oddělené složky nejistoty — combined safe threshold se nevytváří")
    ax_top.text(0.01, 0.96, "Nevyčísleno: deep ocean, cap OHC mapping, land/glacier storage, PIOMAS/ERA5 structure", transform=ax_top.transAxes, va="top", fontsize=8)
    ax_top.legend(frameon=False, loc="upper right")
    ax_bottom.bar(x, p.maximum_abs_rescaling_sensitivity_tw_dec, width=0.58, color="#cc79a7", label="PIOMAS rescaling: metodický scénář")
    ax_bottom.set_xticks(x, [f"{int(v)}°N" for v in key.boundary_deg_n])
    ax_bottom.set_ylabel("TW/dekádu")
    ax_bottom.set_ylim(0, max(0.4, 1.15 * float(p.maximum_abs_rescaling_sensitivity_tw_dec.max())))
    ax_bottom.legend(frameon=False, loc="upper right")
    fig.tight_layout(); fig.savefig(OUT / "uncertainty_decomposition_post_audit.png", dpi=200); plt.close(fig)


def main() -> None:
    metadata, matrix = load_calibration()
    _, piomas_diag = piomas_rescaling_audit(metadata)
    structural_rebuild(piomas_diag)
    uncertainty, wide, alias = post_audit_inference(metadata, matrix, piomas_diag)
    derivative_recalibration(metadata)
    diagnostic_classification()
    make_plots(wide, alias, uncertainty, piomas_diag)
    print(wide[wide.boundary_deg_n.isin(KEY_LATITUDES)][["boundary_deg_n", "h_corr_trend_tw_dec", "h_corr_calibrated_ci_low_tw_dec", "h_corr_calibrated_ci_high_tw_dec", "h_corr_empirical_detection_limit_tw_dec", "storage_alias_trend_tw_dec", "storage_alias_ci_low_tw_dec", "storage_alias_ci_high_tw_dec", "era5_aht_trend_tw_dec", "post_audit_decision"]].to_string(index=False))


if __name__ == "__main__":
    main()
