"""Statistical utilities used by the Stage 10 adversarial audit.

The module is deliberately separate from the frozen Stage 9 implementation.
It reproduces the legacy HAC calculation, provides a strict corrected version,
and generates physically consistent synthetic storage states whose derivative
has a known linear trend.
"""

from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
import pandas as pd
from scipy.stats import norm

from src.energy_budget import decimal_year


TW_PER_PW_PER_DECADE = 10_000.0


@dataclass(frozen=True)
class InferenceResult:
    slope_tw_dec: float
    se_tw_dec: float
    ci_low_tw_dec: float
    ci_high_tw_dec: float
    n: int
    requested_lag: int
    effective_lag: int
    critical_value: float


def automatic_hac_lag(n: int) -> int:
    """Small-sample Newey--West rule, bounded by the available observations."""
    if n < 3:
        raise ValueError("at least three observations are required")
    return min(n - 1, max(0, int(math.floor(4.0 * (n / 100.0) ** (2.0 / 9.0)))))


def _prepared(values: np.ndarray, index: pd.DatetimeIndex, deseasonalize: bool) -> tuple[np.ndarray, pd.DatetimeIndex]:
    y = np.asarray(values, dtype=float)
    if y.ndim != 1 or len(y) != len(index):
        raise ValueError("values and index must be aligned one-dimensional arrays")
    ok = np.isfinite(y)
    y = y[ok]
    idx = pd.DatetimeIndex(index[ok])
    if len(y) < 3:
        raise ValueError("at least three finite observations are required")
    if deseasonalize:
        month_mean = pd.Series(y, index=idx).groupby(idx.month).transform("mean").to_numpy()
        y = y - month_mean + np.mean(y)
    return y, idx


def strict_hac_trend(
    values: np.ndarray,
    index: pd.DatetimeIndex,
    *,
    maxlags: int | None = None,
    deseasonalize: bool = True,
    critical_value: float | None = None,
) -> InferenceResult:
    """OLS slope with explicit, finite-sample-safe Newey--West covariance.

    Unlike the Stage 9 implementation, the Bartlett denominator uses the
    *effective* lag after bounding it by ``n-1``. A materially negative slope
    variance raises an error instead of being silently replaced by zero.
    """
    y, idx = _prepared(values, index, deseasonalize)
    n = len(y)
    requested = automatic_hac_lag(n) if maxlags is None else int(maxlags)
    if requested < 0:
        raise ValueError("maxlags must be non-negative")
    lag_eff = min(requested, n - 1)
    x = decimal_year(idx)
    x -= np.mean(x)
    design = np.column_stack([np.ones(n), x])
    if np.linalg.matrix_rank(design) < 2:
        raise ValueError("time design is singular")
    xtx_inv = np.linalg.inv(design.T @ design)
    beta = xtx_inv @ design.T @ y
    resid = y - design @ beta
    score = design * resid[:, None]
    meat = score.T @ score
    for lag in range(1, lag_eff + 1):
        weight = 1.0 - lag / (lag_eff + 1.0)
        gamma = score[lag:].T @ score[:-lag]
        meat += weight * (gamma + gamma.T)
    cov = (n / (n - design.shape[1])) * xtx_inv @ meat @ xtx_inv
    variance = float(cov[1, 1])
    numerical_tol = 1e-14 * max(1.0, float(np.max(np.abs(cov))))
    if variance < -numerical_tol:
        raise FloatingPointError(f"negative HAC slope variance: {variance}")
    variance = max(variance, 0.0)
    se = math.sqrt(variance)
    crit = float(norm.ppf(0.975) if critical_value is None else critical_value)
    slope = float(beta[1])
    return InferenceResult(
        slope_tw_dec=slope * TW_PER_PW_PER_DECADE,
        se_tw_dec=se * TW_PER_PW_PER_DECADE,
        ci_low_tw_dec=(slope - crit * se) * TW_PER_PW_PER_DECADE,
        ci_high_tw_dec=(slope + crit * se) * TW_PER_PW_PER_DECADE,
        n=n,
        requested_lag=requested,
        effective_lag=lag_eff,
        critical_value=crit,
    )


def legacy_hac_batch(
    series: np.ndarray,
    index: pd.DatetimeIndex,
    maxlags: int,
    *,
    deseasonalize: bool = True,
) -> tuple[np.ndarray, np.ndarray, int]:
    """Vectorized exact reproduction of the Stage 9 HAC slope and SE."""
    y = np.asarray(series, dtype=float)
    if y.ndim == 1:
        y = y[None, :]
    if y.shape[1] != len(index):
        raise ValueError("series and index do not align")
    if deseasonalize:
        y = deseasonalize_batch(y, index)
    return _hac_batch(y, index, maxlags, legacy_denominator=True)


def corrected_hac_batch(
    series: np.ndarray,
    index: pd.DatetimeIndex,
    maxlags: int,
    *,
    deseasonalize: bool = True,
) -> tuple[np.ndarray, np.ndarray, int]:
    """Vectorized HAC with the Bartlett denominator based on effective lag."""
    y = np.asarray(series, dtype=float)
    if y.ndim == 1:
        y = y[None, :]
    if y.shape[1] != len(index):
        raise ValueError("series and index do not align")
    if deseasonalize:
        y = deseasonalize_batch(y, index)
    return _hac_batch(y, index, maxlags, legacy_denominator=False)


def _hac_batch(
    y: np.ndarray,
    index: pd.DatetimeIndex,
    maxlags: int,
    *,
    legacy_denominator: bool,
) -> tuple[np.ndarray, np.ndarray, int]:
    n = y.shape[1]
    if n < 3:
        raise ValueError("at least three observations are required")
    effective = min(int(maxlags), n - 1)
    if effective < 0:
        raise ValueError("maxlags must be non-negative")
    x = decimal_year(index)
    x -= x.mean()
    design = np.column_stack([np.ones(n), x])
    xtx_inv = np.linalg.inv(design.T @ design)
    beta = y @ design @ xtx_inv
    resid = y - beta @ design.T
    score = resid[:, :, None] * design[None, :, :]
    meat = np.einsum("rni,rnj->rij", score, score)
    denominator_lag = int(maxlags) if legacy_denominator else effective
    for lag in range(1, effective + 1):
        weight = 1.0 - lag / (denominator_lag + 1.0)
        gamma = np.einsum("rni,rnj->rij", score[:, lag:, :], score[:, :-lag, :])
        meat += weight * (gamma + np.swapaxes(gamma, 1, 2))
    cov = (n / (n - 2.0)) * np.einsum("ij,rjk,kl->ril", xtx_inv, meat, xtx_inv)
    variance = cov[:, 1, 1]
    # Legacy behavior is reproduced for Monte Carlo diagnosis only.
    se = np.sqrt(np.maximum(variance, 0.0))
    return beta[:, 1] * TW_PER_PW_PER_DECADE, se * TW_PER_PW_PER_DECADE, effective


def deseasonalize_batch(series: np.ndarray, index: pd.DatetimeIndex) -> np.ndarray:
    out = np.asarray(series, dtype=float).copy()
    grand = out.mean(axis=1, keepdims=True)
    months = np.asarray(index.month)
    for month in np.unique(months):
        selected = months == month
        out[:, selected] -= out[:, selected].mean(axis=1, keepdims=True)
    out += grand
    return out


def ols_batch(series: np.ndarray, index: pd.DatetimeIndex, *, deseasonalize: bool = True) -> tuple[np.ndarray, np.ndarray]:
    y = np.asarray(series, dtype=float)
    if y.ndim == 1:
        y = y[None, :]
    if deseasonalize:
        y = deseasonalize_batch(y, index)
    x = decimal_year(index)
    x -= x.mean()
    design = np.column_stack([np.ones(len(x)), x])
    inv = np.linalg.inv(design.T @ design)
    beta = y @ design @ inv
    resid = y - beta @ design.T
    return beta[:, 1] * TW_PER_PW_PER_DECADE, resid


def moving_block_bootstrap_se_batch(
    series: np.ndarray,
    index: pd.DatetimeIndex,
    *,
    block_length: int,
    n_boot: int,
    rng: np.random.Generator,
    moving: bool,
    deseasonalize: bool = True,
) -> np.ndarray:
    """Residual block-bootstrap slope standard errors, vectorized by replicate."""
    y = np.asarray(series, dtype=float)
    if y.ndim == 1:
        y = y[None, :]
    if deseasonalize:
        y = deseasonalize_batch(y, index)
    _, resid = ols_batch(y, index, deseasonalize=False)
    n_rep, n = resid.shape
    block_length = min(max(1, int(block_length)), n)
    n_blocks = int(math.ceil(n / block_length))
    if moving:
        possible = np.arange(n)
    else:
        possible = np.arange(0, n, block_length)
    starts = rng.choice(possible, size=(n_rep, n_boot, n_blocks), replace=True)
    offsets = np.arange(block_length)
    indices = (starts[..., None] + offsets) % n
    indices = indices.reshape(n_rep, n_boot, -1)[..., :n]
    sampled = resid[np.arange(n_rep)[:, None, None], indices]
    x = decimal_year(index)
    x -= x.mean()
    slope_weights = x / np.sum(x**2)
    bootstrap_slopes = np.einsum("rbn,n->rb", sampled, slope_weights)
    return np.std(bootstrap_slopes, axis=1, ddof=1) * TW_PER_PW_PER_DECADE


def monthly_midpoints(start: str = "2005-01", periods: int = 216) -> pd.DatetimeIndex:
    months = pd.period_range(start, periods=periods, freq="M")
    starts = months.to_timestamp(how="start")
    ends = (months + 1).to_timestamp(how="start")
    return pd.DatetimeIndex([a + (b - a) / 2 for a, b in zip(starts, ends)])


def simulate_tendency_process(
    dgp: str,
    n_rep: int,
    n_time: int,
    rng: np.random.Generator,
    *,
    sigma_pw: float = 0.10,
    burn: int = 500,
) -> np.ndarray:
    """Generate monthly tendency noise in PW for the calibration DGPs."""
    innovations = rng.normal(0.0, sigma_pw, size=(n_rep, n_time + burn))
    out = np.zeros_like(innovations)
    if dgp == "white":
        out = innovations
    elif dgp.startswith("ar1_"):
        phi = float(dgp.split("_")[1])
        for t in range(1, out.shape[1]):
            out[:, t] = phi * out[:, t - 1] + innovations[:, t]
    elif dgp == "ar2_long":
        phi1, phi2 = 1.20, -0.35
        for t in range(2, out.shape[1]):
            out[:, t] = phi1 * out[:, t - 1] + phi2 * out[:, t - 2] + innovations[:, t]
    else:
        raise ValueError(dgp)
    return out[:, burn:]


def integrate_tendency(tendency_pw: np.ndarray, index: pd.DatetimeIndex) -> np.ndarray:
    """Integrate midpoint tendency into a state in PW seconds."""
    q = np.asarray(tendency_pw, dtype=float)
    state = np.zeros_like(q)
    seconds = np.asarray([(b - a).total_seconds() for a, b in zip(index[:-1], index[1:])])
    increments = 0.5 * (q[:, :-1] + q[:, 1:]) * seconds[None, :]
    state[:, 1:] = np.cumsum(increments, axis=1)
    return state


def block_mean_derivative_batch(state: np.ndarray, index: pd.DatetimeIndex, block: int = 12) -> tuple[pd.DatetimeIndex, np.ndarray]:
    y = np.asarray(state, dtype=float)
    positions = np.arange(block, y.shape[1] - block + 1)
    cs = np.concatenate([np.zeros((y.shape[0], 1)), np.cumsum(y, axis=1)], axis=1)
    previous = (cs[:, positions] - cs[:, positions - block]) / block
    following = (cs[:, positions + block] - cs[:, positions]) / block
    dt = []
    for t in positions:
        origin = index[0]
        p = np.mean([(stamp - origin).total_seconds() for stamp in index[t - block : t]])
        f = np.mean([(stamp - origin).total_seconds() for stamp in index[t : t + block]])
        dt.append(f - p)
    return pd.DatetimeIndex(index[positions]), (following - previous) / np.asarray(dt)[None, :]


def central_derivative_batch(state: np.ndarray, index: pd.DatetimeIndex, halfspan: int = 6) -> tuple[pd.DatetimeIndex, np.ndarray]:
    y = np.asarray(state, dtype=float)
    positions = np.arange(halfspan, y.shape[1] - halfspan)
    dt = np.asarray(
        [
            (index[t + halfspan] - index[t - halfspan]).total_seconds()
            for t in positions
        ]
    )
    return pd.DatetimeIndex(index[positions]), (y[:, positions + halfspan] - y[:, positions - halfspan]) / dt[None, :]


def _state_at_batch(state: np.ndarray, index: pd.DatetimeIndex, target: pd.Timestamp) -> np.ndarray:
    origin = index[0]
    seconds = np.asarray([(stamp - origin).total_seconds() for stamp in index])
    target_s = (target - origin).total_seconds()
    right = int(np.searchsorted(seconds, target_s))
    if right == 0 or right == len(seconds):
        raise ValueError("target lies outside state series")
    left = right - 1
    weight = (target_s - seconds[left]) / (seconds[right] - seconds[left])
    return state[:, left] * (1.0 - weight) + state[:, right] * weight


def annual_difference_batch(state: np.ndarray, index: pd.DatetimeIndex) -> tuple[pd.DatetimeIndex, np.ndarray]:
    values = []
    dates = []
    for year in range(2006, 2022):
        start = pd.Timestamp(year, 1, 1)
        end = pd.Timestamp(year + 1, 1, 1)
        values.append((_state_at_batch(state, index, end) - _state_at_batch(state, index, start)) / (end - start).total_seconds())
        dates.append(pd.Timestamp(year, 7, 1))
    return pd.DatetimeIndex(dates), np.column_stack(values)


def synthetic_estimator_series(
    dgp: str,
    trend_tw_dec: float,
    n_rep: int,
    rng: np.random.Generator,
) -> dict[str, tuple[pd.DatetimeIndex, np.ndarray]]:
    """Return three derivative estimates from one common synthetic state."""
    index = monthly_midpoints()
    noise = simulate_tendency_process(dgp, n_rep, len(index), rng)
    years = decimal_year(index)
    slope_pw_year = trend_tw_dec / TW_PER_PW_PER_DECADE
    deterministic = slope_pw_year * (years - years.mean())
    tendency = noise + deterministic[None, :]
    state = integrate_tendency(tendency, index)
    b_time, block = block_mean_derivative_batch(state, index)
    c_time, central = central_derivative_batch(state, index)
    a_time, annual = annual_difference_batch(state, index)
    return {
        "block_12m_means": (b_time, block),
        "central_12m_endpoints": (c_time, central),
        "annual_difference": (a_time, annual),
    }
