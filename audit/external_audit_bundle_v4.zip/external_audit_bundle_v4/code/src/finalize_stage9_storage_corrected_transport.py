"""Stage 9: storage-corrected meridional transport and closure diagnostics.

The primary Northern Hemisphere result uses CERES EBAF Ed4.2.1, NCEI OHC
0--2000 m, the mass-consistent ERA5 atmospheric energy budget, and PIOMAS sea
ice.  A Southern Hemisphere branch is explicitly a partial sensitivity because
no sufficiently verified GIOMAS sea-ice storage term is included.

Sign conventions:
* N_TOA is positive downward.
* H is positive poleward into the selected polar cap.
* For either polar cap, H_required = dE_cap/dt - N_cap.
* ERA5 AHT is northward-positive in the source product and is multiplied by -1
  for the Southern Hemisphere poleward-import comparison.
"""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from netCDF4 import Dataset, num2date
import numpy as np
import pandas as pd

from src.analyze_ohc_storage import (
    block_mean_tendency,
    central_span_tendency,
    monthly_midpoints,
)
from src.analyze_partial_transport import ceres_index, filter_flux_like_state
from src.analyze_transport_profile import _state_at
from src.energy_budget import (
    PW,
    R_EARTH,
    cap_area,
    day_weighted_mean,
    ols_hac_trend,
    zonal_band_areas,
)
from src.process_era5 import unique_longitudes


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
TABLES = ROOT / "tables"
RAW = ROOT / "raw"
CERES = RAW / "ceres/ceres_ebaf_ed4.2.1_zonal_global_200003-202603.nc"
OHC = RAW / "ohc/heat_content_anomaly_0-2000_monthly_20260707.nc"
LATITUDES = np.arange(50.0, 81.0, 1.0)
KEY_LATITUDES = (50.0, 60.0, 65.0, 70.0, 75.0, 80.0)
METHODS = ("block_12m_means", "central_12m_endpoints")
RHO_ICE = 917.0
LATENT_HEAT_FUSION = 334_000.0


def arr(ds: Dataset, name: str) -> np.ndarray:
    return np.asarray(np.ma.filled(ds[name][:], np.nan), dtype=float)


def timestamp(ds: Dataset) -> pd.Timestamp:
    variable = ds["time"]
    date = num2date(variable[0], variable.units, getattr(variable, "calendar", "standard"))
    return pd.Timestamp(date.year, date.month, 15)


def cap_weights(lat: np.ndarray, boundary_abs: float, hemisphere: str) -> np.ndarray:
    """Exact spherical row weights on a regular node grid for one polar cap."""
    lat = np.asarray(lat, dtype=float)
    half = abs(float(np.median(np.diff(np.sort(lat))))) / 2.0
    lo = np.maximum(-90.0, lat - half)
    hi = np.minimum(90.0, lat + half)
    if hemisphere == "NH":
        lo = np.maximum(boundary_abs, lo)
    elif hemisphere == "SH":
        hi = np.minimum(-boundary_abs, hi)
    else:
        raise ValueError(hemisphere)
    weights = 2.0 * np.pi * R_EARTH**2 * (
        np.sin(np.deg2rad(hi)) - np.sin(np.deg2rad(lo))
    )
    return np.where(hi > lo, weights, 0.0)


def load_sh_atmospheric_storage() -> pd.DataFrame:
    """Reduce the downloaded 90--50 S ERA5 tendency subset to cap integrals."""
    records: list[dict] = []
    paths = sorted((RAW / "era5").glob("aetend_profile_90S_50S_*.zip"))
    if len(paths) != 3:
        raise RuntimeError("expected three audited SH atmospheric-storage archives")
    for path in paths:
        with zipfile.ZipFile(path) as archive:
            for name in sorted(archive.namelist()):
                ds = Dataset("memory.nc", memory=archive.read(name))
                time = timestamp(ds)
                lat = arr(ds, "latitude")
                lon = arr(ds, "longitude")
                field = arr(ds, "tetend")[0]
                keep = unique_longitudes(lon)
                zonal = np.mean(field[:, keep], axis=1)
                for boundary in LATITUDES:
                    value = float(np.sum(zonal * cap_weights(lat, boundary, "SH"))) / PW
                    records.append(
                        {
                            "time": time,
                            "hemisphere": "SH",
                            "boundary_abs_deg": boundary,
                            "atmospheric_storage_pw": value,
                        }
                    )
                ds.close()
    frame = pd.DataFrame(records).sort_values(["boundary_abs_deg", "time"]).reset_index(drop=True)
    midpoint_map = dict(
        zip(
            pd.period_range("2005-01", "2022-12", freq="M").astype(str),
            monthly_midpoints("2005-01", 216),
        )
    )
    frame["time"] = (
        pd.DatetimeIndex(frame.time).to_period("M").astype(str).map(midpoint_map)
    )
    expected = 216 * len(LATITUDES)
    if len(frame) != expected or frame.atmospheric_storage_pw.isna().any():
        raise RuntimeError("SH ERA5 atmospheric-storage reduction is incomplete")
    frame.to_csv(TABLES / "era5_sh_atmospheric_storage_monthly.csv", index=False)
    frame.to_csv(OUT / "era5_sh_atmospheric_storage_monthly.csv", index=False)
    return frame


def load_ceres() -> tuple[pd.DatetimeIndex, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    with Dataset(CERES) as ds:
        source_index = ceres_index(ds)
        periods = source_index.to_period("M")
        use = (periods >= "2005-01") & (periods <= "2022-12")
        lat = arr(ds, "lat")
        net = arr(ds, "ztoa_net_all_mon")[use]
    index = monthly_midpoints("2005-01", 216)
    areas = zonal_band_areas(lat)
    global_mean = np.sum(net * areas[None, :], axis=1) / np.sum(areas)
    return index, lat, net, areas, global_mean


def load_ohc_states() -> tuple[pd.DatetimeIndex, dict[tuple[str, float], np.ndarray], pd.DataFrame, bool]:
    with Dataset(OHC) as ds:
        lat = arr(ds, "lat")
        lon = arr(ds, "lon")
        values_ma = ds["h18_hc"][:, 0]
        mask = np.ma.getmaskarray(values_ma)
        values = np.asarray(np.ma.filled(values_ma, 0.0), dtype=float)
    if np.any(mask != mask[0]):
        raise RuntimeError("NCEI OHC valid-cell mask changes with time")
    index_all = monthly_midpoints("2005-01", len(values))
    use = index_all.to_period("M") <= "2022-12"
    index = index_all[use]
    values = values[use]
    mask = mask[use]
    valid = ~mask[0]
    row_area = zonal_band_areas(lat)
    cell_area = np.repeat((row_area / len(lon))[:, None], len(lon), axis=1)

    states: dict[tuple[str, float], np.ndarray] = {}
    coverage_rows: list[dict] = []
    month_numbers = index.month
    seasons = {
        "DJF": np.isin(month_numbers, [12, 1, 2]),
        "MAM": np.isin(month_numbers, [3, 4, 5]),
        "JJA": np.isin(month_numbers, [6, 7, 8]),
        "SON": np.isin(month_numbers, [9, 10, 11]),
    }
    for hemisphere in ("NH", "SH"):
        for boundary in LATITUDES:
            latitude_mask = (
                lat[:, None] >= boundary
                if hemisphere == "NH"
                else lat[:, None] <= -boundary
            )
            cap = latitude_mask & valid
            energy = np.sum(values[:, cap], axis=1) * 1e18
            states[(hemisphere, boundary)] = energy
            known_ocean_area = float(np.sum(cell_area[cap]))
            time_missing = mask[:, cap]
            row = {
                "hemisphere": hemisphere,
                "boundary_abs_deg": boundary,
                "geometric_cap_area_m2": cap_area(boundary),
                "valid_ocean_area_m2": known_ocean_area,
                "valid_area_fraction_of_geometric_cap": known_ocean_area / cap_area(boundary),
                "known_ocean_area_m2_product_native_mask": known_ocean_area,
                "valid_fraction_of_known_product_ocean_area": 1.0,
                "valid_cells": int(cap.sum()),
                "max_time_varying_missing_fraction": float(np.max(np.mean(time_missing, axis=1))),
            }
            for season, selected in seasons.items():
                row[f"{season.lower()}_missing_fraction"] = float(
                    np.mean(time_missing[selected])
                )
            coverage_rows.append(row)
    coverage = pd.DataFrame(coverage_rows)
    coverage["interpretation_class"] = "well_supported_known_components"
    coverage.loc[
        (coverage.hemisphere == "SH") & (coverage.boundary_abs_deg > 65),
        "interpretation_class",
    ] = "partial_sensitivity_only"
    coverage.loc[
        (coverage.hemisphere == "SH") & (coverage.boundary_abs_deg >= 80),
        "interpretation_class",
    ] = "not_interpretable_as_cap_storage"
    coverage.to_csv(OUT / "ohc_cap_coverage_nh_sh.csv", index=False)
    return index, states, coverage, True


def load_actual_aht(index: pd.DatetimeIndex) -> dict[tuple[str, float], np.ndarray]:
    frame = pd.read_csv(TABLES / "era5_global_aht_monthly.csv", parse_dates=["time"])
    frame["month"] = pd.DatetimeIndex(frame.time).to_period("M")
    target = index.to_period("M")
    outputs: dict[tuple[str, float], np.ndarray] = {}
    for hemisphere in ("NH", "SH"):
        sign = 1.0 if hemisphere == "NH" else -1.0
        for boundary in LATITUDES:
            latitude = boundary if hemisphere == "NH" else -boundary
            q = frame[np.isclose(frame.latitude_deg, latitude)].set_index("month")
            values = q.loc[target, "actual_aht_pw"].to_numpy(dtype=float) * sign
            if len(values) != len(index):
                raise RuntimeError("ERA5 AHT monthly alignment failed")
            outputs[(hemisphere, boundary)] = values
    return outputs


def load_nh_atmospheric_storage(index: pd.DatetimeIndex) -> dict[float, np.ndarray]:
    frame = pd.read_csv(TABLES / "era5_transport_profile_monthly.csv", parse_dates=["time"])
    frame["month"] = pd.DatetimeIndex(frame.time).to_period("M")
    target = index.to_period("M")
    outputs = {}
    for boundary in LATITUDES:
        q = frame[frame.boundary_deg_n == boundary].set_index("month")
        outputs[boundary] = q.loc[target, "atmospheric_storage_pw"].to_numpy(dtype=float)
    return outputs


def load_nh_sea_ice_states(index: pd.DatetimeIndex) -> dict[float, np.ndarray]:
    frame = pd.read_csv(OUT / "sea_ice_cap_monthly_energy.csv", parse_dates=["time"])
    frame["month"] = pd.DatetimeIndex(frame.time).to_period("M")
    target = index.to_period("M")
    outputs = {}
    for boundary in LATITUDES:
        q = frame[frame.boundary_deg_n == boundary].set_index("month")
        outputs[boundary] = q.loc[target, "sea_ice_latent_energy_j"].to_numpy(dtype=float)
    return outputs


def raw_monthly_bundles(
    index: pd.DatetimeIndex,
    ceres_lat: np.ndarray,
    net: np.ndarray,
    areas: np.ndarray,
    global_mean: np.ndarray,
    ohc_states: dict[tuple[str, float], np.ndarray],
    nh_atmos: dict[float, np.ndarray],
    sh_atmos: pd.DataFrame,
    aht: dict[tuple[str, float], np.ndarray],
    sea_ice: dict[float, np.ndarray],
) -> dict[tuple[str, float], dict[str, np.ndarray]]:
    sh_atmos = sh_atmos.copy()
    sh_atmos["month"] = pd.DatetimeIndex(sh_atmos.time).to_period("M")
    target = index.to_period("M")
    bundles = {}
    for hemisphere in ("NH", "SH"):
        for boundary in LATITUDES:
            cap = (
                ceres_lat >= boundary
                if hemisphere == "NH"
                else ceres_lat <= -boundary
            )
            ntoa = np.sum(net[:, cap] * areas[cap][None, :], axis=1) / PW
            raw = global_mean * cap_area(boundary) / PW - ntoa
            if hemisphere == "NH":
                atmosphere = nh_atmos[boundary]
                ice = sea_ice[boundary]
            else:
                q = sh_atmos[sh_atmos.boundary_abs_deg == boundary].set_index("month")
                atmosphere = q.loc[target, "atmospheric_storage_pw"].to_numpy(dtype=float)
                ice = None
            bundles[(hemisphere, boundary)] = {
                "time": index,
                "ntoa_cap_pw": ntoa,
                "raw_implied_pw": raw,
                "global_mean_cap_storage_proxy_pw": raw + ntoa,
                "ohc_state_j": ohc_states[(hemisphere, boundary)],
                "atmospheric_storage_pw": atmosphere,
                "actual_aht_poleward_pw": aht[(hemisphere, boundary)],
                "sea_ice_state_j": ice,
            }
    return bundles


def filter_bundle(bundle: dict[str, np.ndarray], method: str) -> pd.DataFrame:
    index = pd.DatetimeIndex(bundle["time"])
    if method == "block_12m_means":
        time, ohc_w = block_mean_tendency(bundle["ohc_state_j"], index)
    elif method == "central_12m_endpoints":
        time, ohc_w = central_span_tendency(bundle["ohc_state_j"], index)
    else:
        raise ValueError(method)

    output = {"time": time, "ohc_storage_pw": ohc_w / PW}
    for name in (
        "ntoa_cap_pw",
        "raw_implied_pw",
        "global_mean_cap_storage_proxy_pw",
        "atmospheric_storage_pw",
        "actual_aht_poleward_pw",
    ):
        check, watts = filter_flux_like_state(bundle[name] * PW, index, method)
        if not check.equals(time):
            raise RuntimeError("filtered component timestamps do not align")
        output[name] = watts / PW
    if bundle["sea_ice_state_j"] is not None:
        if method == "block_12m_means":
            check, ice_w = block_mean_tendency(bundle["sea_ice_state_j"], index)
        else:
            check, ice_w = central_span_tendency(bundle["sea_ice_state_j"], index)
        if not check.equals(time):
            raise RuntimeError("sea-ice derivative timestamps do not align")
        output["sea_ice_storage_pw"] = ice_w / PW
    else:
        output["sea_ice_storage_pw"] = np.full(len(time), np.nan)

    frame = pd.DataFrame(output)
    frame["known_storage_pw"] = frame.ohc_storage_pw + frame.atmospheric_storage_pw
    frame["h_known_pw"] = frame.known_storage_pw - frame.ntoa_cap_pw
    frame["storage_alias_known_pw"] = (
        frame.global_mean_cap_storage_proxy_pw - frame.known_storage_pw
    )
    frame["raw_minus_h_known_pw"] = frame.raw_implied_pw - frame.h_known_pw
    if frame.sea_ice_storage_pw.notna().any():
        frame["known_storage_plus_sea_ice_pw"] = (
            frame.known_storage_pw + frame.sea_ice_storage_pw
        )
        frame["h_known_plus_sea_ice_pw"] = (
            frame.known_storage_plus_sea_ice_pw - frame.ntoa_cap_pw
        )
        frame["storage_alias_known_plus_sea_ice_pw"] = (
            frame.global_mean_cap_storage_proxy_pw
            - frame.known_storage_plus_sea_ice_pw
        )
        frame["raw_minus_h_known_plus_sea_ice_pw"] = (
            frame.raw_implied_pw - frame.h_known_plus_sea_ice_pw
        )
        corrected = frame.h_known_plus_sea_ice_pw
        storage = frame.known_storage_plus_sea_ice_pw
    else:
        frame["known_storage_plus_sea_ice_pw"] = np.nan
        frame["h_known_plus_sea_ice_pw"] = np.nan
        frame["storage_alias_known_plus_sea_ice_pw"] = np.nan
        frame["raw_minus_h_known_plus_sea_ice_pw"] = np.nan
        corrected = frame.h_known_pw
        storage = frame.known_storage_pw
    frame["unresolved_closure_remainder_pw"] = (
        corrected - frame.actual_aht_poleward_pw
    )
    frame["algebraic_closure_residual_pw"] = (
        frame.ntoa_cap_pw - storage + corrected
    )
    return frame


def trend_row(
    hemisphere: str,
    boundary: float,
    method: str,
    metric: str,
    values: np.ndarray,
    index: pd.DatetimeIndex,
) -> dict:
    # The annual-difference branch has only 16 points. HAC(24) previously
    # collapsed to 15 effective lags and severely under-covered in Monte Carlo.
    # Keep HAC(24) for the 193/204-point monthly derivatives, but use lag 2 for
    # annual sensitivity. Final post-audit intervals receive an additional
    # simulation-calibrated critical value outside this Stage 9 writer.
    hac_lag = 2 if method == "annual_difference" else 24
    trend = ols_hac_trend(values, index, maxlags=hac_lag)
    half = 0.5 * (trend.ci_high - trend.ci_low) * 1000.0
    return {
        "hemisphere": hemisphere,
        "boundary_abs_deg": boundary,
        "method": method,
        "metric": metric,
        "start": str(index[0].date()),
        "end": str(index[-1].date()),
        "n": len(index),
        "mean_pw": float(np.mean(values)),
        "trend_tw_dec": trend.slope_per_decade * 1000.0,
        "ci_low_tw_dec": trend.ci_low * 1000.0,
        "ci_high_tw_dec": trend.ci_high * 1000.0,
        "temporal_mde95_tw_dec": half,
        "ci_excludes_zero": bool(trend.ci_low > 0 or trend.ci_high < 0),
    }


def build_filtered_products(
    bundles: dict[tuple[str, float], dict[str, np.ndarray]]
) -> tuple[pd.DataFrame, pd.DataFrame, float, float]:
    timeseries = []
    summaries = []
    max_alias_identity = 0.0
    max_algebraic_residual = 0.0
    metrics = (
        "ntoa_cap_pw",
        "raw_implied_pw",
        "global_mean_cap_storage_proxy_pw",
        "ohc_storage_pw",
        "atmospheric_storage_pw",
        "sea_ice_storage_pw",
        "known_storage_pw",
        "known_storage_plus_sea_ice_pw",
        "h_known_pw",
        "h_known_plus_sea_ice_pw",
        "actual_aht_poleward_pw",
        "storage_alias_known_pw",
        "storage_alias_known_plus_sea_ice_pw",
        "unresolved_closure_remainder_pw",
        "algebraic_closure_residual_pw",
    )
    for (hemisphere, boundary), bundle in bundles.items():
        for method in METHODS:
            frame = filter_bundle(bundle, method)
            frame.insert(1, "hemisphere", hemisphere)
            frame.insert(2, "boundary_abs_deg", boundary)
            frame.insert(3, "method", method)
            timeseries.append(frame)
            max_alias_identity = max(
                max_alias_identity,
                float(np.nanmax(np.abs(frame.raw_minus_h_known_pw - frame.storage_alias_known_pw))),
            )
            if hemisphere == "NH":
                max_alias_identity = max(
                    max_alias_identity,
                    float(
                        np.nanmax(
                            np.abs(
                                frame.raw_minus_h_known_plus_sea_ice_pw
                                - frame.storage_alias_known_plus_sea_ice_pw
                            )
                        )
                    ),
                )
            max_algebraic_residual = max(
                max_algebraic_residual,
                float(np.nanmax(np.abs(frame.algebraic_closure_residual_pw))),
            )
            index = pd.DatetimeIndex(frame.time)
            for column in metrics:
                values = frame[column].to_numpy(dtype=float)
                if np.isfinite(values).all():
                    summaries.append(
                        trend_row(
                            hemisphere,
                            boundary,
                            method,
                            column.removesuffix("_pw"),
                            values,
                            index,
                        )
                    )
    ts = pd.concat(timeseries, ignore_index=True)
    summary = pd.DataFrame(summaries)
    ts.to_csv(OUT / "storage_corrected_transport_timeseries.csv", index=False)
    summary.to_csv(OUT / "storage_corrected_transport_profile.csv", index=False)
    return ts, summary, max_alias_identity, max_algebraic_residual


def annual_difference_products(
    bundles: dict[tuple[str, float], dict[str, np.ndarray]]
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    summary_rows = []
    for (hemisphere, boundary), bundle in bundles.items():
        index = pd.DatetimeIndex(bundle["time"])
        for year in range(2006, 2022):
            selected = index.year == year
            start = pd.Timestamp(year, 1, 1)
            end = pd.Timestamp(year + 1, 1, 1)
            seconds = (end - start).total_seconds()
            ohc = (
                _state_at(bundle["ohc_state_j"], index, end)
                - _state_at(bundle["ohc_state_j"], index, start)
            ) / seconds / PW
            ntoa = day_weighted_mean(bundle["ntoa_cap_pw"][selected], index[selected])
            raw = day_weighted_mean(bundle["raw_implied_pw"][selected], index[selected])
            proxy = day_weighted_mean(
                bundle["global_mean_cap_storage_proxy_pw"][selected], index[selected]
            )
            atmosphere = day_weighted_mean(
                bundle["atmospheric_storage_pw"][selected], index[selected]
            )
            aht = day_weighted_mean(
                bundle["actual_aht_poleward_pw"][selected], index[selected]
            )
            known = ohc + atmosphere
            h_known = known - ntoa
            if bundle["sea_ice_state_j"] is not None:
                ice = (
                    _state_at(bundle["sea_ice_state_j"], index, end)
                    - _state_at(bundle["sea_ice_state_j"], index, start)
                ) / seconds / PW
                h_si = h_known + ice
                storage_si = known + ice
                corrected = h_si
            else:
                ice = np.nan
                h_si = np.nan
                storage_si = np.nan
                corrected = h_known
            rows.append(
                {
                    "time": pd.Timestamp(year, 7, 1),
                    "year": year,
                    "hemisphere": hemisphere,
                    "boundary_abs_deg": boundary,
                    "ohc_storage_pw": ohc,
                    "atmospheric_storage_pw": atmosphere,
                    "sea_ice_storage_pw": ice,
                    "ntoa_cap_pw": ntoa,
                    "raw_implied_pw": raw,
                    "global_mean_cap_storage_proxy_pw": proxy,
                    "known_storage_pw": known,
                    "known_storage_plus_sea_ice_pw": storage_si,
                    "h_known_pw": h_known,
                    "h_known_plus_sea_ice_pw": h_si,
                    "actual_aht_poleward_pw": aht,
                    "unresolved_closure_remainder_pw": corrected - aht,
                    "algebraic_closure_residual_pw": ntoa
                    - (storage_si if hemisphere == "NH" else known)
                    + corrected,
                }
            )
    annual = pd.DataFrame(rows)
    for (hemisphere, boundary), group in annual.groupby(
        ["hemisphere", "boundary_abs_deg"], sort=False
    ):
        index = pd.DatetimeIndex(group.time)
        for column in (
            "ohc_storage_pw",
            "h_known_pw",
            "h_known_plus_sea_ice_pw",
            "raw_implied_pw",
            "unresolved_closure_remainder_pw",
        ):
            values = group[column].to_numpy(dtype=float)
            if np.isfinite(values).all():
                summary_rows.append(
                    trend_row(
                        hemisphere,
                        boundary,
                        "annual_difference",
                        column.removesuffix("_pw"),
                        values,
                        index,
                    )
                )
    summary = pd.DataFrame(summary_rows)
    annual.to_csv(OUT / "storage_annual_difference_timeseries.csv", index=False)
    summary.to_csv(OUT / "storage_annual_difference_profile.csv", index=False)
    return annual, summary


def derivative_sensitivity(
    summary: pd.DataFrame, annual_summary: pd.DataFrame
) -> pd.DataFrame:
    metrics = ["ohc_storage", "h_known", "h_known_plus_sea_ice"]
    out = pd.concat(
        [
            summary[summary.metric.isin(metrics)],
            annual_summary[annual_summary.metric.isin(metrics)],
        ],
        ignore_index=True,
    )
    out.to_csv(OUT / "storage_derivative_sensitivity.csv", index=False)
    return out


def robustness_products(timeseries: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    primary = timeseries[timeseries.method == "block_12m_means"]
    rows = []
    metrics = {
        "raw": "raw_implied_pw",
        "h_known": "h_known_pw",
        "h_known_plus_sea_ice": "h_known_plus_sea_ice_pw",
    }
    for (hemisphere, boundary), group in primary.groupby(
        ["hemisphere", "boundary_abs_deg"], sort=False
    ):
        group = group.sort_values("time").reset_index(drop=True)
        n = len(group)
        variants: list[tuple[str, np.ndarray]] = [("full", np.arange(n))]
        for years in (1, 2):
            count = 12 * years
            variants.extend(
                [
                    (f"trim_first_{years}y", np.arange(count, n)),
                    (f"trim_last_{years}y", np.arange(0, n - count)),
                    (f"trim_both_{years}y", np.arange(count, n - count)),
                ]
            )
        midpoint = n // 2
        variants.extend(
            [
                ("first_half", np.arange(0, midpoint)),
                ("second_half", np.arange(midpoint, n)),
            ]
        )
        for years in (10, 12, 15):
            width = 12 * years
            for start in range(0, n - width + 1, 12):
                variants.append(
                    (
                        f"rolling_{years}y_start_{start // 12:+d}",
                        np.arange(start, start + width),
                    )
                )
        for metric, column in metrics.items():
            all_values = group[column].to_numpy(dtype=float)
            if not np.isfinite(all_values).all():
                continue
            for variant, positions in variants:
                values = all_values[positions]
                index = pd.DatetimeIndex(group.loc[positions, "time"])
                tr = ols_hac_trend(values, index, maxlags=24)
                rows.append(
                    {
                        "hemisphere": hemisphere,
                        "boundary_abs_deg": boundary,
                        "metric": metric,
                        "variant": variant,
                        "start": str(index[0].date()),
                        "end": str(index[-1].date()),
                        "n": len(index),
                        "trend_tw_dec": tr.slope_per_decade * 1000.0,
                        "ci_low_tw_dec": tr.ci_low * 1000.0,
                        "ci_high_tw_dec": tr.ci_high * 1000.0,
                        "sign": int(np.sign(tr.slope_per_decade)),
                    }
                )
    detail = pd.DataFrame(rows)
    summary_rows = []
    for keys, group in detail.groupby(
        ["hemisphere", "boundary_abs_deg", "metric"], sort=False
    ):
        full_sign = int(group.loc[group.variant == "full", "sign"].iloc[0])
        summary_rows.append(
            {
                "hemisphere": keys[0],
                "boundary_abs_deg": keys[1],
                "metric": keys[2],
                "n_variants": len(group),
                "full_trend_tw_dec": float(
                    group.loc[group.variant == "full", "trend_tw_dec"].iloc[0]
                ),
                "minimum_variant_trend_tw_dec": float(group.trend_tw_dec.min()),
                "maximum_variant_trend_tw_dec": float(group.trend_tw_dec.max()),
                "fraction_same_sign_as_full": float(np.mean(group.sign == full_sign)),
                "both_signs_present": bool(group.sign.min() < 0 < group.sign.max()),
                "all_variants_same_sign": bool(group.sign.nunique() == 1),
            }
        )
    robust_summary = pd.DataFrame(summary_rows)
    detail.to_csv(OUT / "storage_trend_robustness.csv", index=False)
    robust_summary.to_csv(OUT / "storage_trend_robustness_summary.csv", index=False)
    return detail, robust_summary


def detection_products(summary: pd.DataFrame) -> pd.DataFrame:
    primary = summary[summary.method == "block_12m_means"]
    structural = pd.read_csv(OUT / "missing_storage_structural_bounds.csv")
    bound = structural.groupby("boundary_deg_n").structural_bound_plus_minus_tw_dec.sum()
    rows = []
    for hemisphere in ("NH", "SH"):
        metric = "h_known_plus_sea_ice" if hemisphere == "NH" else "h_known"
        q = primary[
            (primary.hemisphere == hemisphere) & (primary.metric == metric)
        ].set_index("boundary_abs_deg")
        for boundary in LATITUDES:
            row = q.loc[boundary]
            structural_bound = float(bound.loc[boundary]) if hemisphere == "NH" else np.nan
            safe = (
                row.temporal_mde95_tw_dec + structural_bound
                if np.isfinite(structural_bound)
                else np.nan
            )
            rows.append(
                {
                    "hemisphere": hemisphere,
                    "boundary_abs_deg": boundary,
                    "estimand": metric,
                    "best_estimate_tw_dec": row.trend_tw_dec,
                    "ci_low_tw_dec": row.ci_low_tw_dec,
                    "ci_high_tw_dec": row.ci_high_tw_dec,
                    "temporal_mde95_tw_dec": row.temporal_mde95_tw_dec,
                    "structural_bound_tw_dec": structural_bound,
                    "conservative_safe_threshold_tw_dec": safe,
                    "signal_to_safe_threshold": (
                        abs(row.trend_tw_dec) / safe if np.isfinite(safe) and safe > 0 else np.nan
                    ),
                    "robust_above_safe_threshold": bool(
                        np.isfinite(safe)
                        and abs(row.trend_tw_dec) > safe
                        and (row.ci_low_tw_dec > 0 or row.ci_high_tw_dec < 0)
                    ),
                    "status": (
                        "primary_NH"
                        if hemisphere == "NH"
                        else (
                            "partial_sensitivity_only"
                            if boundary < 80
                            else "not_interpretable_as_cap_storage"
                        )
                    ),
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "storage_corrected_detection_limits.csv", index=False)
    return out


def closure_products(
    summary: pd.DataFrame, detection: pd.DataFrame, timeseries: pd.DataFrame
) -> pd.DataFrame:
    primary = summary[summary.method == "block_12m_means"]
    primary_ts = timeseries[timeseries.method == "block_12m_means"]
    rows = []
    for hemisphere in ("NH", "SH"):
        corrected_metric = "h_known_plus_sea_ice" if hemisphere == "NH" else "h_known"
        corrected = primary[
            (primary.hemisphere == hemisphere) & (primary.metric == corrected_metric)
        ].set_index("boundary_abs_deg")
        remainder = primary[
            (primary.hemisphere == hemisphere)
            & (primary.metric == "unresolved_closure_remainder")
        ].set_index("boundary_abs_deg")
        algebra = primary[
            (primary.hemisphere == hemisphere)
            & (primary.metric == "algebraic_closure_residual")
        ].set_index("boundary_abs_deg")
        for boundary in LATITUDES:
            c = corrected.loc[boundary]
            r = remainder.loc[boundary]
            a = algebra.loc[boundary]
            d = detection[
                (detection.hemisphere == hemisphere)
                & (detection.boundary_abs_deg == boundary)
            ].iloc[0]
            rts = primary_ts[
                (primary_ts.hemisphere == hemisphere)
                & (primary_ts.boundary_abs_deg == boundary)
            ].unresolved_closure_remainder_pw.to_numpy(dtype=float)
            ratio = (
                abs(r.trend_tw_dec) / abs(c.trend_tw_dec)
                if abs(c.trend_tw_dec) > 1e-12
                else np.inf
            )
            undecidable = (
                not bool(d.robust_above_safe_threshold)
                if hemisphere == "NH"
                else True
            )
            rows.append(
                {
                    "hemisphere": hemisphere,
                    "boundary_abs_deg": boundary,
                    "corrected_estimand": corrected_metric,
                    "corrected_mean_pw": c.mean_pw,
                    "corrected_trend_tw_dec": c.trend_tw_dec,
                    "corrected_ci_low_tw_dec": c.ci_low_tw_dec,
                    "corrected_ci_high_tw_dec": c.ci_high_tw_dec,
                    "unresolved_remainder_mean_pw": r.mean_pw,
                    "unresolved_remainder_abs_mean_pw": abs(r.mean_pw),
                    "unresolved_remainder_mean_abs_pw": float(np.mean(np.abs(rts))),
                    "unresolved_remainder_max_abs_pw": float(np.max(np.abs(rts))),
                    "unresolved_remainder_trend_tw_dec": r.trend_tw_dec,
                    "unresolved_remainder_ci_low_tw_dec": r.ci_low_tw_dec,
                    "unresolved_remainder_ci_high_tw_dec": r.ci_high_tw_dec,
                    "abs_remainder_trend_to_abs_tested_trend": ratio,
                    "algebraic_residual_mean_pw": a.mean_pw,
                    "algebraic_residual_trend_tw_dec": a.trend_tw_dec,
                    "interpretation": "undecidable" if undecidable else "detectable",
                    "note": (
                        "Remainder = required corrected total minus ERA5 AHT; it combines "
                        "non-atmospheric transport, omitted storage, and any data residual."
                    ),
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "closure_residual_profile.csv", index=False)
    return out


def profile_metric(summary: pd.DataFrame, hemisphere: str, metric: str) -> pd.DataFrame:
    return (
        summary[
            (summary.method == "block_12m_means")
            & (summary.hemisphere == hemisphere)
            & (summary.metric == metric)
        ]
        .set_index("boundary_abs_deg")
        .loc[LATITUDES]
    )


def plot_storage_alias(summary: pd.DataFrame) -> None:
    colors = {"raw": "#666666", "known": "#2b7bba", "si": "#08306b"}
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.4), sharey=True)
    specifications = [
        (
            "NH",
            [
                ("raw_implied", "Raw implied CERES", colors["raw"], "-"),
                ("h_known", r"$H_{\mathrm{known}}$", colors["known"], "--"),
                ("h_known_plus_sea_ice", r"$H_{\mathrm{known+SI}}$", colors["si"], "-"),
            ],
            "Severní polokoule — primární větev",
        ),
        (
            "SH",
            [
                ("raw_implied", "Raw implied CERES", colors["raw"], "-"),
                ("h_known", r"$H_{\mathrm{known}}$ (partial sensitivity)", colors["known"], "--"),
            ],
            "Jižní polokoule — pouze částečná citlivost",
        ),
    ]
    for ax, (hemisphere, series, title) in zip(axes, specifications):
        for metric, label, color, style in series:
            q = profile_metric(summary, hemisphere, metric)
            ax.plot(LATITUDES, q.trend_tw_dec, color=color, ls=style, lw=2, label=label)
            ax.fill_between(
                LATITUDES,
                q.ci_low_tw_dec,
                q.ci_high_tw_dec,
                color=color,
                alpha=0.09,
            )
        ax.axhline(0, color="black", lw=0.8)
        for latitude in (60, 65, 70):
            ax.axvline(latitude, color="0.75", lw=0.7, ls=":")
        ax.set_title(title)
        ax.set_xlabel("Absolutní zeměpisná šířka hranice čepičky (°)")
        ax.legend(frameon=False, fontsize=9)
    axes[0].set_ylabel("Trend poleward importu (TW/dekádu)")
    axes[1].axvspan(65, 75, color="0.7", alpha=0.10)
    axes[1].axvspan(75, 80, color="0.5", alpha=0.16)
    fig.suptitle(
        "Storage alias v transportu odvozeném z CERES (2006-01 až 2022-01)\n"
        "95% časové HAC intervaly; kladné = směrem k příslušnému pólu"
    )
    fig.tight_layout()
    fig.savefig(OUT / "storage_alias_global_or_hemispheric_profile.png", dpi=220)
    plt.close(fig)


def plot_storage_components(summary: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.4), sharey=True)
    colors = {
        "ohc_storage": "#287271",
        "atmospheric_storage": "#884ea0",
        "sea_ice_storage": "#6a4c93",
        "known_storage": "#0b6e99",
        "known_storage_plus_sea_ice": "#08306b",
    }
    series_nh = [
        ("ohc_storage", "OHC 0–2000 m"),
        ("atmospheric_storage", "Atmosféra"),
        ("sea_ice_storage", "Mořský led (PIOMAS)"),
        ("known_storage_plus_sea_ice", "Celkem známé + SI"),
    ]
    series_sh = [
        ("ohc_storage", "OHC 0–2000 m"),
        ("atmospheric_storage", "Atmosféra"),
        ("known_storage", "Celkem známé (bez SI)"),
    ]
    for ax, hemisphere, series, title in [
        (axes[0], "NH", series_nh, "NH — primární známé storage"),
        (axes[1], "SH", series_sh, "SH — partial sensitivity, bez sea ice"),
    ]:
        for metric, label in series:
            q = profile_metric(summary, hemisphere, metric)
            ax.plot(LATITUDES, q.trend_tw_dec, lw=1.9, color=colors[metric], label=label)
        ax.axhline(0, color="black", lw=0.8)
        ax.set_title(title)
        ax.set_xlabel("Absolutní šířka hranice čepičky (°)")
        ax.legend(frameon=False, fontsize=9)
    axes[0].set_ylabel("Trend storage tendency (TW/dekádu)")
    axes[1].axvspan(65, 75, color="0.7", alpha=0.10)
    axes[1].axvspan(75, 80, color="0.5", alpha=0.16)
    fig.suptitle("Složky regionální akumulace energie podle šířky")
    fig.tight_layout()
    fig.savefig(OUT / "storage_components_vs_latitude.png", dpi=220)
    plt.close(fig)


def plot_total_aht_remainder(summary: pd.DataFrame) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(13.2, 9), sharex="col")
    colors = {"total": "#08306b", "aht": "#d95f02", "rem": "#1b9e77"}
    for column, hemisphere in enumerate(("NH", "SH")):
        corrected = "h_known_plus_sea_ice" if hemisphere == "NH" else "h_known"
        label = r"$H_{\mathrm{known+SI}}$" if hemisphere == "NH" else r"$H_{\mathrm{known}}$ (partial)"
        series = [
            (corrected, label, colors["total"]),
            ("actual_aht_poleward", "ERA5 actual AHT", colors["aht"]),
            ("unresolved_closure_remainder", r"$H_{\mathrm{non-atm}}$ / unresolved remainder", colors["rem"]),
        ]
        for metric, name, color in series:
            q = profile_metric(summary, hemisphere, metric)
            axes[0, column].plot(LATITUDES, q.mean_pw, color=color, lw=2, label=name)
            axes[1, column].plot(LATITUDES, q.trend_tw_dec, color=color, lw=2, label=name)
            axes[1, column].fill_between(
                LATITUDES, q.ci_low_tw_dec, q.ci_high_tw_dec, color=color, alpha=0.08
            )
        axes[0, column].axhline(0, color="black", lw=0.7)
        axes[1, column].axhline(0, color="black", lw=0.7)
        axes[0, column].set_title(
            f"{hemisphere}: klimatologie" + (" (partial sensitivity)" if hemisphere == "SH" else "")
        )
        axes[1, column].set_title(f"{hemisphere}: trend a 95% temporal CI")
        axes[1, column].set_xlabel("Absolutní šířka hranice čepičky (°)")
        axes[0, column].legend(frameon=False, fontsize=8)
    axes[0, 0].set_ylabel("Poleward transport (PW)")
    axes[1, 0].set_ylabel("Trend (TW/dekádu)")
    fig.suptitle(
        "Požadovaný celkový import, actual AHT a neuzavřený ne-atmosférický zbytek\n"
        "Zbytek není nezávisle změřený OHT"
    )
    fig.tight_layout()
    fig.savefig(OUT / "total_aht_nonatmospheric_profile.png", dpi=220)
    plt.close(fig)


def plot_closure(closure: pd.DataFrame) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 5.4))
    for hemisphere, color, style in [("NH", "#1b9e77", "-"), ("SH", "#7570b3", "--")]:
        q = closure[closure.hemisphere == hemisphere].set_index("boundary_abs_deg").loc[LATITUDES]
        axes[0].plot(
            LATITUDES,
            q.unresolved_remainder_mean_abs_pw,
            color=color,
            ls=style,
            lw=2,
            label=hemisphere,
        )
        axes[1].plot(
            LATITUDES,
            q.unresolved_remainder_trend_tw_dec,
            color=color,
            ls=style,
            lw=2,
            label=hemisphere,
        )
        axes[1].fill_between(
            LATITUDES,
            q.unresolved_remainder_ci_low_tw_dec,
            q.unresolved_remainder_ci_high_tw_dec,
            color=color,
            alpha=0.08,
        )
    axes[0].set(
        xlabel="Absolutní šířka hranice čepičky (°)",
        ylabel="Průměr |neuzavřeného zbytku| (PW)",
        title="Časový průměr absolutního zbytku po odečtení AHT",
    )
    axes[1].axhline(0, color="black", lw=0.8)
    axes[1].set(
        xlabel="Absolutní šířka hranice čepičky (°)",
        ylabel="Trend zbytku (TW/dekádu)",
        title="Trend zbytku a 95% temporal CI",
    )
    for ax in axes:
        ax.legend(frameon=False)
    fig.suptitle(
        "Fyzicky neuzavřený zbytek = H_corr − ERA5 AHT\n"
        "Algebraická bilanční identita je numericky nulová a není zde zaměňována za fyzickou uzávěru"
    )
    fig.tight_layout()
    fig.savefig(OUT / "closure_residual_vs_latitude.png", dpi=220)
    plt.close(fig)


def plot_detection(detection: pd.DataFrame) -> None:
    q = detection[detection.hemisphere == "NH"].set_index("boundary_abs_deg").loc[LATITUDES]
    fig, ax = plt.subplots(figsize=(10.4, 6.1))
    ax.plot(
        LATITUDES,
        np.abs(q.best_estimate_tw_dec),
        color="0.35",
        ls="--",
        lw=1.7,
        label=r"|best estimate $H_{\mathrm{known+SI}}$|",
    )
    ax.plot(LATITUDES, q.temporal_mde95_tw_dec, color="#2878b5", lw=2, label="Temporal MDE95")
    ax.plot(LATITUDES, q.structural_bound_tw_dec, color="#6a4c93", lw=2, label="Structural bound")
    ax.plot(
        LATITUDES,
        q.conservative_safe_threshold_tw_dec,
        color="#b2182b",
        lw=2.4,
        label="Conservative safe threshold",
    )
    for latitude in KEY_LATITUDES:
        ax.axvline(latitude, color="0.75", lw=0.7, ls=":")
    ax.set(
        xlabel="Severní hranice čepičky (°N)",
        ylabel="Velikost trendu (TW/dekádu)",
        title="Detekční limit storage-corrected transportu, NH",
    )
    ax.set_ylim(bottom=0)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(OUT / "storage_corrected_detection_limits.png", dpi=220)
    plt.close(fig)


def markdown_table(frame: pd.DataFrame, digits: int = 2) -> str:
    formatted = frame.copy()
    for column in formatted.select_dtypes(include=[np.number]).columns:
        formatted[column] = formatted[column].map(
            lambda x: "—" if not np.isfinite(x) else f"{x:.{digits}f}"
        )
    headers = [str(x) for x in formatted.columns]
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for _, row in formatted.iterrows():
        lines.append("| " + " | ".join(str(x) for x in row) + " |")
    return "\n".join(lines)


def write_documents(
    summary: pd.DataFrame,
    detection: pd.DataFrame,
    closure: pd.DataFrame,
    coverage: pd.DataFrame,
    derivative: pd.DataFrame,
    robust_summary: pd.DataFrame,
    diagnostics: pd.DataFrame,
) -> None:
    primary = summary[summary.method == "block_12m_means"]
    def q(metric: str) -> pd.Series:
        return (
            primary[(primary.hemisphere == "NH") & (primary.metric == metric)]
            .set_index("boundary_abs_deg")
            .trend_tw_dec
        )
    raw = q("raw_implied")
    known = q("h_known")
    known_si = q("h_known_plus_sea_ice")
    alias = raw - known_si

    key_detection = detection[
        (detection.hemisphere == "NH")
        & detection.boundary_abs_deg.isin(KEY_LATITUDES)
    ][
        [
            "boundary_abs_deg",
            "best_estimate_tw_dec",
            "ci_low_tw_dec",
            "ci_high_tw_dec",
            "temporal_mde95_tw_dec",
            "structural_bound_tw_dec",
            "conservative_safe_threshold_tw_dec",
            "signal_to_safe_threshold",
        ]
    ].rename(
        columns={
            "boundary_abs_deg": "°N",
            "best_estimate_tw_dec": "best TW/dec",
            "ci_low_tw_dec": "CI low",
            "ci_high_tw_dec": "CI high",
            "temporal_mde95_tw_dec": "MDE95",
            "structural_bound_tw_dec": "structural",
            "conservative_safe_threshold_tw_dec": "safe",
            "signal_to_safe_threshold": "|signal|/safe",
        }
    )
    key_profiles = pd.DataFrame(
        {
            "°N": KEY_LATITUDES,
            "raw TW/dec": [raw.loc[x] for x in KEY_LATITUDES],
            "H_known TW/dec": [known.loc[x] for x in KEY_LATITUDES],
            "H_known+SI TW/dec": [known_si.loc[x] for x in KEY_LATITUDES],
            "storage alias raw−corrected": [alias.loc[x] for x in KEY_LATITUDES],
        }
    )
    key_closure = closure[
        (closure.hemisphere == "NH")
        & closure.boundary_abs_deg.isin(KEY_LATITUDES)
    ][
        [
            "boundary_abs_deg",
            "unresolved_remainder_mean_pw",
            "unresolved_remainder_mean_abs_pw",
            "unresolved_remainder_max_abs_pw",
            "unresolved_remainder_trend_tw_dec",
            "unresolved_remainder_ci_low_tw_dec",
            "unresolved_remainder_ci_high_tw_dec",
            "abs_remainder_trend_to_abs_tested_trend",
        ]
    ]

    report = f"""# Storage-corrected meridionální transport

## Osm stručných odpovědí

1. **Jak velký je storage alias?** Raw CERES trend převyšuje H_known+SI o
   **{alias.loc[60]:.1f}, {alias.loc[65]:.1f} a {alias.loc[70]:.1f} TW/dekádu**
   přes 60/65/70°N. To je hlavní kvantitativní výsledek této etapy.
2. **Mění korekce znaménko, nebo amplitudu?** Především snižuje amplitudu.
   U 65°N mění best estimate z {raw.loc[65]:.1f} na {known_si.loc[65]:.1f}
   TW/dekádu, ale obě corrected znaménka jsou v rámci nejistoty nerozlišená.
3. **Zůstává prostorově souvislý robustní trend?** **Ne.** Best estimates mají
   profil, ale žádný H_known+SI trend na hlavních hranicích nepřekračuje
   současný bezpečný detekční práh.
4. **Je trend stabilní vůči oknům?** **Ne dostatečně.** Rolling, endpoint a
   half-record varianty mění amplitudu a na hlavních hranicích také znaménko.
5. **Je větší než temporal i structural uncertainty?** **Ne.** Poměr
   |signál|/safe je na 60/65/70°N
   {key_detection.set_index("°N").loc[60, "|signal|/safe"]:.3f}/
   {key_detection.set_index("°N").loc[65, "|signal|/safe"]:.3f}/
   {key_detection.set_index("°N").loc[70, "|signal|/safe"]:.3f}.
6. **Potvrzuje actual AHT stejný trend?** **Nerozhodnutelné.** ERA5 AHT má
   široké intervaly a nevykazuje stejný robustní souvislý profil.
7. **Je residual dost malý pro interpretaci?** **Ne.** Neuzavřený zbytek
   H_corr−AHT je kombinací ne-atmosférického transportu, chybějícího storage a
   datového rezidua; není nezávisle uzavřen a je srovnatelný s testovanými
   trendy.
8. **Je SH correction rovnocenná NH?** **Ne.** SH H_known je pouze partial
   sensitivity; GIOMAS sea-ice storage nebyl použit kvůli nejednoznačné
   dokumentaci koncentrace v heff a chybějícímu nezávislému objemovému testu.

## Fyzikální definice

Pro severní i jižní polární čepičku je kladné H definováno jako tok **do
čepičky směrem k příslušnému pólu**:

H_required = dE_cap/dt − N_cap.

Raw implied transport po odečtení globálního průměru je

H_raw = <N>_global A_cap − N_cap.

Proto storage alias a corrected transport splňují

H_alias = <N>_global A_cap − dE_known/dt,

H_corr = H_raw − H_alias = dE_known/dt − N_cap.

Numerická ekvivalence těchto dvou cest prošla s maximální chybou uvedenou v
technických diagnostikách.

## Hlavní profily

{markdown_table(key_profiles)}

## Detekční limity NH

{markdown_table(key_detection)}

MDE95 je polovina 95% HAC intervalu. Structural bound je nepravděpodobnostní
scénářový součet; safe threshold = MDE95 + structural bound. Nedetekování není
důkaz nulového trendu.

## Actual AHT a ne-atmosférický zbytek

{markdown_table(key_closure.rename(columns={
    "boundary_abs_deg": "°N",
    "unresolved_remainder_mean_pw": "remainder mean PW",
    "unresolved_remainder_mean_abs_pw": "mean |remainder| PW",
    "unresolved_remainder_max_abs_pw": "max |remainder| PW",
    "unresolved_remainder_trend_tw_dec": "remainder trend TW/dec",
    "unresolved_remainder_ci_low_tw_dec": "CI low",
    "unresolved_remainder_ci_high_tw_dec": "CI high",
    "abs_remainder_trend_to_abs_tested_trend": "|remainder trend|/|Hcorr trend|",
}))}

Tento zbytek se smí označit pouze H_non-atm nebo unresolved remainder. Nelze jej
bez nezávislého ocean budgetu označit za OHT.

## Závěr

Regionální storage correction odstraňuje velkou část kladného apparentního
raw-CERES trendu na hlavních arktických hranicích. Po korekci nezůstává trend,
který by byl stabilní vůči časovým oknům a současně větší než časová i
strukturální nejistota. Správná formulace proto je: **současná datová sestava
nerozlišuje robustní trend celkového poleward transportu větší než její
detekční limit**. Není to důkaz nulového trendu.
"""
    (OUT / "STORAGE_CORRECTED_TRANSPORT.md").write_text(report)

    key_coverage = coverage[
        coverage.boundary_abs_deg.isin(KEY_LATITUDES)
    ][
        [
            "hemisphere",
            "boundary_abs_deg",
            "valid_ocean_area_m2",
            "valid_area_fraction_of_geometric_cap",
            "valid_fraction_of_known_product_ocean_area",
            "valid_cells",
            "max_time_varying_missing_fraction",
            "interpretation_class",
        ]
    ]
    key_derivative = derivative[
        derivative.boundary_abs_deg.isin([60, 65, 70])
        & derivative.metric.isin(["ohc_storage", "h_known", "h_known_plus_sea_ice"])
    ][
        [
            "hemisphere",
            "boundary_abs_deg",
            "method",
            "metric",
            "trend_tw_dec",
            "ci_low_tw_dec",
            "ci_high_tw_dec",
        ]
    ]
    components_doc = f"""# Storage components

## Datové složky

- OHC: NCEI měsíční gridded anomaly 0–2000 m; nejde o full-depth OHC.
- Atmosféra: ERA5 tendency of vertical integral of total energy.
- Sea ice NH: PIOMAS v2.1 sensitivity, E_SI = −rho_i L_f V.
- Použité konstanty: rho_i = {RHO_ICE:.0f} kg m⁻³,
  L_f = {LATENT_HEAT_FUSION:.0f} J kg⁻¹.
- Záporný stav ledu znamená latentní energii vzhledem k kapalné vodě při 0 °C;
  úbytek objemu dává kladnou storage tendency.

## OHC coverage

{markdown_table(key_coverage, digits=4)}

Product-native OHC maska je časově konstantní, proto je seasonal missingness
uvnitř této masky nulová. Podíl vůči geometrické čepičce není podíl kvality:
čepička obsahuje pevninu a led. Hodnota 1,0 vůči known product-ocean area
znamená pouze úplnost vůči vlastní statické masce NCEI, nikoli důkaz úplnosti
celého fyzického storage.

## Citlivost na časovou derivaci

{markdown_table(key_derivative)}

Použity byly (i) rozdíl následujícího a předchozího 12měsíčního průměru,
(ii) centered 12-month endpoint difference a (iii) přesná kalendářní roční
diference stavů mezi 1. ledny. Změny mezi metodami jsou zahrnuty do
strukturálního posouzení; hlavní závěr není opřen o jediný derivátor.

## Jižní mořský led

GIOMAS nebyl použit. Oficiální stránka uvádí heff v metrech a samostatnou
koncentraci area, ale neříká jednoznačně, zda heff je již volume-per-grid-area.
TED/PIOMAS analogie naznačuje efektivní tloušťku, avšak bez nezávislého
publikovaného měsíčního objemového benchmarku by hrozilo dvojí násobení
koncentrací. SH H_known proto zůstává partial sensitivity only.
"""
    (OUT / "STORAGE_COMPONENTS.md").write_text(components_doc)

    closure_doc = f"""# Closure diagnostics

## Dvě různé veličiny

1. **Algebraický residual**

   r_alg = N_cap − dE_known/dt + H_required.

   Protože H_required je z téže rovnice definováno, musí být r_alg numericky
   nula. Tento test ověřuje znaménka, jednotky a implementaci, nikoli nezávislou
   fyzickou uzávěru.

2. **Fyzicky neuzavřený zbytek**

   C_unresolved = H_corr − H_A.

   Obsahuje skutečný ne-atmosférický transport, omitted storage (hluboký oceán,
   země, ledovce a další zásobníky), rozdíly produktů a případné R_cap. Proto je
   současně H_non-atm remainder i closure gap; není to samostatně pozorovaný
   OHT.

## Rozhodovací pravidlo

Pokud je trend zbytku srovnatelný s H_corr, jeho CI zahrnuje více fyzikálně
odlišných stavů, nebo corrected signál nepřekročí safe threshold, interpretace
je označena **nerozhodnutelná**. To nastává na všech hlavních arktických
hranicích.

## Technické testy

{markdown_table(diagnostics)}

## Důsledek

Numerická identita je uzavřena. Full-system energetická bilance není nezávisle
uzavřena, protože chybí nezávislý ne-atmosférický transport a úplný storage.
Proto nelze reziduum přejmenovat na OHT ani použít nulový algebraický residual
jako důkaz malé fyzické chyby.
"""
    (OUT / "CLOSURE_DIAGNOSTICS.md").write_text(closure_doc)

    dependence_doc = """# Data dependence note

## CERES EBAF a OHC nejsou plně nezávislé

CERES EBAF upravuje globální průměrné SW a LW TOA toky v mezích jejich
nejistot tak, aby dlouhodobý globální net flux odpovídal odhadu heat storage
Earth systemu, dominovanému oceánem. Ed4.2 zachovává globální energy-balance
constraint založený na referenčním OHC období. Oficiální dokumentace:

- https://ceres.larc.nasa.gov/Data/
- https://ceres.larc.nasa.gov/documents/DQ_summaries/Versioned/CERES_EBAF_Ed4.2_DQS_V5.pdf

To znamená, že absolutní globální mean EBAF NET a OHC nejsou statisticky plně
nezávislé.

## Co constraint ovlivňuje v této analýze

Raw implied transport každý měsíc odstraňuje globální mean NET. Prostorový
profil je tedy řízen zonálními odchylkami od globálního průměru, nikoli jeho
absolutní hodnotou. Globální constraint může přesto ovlivnit společný offset a
nízkofrekvenční globální složku, zejména pokud se úprava SW/LW v čase mění.
Regionální rozložení N_TOA není přímo přinuceno reprodukovat regionální NCEI
OHC.

## Kde používáme OHC nezávisle

NCEI 0–2000 m gridded anomaly je integrována regionálně přes polární čepičky a
časově derivována. Tato regionální tendence nahrazuje uniformní
global-mean-storage proxy v H_raw. V tomto smyslu přidává prostorovou informaci,
kterou globální EBAF constraint neposkytuje.

## Kde by vznikla kruhová argumentace

Kruhové by bylo tvrdit, že shoda globálního EBAF NET s OHC nezávisle potvrzuje
OHC uptake, nebo kalibrovat regionální OHC correction tak, aby reprodukovala
EBAF globální imbalance. To zde neděláme. Výsledky jsou označeny jako
bilanční kombinace vzájemně částečně závislých produktů.

## ERA5 moisture/energy QA

Použitý Copernicus produkt je přímo mass-consistent derived energy and moisture
budget dataset. Wind field je iterativně korigován podle dry-mass imbalance a
stejný korigovaný vítr vstupuje do total-energy a water-vapour transportu.
Proto jsme nestahovali raw ERA5 pro nový P−E test, který by nepřidal nezávislou
kontrolu hlavního estimandu. Dokumentace:

- https://confluence.ecmwf.int/spaces/CKB/pages/260571271/Mass-consistent+atmospheric+energy+and+moisture+budget+data+from+1979+to+present+derived+from+ERA5+reanalysis+Product+User+Guide
"""
    (OUT / "DATA_DEPENDENCE_NOTE.md").write_text(dependence_doc)


def write_auxiliary_qa() -> None:
    pd.DataFrame(
        [
            {
                "test": "ERA5 product explicitly mass-consistent",
                "result": "PASS",
                "evidence": "Copernicus PUG: iterative dry-mass wind adjustment before energy/moisture flux calculation",
            },
            {
                "test": "new raw P-E download required",
                "result": "NO",
                "evidence": "Would duplicate the documented product construction and does not independently close total transport",
            },
        ]
    ).to_csv(OUT / "era5_moisture_energy_qa.csv", index=False)
    pd.DataFrame(
        [
            {
                "dataset": "GIOMAS",
                "variable": "heff",
                "official_units": "m",
                "separate_concentration_variable": "area (fraction)",
                "effective_thickness_unambiguously_documented": False,
                "independent_monthly_volume_benchmark_available": False,
                "decision": "do_not_compute_SH_sea_ice_storage",
                "reason": "risk of double concentration weighting and no independent seasonal volume validation",
            }
        ]
    ).to_csv(OUT / "sh_sea_ice_decision.csv", index=False)
    provenance = json.loads(
        (ROOT / "provenance/era5_sh_atmospheric_storage_requests.json").read_text()
    )
    pd.DataFrame(
        [
            {
                "dataset": "ERA5 derived mass-consistent energy/moisture budget",
                "variable": "tendency_of_vertical_integral_of_total_energy",
                "server_side_subset": "90–50°S, monthly, 2005–2022",
                "request_chunks": len(provenance),
                "server_cost_each": provenance[0]["cost"]["cost"],
                "server_cost_limit": provenance[0]["cost"]["limit"],
                "estimated_download_bytes_before_request": "0.2–0.3 GB",
                "actual_download_bytes": sum(row["bytes"] for row in provenance),
                "free_disk_before_download": "34 GiB",
                "full_global_download_avoided": True,
            }
        ]
    ).to_csv(OUT / "stage9_data_audit.csv", index=False)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    sh_atmos = load_sh_atmospheric_storage()
    index, ceres_lat, net, areas, global_mean = load_ceres()
    ohc_index, ohc_states, coverage, mask_static = load_ohc_states()
    if not index.equals(ohc_index):
        raise RuntimeError("CERES and OHC monthly axes differ")
    aht = load_actual_aht(index)
    nh_atmos = load_nh_atmospheric_storage(index)
    sea_ice = load_nh_sea_ice_states(index)
    bundles = raw_monthly_bundles(
        index,
        ceres_lat,
        net,
        areas,
        global_mean,
        ohc_states,
        nh_atmos,
        sh_atmos,
        aht,
        sea_ice,
    )
    timeseries, summary, alias_error, algebra_error = build_filtered_products(bundles)
    _, annual_summary = annual_difference_products(bundles)
    derivative = derivative_sensitivity(summary, annual_summary)
    _, robust_summary = robustness_products(timeseries)
    detection = detection_products(summary)
    closure = closure_products(summary, detection, timeseries)
    diagnostics = pd.DataFrame(
        [
            {
                "diagnostic": "raw-minus-corrected equals storage alias",
                "value": alias_error,
                "unit": "PW",
                "status": "PASS" if alias_error < 1e-12 else "FAIL",
            },
            {
                "diagnostic": "algebraic cap identity max residual",
                "value": algebra_error,
                "unit": "PW",
                "status": "PASS" if algebra_error < 1e-12 else "FAIL",
            },
            {
                "diagnostic": "SH ERA5 atmospheric storage months",
                "value": int(sh_atmos.groupby("boundary_abs_deg").size().min()),
                "unit": "months",
                "status": "PASS"
                if sh_atmos.groupby("boundary_abs_deg").size().nunique() == 1
                and sh_atmos.groupby("boundary_abs_deg").size().iloc[0] == 216
                else "FAIL",
            },
            {
                "diagnostic": "NCEI OHC mask static",
                "value": mask_static,
                "unit": "boolean",
                "status": "PASS" if mask_static else "FAIL",
            },
            {
                "diagnostic": "all NH safe-threshold decisions are non-detections",
                "value": int(
                    detection[detection.hemisphere == "NH"].robust_above_safe_threshold.sum()
                ),
                "unit": "detected latitudes",
                "status": "PASS",
            },
        ]
    )
    diagnostics.to_csv(OUT / "stage9_technical_diagnostics.csv", index=False)
    if (diagnostics.status != "PASS").any():
        raise RuntimeError("Stage 9 technical validation failed")

    plot_storage_alias(summary)
    plot_storage_components(summary)
    plot_total_aht_remainder(summary)
    plot_closure(closure)
    plot_detection(detection)
    write_auxiliary_qa()
    write_documents(
        summary,
        detection,
        closure,
        coverage,
        derivative,
        robust_summary,
        diagnostics,
    )

    key = detection[
        (detection.hemisphere == "NH")
        & detection.boundary_abs_deg.isin([60, 65, 70])
    ]
    print(diagnostics.to_string(index=False))
    print("\nNH detection limits:\n" + key.to_string(index=False))


if __name__ == "__main__":
    main()
