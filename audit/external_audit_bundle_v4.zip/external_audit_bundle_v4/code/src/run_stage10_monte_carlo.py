"""Run the Stage 10 Monte Carlo calibration matrix.

No climate data are downloaded or modified. Synthetic tendency processes are
integrated to energy states and passed through the three existing storage
derivative estimators before trend inference is evaluated.
"""

from __future__ import annotations

import json
from pathlib import Path
import time

import numpy as np
import pandas as pd

from src.post_audit_statistics import (
    automatic_hac_lag,
    corrected_hac_batch,
    legacy_hac_batch,
    moving_block_bootstrap_se_batch,
    synthetic_estimator_series,
)


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
SEED = 20260808
N_SIM = 600
N_BOOT = 299
DGPS = ("white", "ar1_0.3", "ar1_0.6", "ar1_0.9", "ar2_long")
TRENDS = (0.0, 10.0, 40.0)
Z95 = 1.959963984540054


def _record(
    dgp: str,
    truth: float,
    estimator: str,
    method: str,
    slopes: np.ndarray,
    ses: np.ndarray,
    requested_lag: int | float,
    effective_lag: int | float,
    critical: float = Z95,
) -> dict:
    errors = slopes - truth
    half = critical * ses
    coverage = float(np.mean(np.abs(errors) <= half))
    empirical_sd = float(np.std(slopes, ddof=1))
    mean_se = float(np.mean(ses))
    return {
        "seed": SEED,
        "n_simulations": len(slopes),
        "n_bootstrap_per_simulation": N_BOOT if "bootstrap" in method else 0,
        "dgp": dgp,
        "truth_trend_tw_dec": truth,
        "estimator": estimator,
        "inference_method": method,
        "requested_lag": requested_lag,
        "effective_lag": effective_lag,
        "critical_value": critical,
        "coverage": coverage,
        "coverage_mc_se": float(np.sqrt(coverage * (1.0 - coverage) / len(slopes))),
        "bias_tw_dec": float(np.mean(errors)),
        "rmse_tw_dec": float(np.sqrt(np.mean(errors**2))),
        "empirical_sd_tw_dec": empirical_sd,
        "mean_reported_se_tw_dec": mean_se,
        "sd_to_reported_se_ratio": empirical_sd / mean_se if mean_se > 0 else np.inf,
        "mean_ci_halfwidth_tw_dec": float(np.mean(half)),
    }


def main() -> None:
    start = time.perf_counter()
    rng = np.random.default_rng(SEED)
    rows: list[dict] = []
    retained_auto: dict[tuple[str, float, str], tuple[np.ndarray, np.ndarray, int]] = {}
    retained_legacy: dict[tuple[str, float, str], tuple[np.ndarray, np.ndarray, int]] = {}

    for dgp in DGPS:
        for truth in TRENDS:
            products = synthetic_estimator_series(dgp, truth, N_SIM, rng)
            for estimator, (index, values) in products.items():
                legacy_slope, legacy_se, legacy_eff = legacy_hac_batch(values, index, 24)
                retained_legacy[(dgp, truth, estimator)] = (legacy_slope, legacy_se, legacy_eff)
                rows.append(_record(dgp, truth, estimator, "legacy_HAC24", legacy_slope, legacy_se, 24, legacy_eff))

                auto = automatic_hac_lag(len(index))
                auto_slope, auto_se, auto_eff = corrected_hac_batch(values, index, auto)
                retained_auto[(dgp, truth, estimator)] = (auto_slope, auto_se, auto_eff)
                rows.append(_record(dgp, truth, estimator, "corrected_HAC_auto", auto_slope, auto_se, auto, auto_eff))

                for lag in (0, 3, 6, 12):
                    slope, se, eff = corrected_hac_batch(values, index, lag)
                    rows.append(_record(dgp, truth, estimator, f"corrected_HAC{lag}", slope, se, lag, eff))

                block = 3 if estimator == "annual_difference" else 12
                mbb_se = moving_block_bootstrap_se_batch(
                    values,
                    index,
                    block_length=block,
                    n_boot=N_BOOT,
                    rng=rng,
                    moving=True,
                )
                rows.append(_record(dgp, truth, estimator, "moving_block_bootstrap", auto_slope, mbb_se, block, block))
                nbb_se = moving_block_bootstrap_se_batch(
                    values,
                    index,
                    block_length=block,
                    n_boot=N_BOOT,
                    rng=rng,
                    moving=False,
                )
                rows.append(_record(dgp, truth, estimator, "nonoverlap_block_bootstrap", auto_slope, nbb_se, block, block))

    # Calibrate the automatic-HAC critical value against the full declared DGP
    # envelope. The maximum DGP-specific 95th percentile prevents the pooled
    # sample from hiding poor coverage in the most persistent process.
    criticals: dict[str, float] = {}
    criticals_by_dgp: dict[str, dict[str, float]] = {}
    selected_base: dict[str, str] = {}
    for estimator in ("block_12m_means", "central_12m_endpoints", "annual_difference"):
        # HAC(24) is the least under-covering analytic estimator for the two
        # long overlapping monthly derivatives. For n=16 it is pathological,
        # so the annual branch instead uses corrected automatic lag 2.
        retained = retained_auto if estimator == "annual_difference" else retained_legacy
        selected_base[estimator] = "corrected_HAC_auto" if estimator == "annual_difference" else "legacy_HAC24"
        dgp_quantiles = []
        criticals_by_dgp[estimator] = {}
        for dgp in DGPS:
            standardized = []
            for truth in TRENDS:
                slopes, ses, _ = retained[(dgp, truth, estimator)]
                good = ses > 0
                standardized.extend(np.abs((slopes[good] - truth) / ses[good]))
            q95 = float(np.quantile(standardized, 0.95))
            dgp_quantiles.append(q95)
            criticals_by_dgp[estimator][dgp] = q95
        criticals[estimator] = max(dgp_quantiles)

    for estimator in ("block_12m_means", "central_12m_endpoints", "annual_difference"):
        retained = retained_auto if estimator == "annual_difference" else retained_legacy
        for (dgp, truth, est), (slopes, ses, eff) in retained.items():
            if est != estimator:
                continue
            crit = criticals[estimator]
            requested = automatic_hac_lag(16) if estimator == "annual_difference" else 24
            rows.append(
                _record(
                    dgp,
                    truth,
                    estimator,
                    "MC_envelope_calibrated_selected_HAC",
                    slopes,
                    ses,
                    requested,
                    eff,
                    crit,
                )
            )

    frame = pd.DataFrame(rows)
    frame.to_csv(OUT / "monte_carlo_calibration_matrix.csv", index=False)
    metadata = {
        "seed": SEED,
        "n_simulations_per_cell": N_SIM,
        "n_bootstrap_per_simulation": N_BOOT,
        "dgps": list(DGPS),
        "truth_trends_tw_dec": list(TRENDS),
        "dgp_ar2_coefficients": [1.20, -0.35],
        "synthetic_months": 216,
        "calibrated_critical_values": criticals,
        "calibrated_critical_values_by_dgp": criticals_by_dgp,
        "selected_base_inference": selected_base,
        "runtime_seconds": time.perf_counter() - start,
        "notes": "Synthetic monthly tendency was integrated to a state before applying each derivative. Critical values are maximum DGP-specific q95(|error/SE_selected|) over the declared DGP envelope. Selected base is HAC24 for monthly derivatives and corrected automatic-lag HAC for annual difference.",
    }
    (OUT / "monte_carlo_calibration_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")

    compact = (
        frame.groupby(["estimator", "inference_method"], sort=False)
        .agg(
            minimum_coverage=("coverage", "min"),
            median_coverage=("coverage", "median"),
            maximum_coverage=("coverage", "max"),
            maximum_abs_bias_tw_dec=("bias_tw_dec", lambda x: float(np.max(np.abs(x)))),
            maximum_sd_to_se_ratio=("sd_to_reported_se_ratio", "max"),
        )
        .reset_index()
    )
    compact.to_csv(OUT / "monte_carlo_method_summary.csv", index=False)
    print(json.dumps(metadata, indent=2))
    print(compact.to_string(index=False))


if __name__ == "__main__":
    main()
