# V4 packaging self-check

Run date: 2026-08-08 (Europe/Prague).

This is a packaging/reproducibility check, not a new climate calculation.  No
new climate data were downloaded and the full raw-data workflow was not run by
the packager; that work is deliberately assigned to the independent reviewer.

| Check | Result | Evidence |
|---|---|---|
| Candidate size before ZIP | PASS | 2,720 KiB allocated; well below 10 MB target and 25 MB maximum |
| Free disk during packaging | PASS | 46,276,256 KiB available |
| Raw climate files absent | PASS | no NetCDF, GRIB, HDF, gzip climate input or ZIP archive inside bundle |
| Author-reduced climate time series absent | PASS | CSV inventory contains only compact reference summaries/profiles and synthetic MC outputs; no monthly/annual climate time series |
| Four official download specifications complete | PASS | CERES, 15 exact ERA5 requests, NCEI OHC and PIOMAS machine-readable specs; dry-run reports 1,843,950,436 expected bytes |
| Download dry-run | PASS | all 15 immutable ERA5 requests and total disk estimate validated without a network call |
| Expected raw metadata explicit | PASS | `EXPECTED_RAW_METADATA.md` plus executable `verify_original_data.py` and ERA5 raw reducer checks |
| Active absolute paths absent | PASS | no author-machine path in bundle-root scripts or active `code/`; original Windows paths occur only in immutable first-audit exhibits and are disclosed in their README |
| Blind calculation isolated | PASS | `run_v4_blind_reproduction.sh` and `build_blind_results_table.py` contain no reference-results path or sealed numeric values |
| Reference reveal isolated | PASS | only `compare_after_blind.sh` invokes `reveal_and_compare.py` after the sealed CSV and completion marker exist |
| Reference tables not calculation inputs | PASS | raw workflow creates its own pre-audit baseline before installing Stage 10 code; references are joined only after blind completion |
| Blind-table contract | PASS | 68 quantities extracted from existing generated artifacts in packaging test; reference field stayed sealed until explicit reveal; post-reveal comparison machinery completed 68/68 |
| Python syntax | PASS | AST parse of 46 Python files |
| Independent ERA5 geometry/request tests | PASS | 7/7 tests pass |
| First-audit response complete | PASS | N1–N7 and R1–R2 each contain claim, reproduction, status, change, numerical effect and open question |
| Independent implementation possible | PASS | `METHODS.md` specifies signs, geometry, conversions, conservation equations, raw variables, storage derivatives and inference design without requiring helper code |
| Historical audit integrity | PASS | original HTML and three scripts preserved byte-for-byte with their SHA-256 values |
| Reference-figure limit | PASS | eight compact reference-only figures; all must be regenerated from fresh raw inputs for audit |
| Clean-copy contract tests | PASS | bundle copied to a new temporary directory; V4 contract and ERA5 independent tests pass with bytecode/cache disabled |
| Checksums in clean copy | PASS | `shasum -a 256 -c CHECKSUMS.sha256` succeeds for every listed payload |
| Internet/file escape in self-check | PASS | clean-copy checks use no internet and no file outside the copied bundle; raw reproduction is intentionally not simulated |

The immutable first-audit scripts are evidence, not active workflow code.  Their
embedded original reviewer path is the only absolute workstation path retained.

If the reviewer skips official downloads or raw-to-result processing, the V4
protocol requires: **INCOMPLETE — RAW DATA REPRODUCTION NOT PERFORMED.**
