"""Head-to-head: skutecna ucinnost obou derivatoru na TYCH SAMYCH realizacich.

Vystup: skutecna smerodatna odchylka odhadu trendu (spolecna skala) a z ni
poctivy detekcni limit, proti tomu, co balicek reportuje.
"""
import sys
from pathlib import Path

BUNDLE = Path(r"C:\Users\vitp\Desktop\external_audit_bundle_v3")
sys.path.insert(0, str(BUNDLE / "code"))

import numpy as np
import pandas as pd
import src.energy_budget as eb
from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints
from src.analyze_transport_profile import _state_at

N_MONTHS, N_ITER = 216, 6000
INDEX = monthly_midpoints("2005-01", N_MONTHS)
_p = INDEX.to_period("M")
SEC = np.asarray([(b - a).total_seconds() for a, b in
                  zip(_p.to_timestamp(how="start"), (_p + 1).to_timestamp(how="start"))])
YEARS = list(range(2006, 2022))
ANN_INDEX = pd.DatetimeIndex([pd.Timestamp(y, 7, 1) for y in YEARS])

_orig = eb.decimal_year; _cache = {}
def _c(ix):
    k = (len(ix), ix[0].value, ix[-1].value)
    if k not in _cache: _cache[k] = _orig(ix)
    return _cache[k]
eb.decimal_year = _c


def as_matrix(fn):
    cols, ti = [], None
    for i in range(N_MONTHS):
        b = np.zeros(N_MONTHS); b[i] = 1.0
        r = fn(b)
        if isinstance(r, tuple): ti, r = r
        cols.append(r)
    return ti, np.column_stack(cols)


def annual_op(energy):
    out = []
    for y in YEARS:
        s, e = pd.Timestamp(y, 1, 1), pd.Timestamp(y + 1, 1, 1)
        out.append((_state_at(energy, INDEX, e) - _state_at(energy, INDEX, s))
                   / (e - s).total_seconds())
    return np.asarray(out)


T_B, M_B = as_matrix(lambda v: block_mean_tendency(v, INDEX))
T_C, M_C = as_matrix(lambda v: central_span_tendency(v, INDEX))
_, M_A = as_matrix(annual_op)

EST = {
    "block_12m_means (PRIMARNI)": (M_B, T_B, 24, True),
    "central_12m_endpoints":      (M_C, T_C, 24, True),
    "annual_difference":          (M_A, ANN_INDEX, 24, False),
}

PHI = 0.6
rng = np.random.default_rng(2024)
slopes = {k: np.empty(N_ITER) for k in EST}
ses = {k: np.empty(N_ITER) for k in EST}
for it in range(N_ITER):
    e = rng.standard_normal(N_MONTHS)
    f = np.empty(N_MONTHS); f[0] = e[0] / np.sqrt(1 - PHI**2)
    for t in range(1, N_MONTHS):
        f[t] = PHI * f[t - 1] + e[t]
    energy = np.concatenate([[0.0], np.cumsum(f * SEC)])[:-1] + 0.5 * f * SEC
    for k, (M, ix, ml, des) in EST.items():
        tr = eb.ols_hac_trend(M @ energy, ix, deseasonalize=des, maxlags=ml)
        slopes[k][it] = tr.slope_per_decade
        ses[k][it] = tr.se_per_decade

print(f"AR(1) phi={PHI}, N_ITER={N_ITER}, spolecne realizace toku\n")
base = None
print(f"{'estimator':>28} {'skut.SD':>10} {'rel.ucin.':>10} {'prum.SE':>10} {'SD/SE':>7} {'pokryti':>8}")
for k in EST:
    sd = float(np.std(slopes[k], ddof=1)); se = float(np.mean(ses[k]))
    if base is None: base = sd
    cov = float(np.mean((slopes[k] - 1.96 * ses[k] <= 0) & (0 <= slopes[k] + 1.96 * ses[k])))
    print(f"{k:>28} {sd:>10.4e} {sd/base:>10.2f} {se:>10.4e} {sd/se:>7.2f} {cov:>7.1%}")

print("\n--- prepocet na realne jednotky: h_known+SI na 70N ---")
rep = {"block_12m_means (PRIMARNI)": 31.24, "central_12m_endpoints": 36.80, "annual_difference": 9.65}
print(f"{'estimator':>28} {'reportovany MDE95':>18} {'poctivy MDE95':>15}")
for k in EST:
    sd = float(np.std(slopes[k], ddof=1)); se = float(np.mean(ses[k]))
    print(f"{k:>28} {rep[k]:>18.2f} {rep[k]*sd/se:>15.2f}")
