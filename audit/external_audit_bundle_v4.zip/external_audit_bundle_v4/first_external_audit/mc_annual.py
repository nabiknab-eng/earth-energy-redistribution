"""Doplnkovy test: pokryti CI pro vetev annual_difference (n=16).

Replikuje presne strukturu annual_difference_products: neprekryvajici se rozdily
kalendarniho stavu interpolovaneho na 1.1. (jejich _state_at = np.interp),
16 hodnot za roky 2006..2021, otisteno na 1.7.  Trend pres jejich ols_hac_trend.

Pipeline vola trend_row -> ols_hac_trend(maxlags=24), coz pri n=16 znamena
min(24, 15) = 15 lagu na 16 pozorovanich.
"""
import sys
from pathlib import Path

BUNDLE = Path(r"C:\Users\vitp\Desktop\external_audit_bundle_v3")
sys.path.insert(0, str(BUNDLE / "code"))

import numpy as np
import pandas as pd
import src.energy_budget as eb
from src.analyze_ohc_storage import monthly_midpoints
from src.analyze_transport_profile import _state_at

N_MONTHS = 216
N_ITER = 4000
INDEX = monthly_midpoints("2005-01", N_MONTHS)
_p = INDEX.to_period("M")
SEC = np.asarray([(b - a).total_seconds() for a, b in
                  zip(_p.to_timestamp(how="start"), (_p + 1).to_timestamp(how="start"))])
YEARS = list(range(2006, 2022))                     # 16 hodnot, jako v pipeline
ANN_INDEX = pd.DatetimeIndex([pd.Timestamp(y, 7, 1) for y in YEARS])

_orig = eb.decimal_year
_cache: dict[tuple, np.ndarray] = {}


def _cached(index):
    key = (len(index), index[0].value, index[-1].value)
    if key not in _cache:
        _cache[key] = _orig(index)
    return _cache[key]


eb.decimal_year = _cached

# annual differencing je take linearni operator -> vytahnu jako matici
def annual_op(energy):
    out = []
    for y in YEARS:
        s = pd.Timestamp(y, 1, 1); e = pd.Timestamp(y + 1, 1, 1)
        out.append((_state_at(energy, INDEX, e) - _state_at(energy, INDEX, s))
                   / (e - s).total_seconds())
    return np.asarray(out)


cols = []
for i in range(N_MONTHS):
    b = np.zeros(N_MONTHS); b[i] = 1.0
    cols.append(annual_op(b))
M_ANN = np.column_stack(cols)
rng0 = np.random.default_rng(3)
v = rng0.standard_normal(N_MONTHS) * 1e20
assert np.max(np.abs(M_ANN @ v - annual_op(v))) / np.max(np.abs(annual_op(v))) < 1e-12
print(f"annual operator overen jako linearni; n={M_ANN.shape[0]}\n")


def run(phi, maxlags, n_iter=N_ITER, seed=999):
    rng = np.random.default_rng(seed)
    cover = 0
    slopes = np.empty(n_iter); ses = np.empty(n_iter)
    for k in range(n_iter):
        e = rng.standard_normal(N_MONTHS)
        if phi:
            f = np.empty(N_MONTHS); f[0] = e[0] / np.sqrt(1 - phi**2)
            for t in range(1, N_MONTHS):
                f[t] = phi * f[t - 1] + e[t]
        else:
            f = e
        energy = np.concatenate([[0.0], np.cumsum(f * SEC)])[:-1] + 0.5 * f * SEC
        tr = eb.ols_hac_trend(M_ANN @ energy, ANN_INDEX, deseasonalize=False, maxlags=maxlags)
        if tr.ci_low <= 0.0 <= tr.ci_high:
            cover += 1
        slopes[k] = tr.slope_per_decade; ses[k] = tr.se_per_decade
    sd = float(np.std(slopes, ddof=1))
    return cover / n_iter, sd, float(np.mean(ses)), sd / float(np.mean(ses))


print(f"N_ITER={N_ITER}, n=16 rocnich hodnot, nominalni pokryti = 95.0%")
print(f"{'phi':>5} {'maxlags':>8} {'pokryti':>9} {'SD/SE':>7}   pozn.")
for phi in (0.0, 0.6, 0.9):
    for ml in (1, 2, 3, 24):
        cov, sd, se, ratio = run(phi, ml)
        note = "  <-- co pipeline skutecne pouziva (min(24,15)=15 lagu)" if ml == 24 else ""
        print(f"{phi:>5.1f} {ml:>8} {cov:>8.1%} {ratio:>7.2f}{note}")
    print()
