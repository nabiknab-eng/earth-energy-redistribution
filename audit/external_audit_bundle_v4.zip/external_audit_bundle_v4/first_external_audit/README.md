# Immutable first-audit exhibits

These four files are copied unchanged from the first external reviewer:

| file | SHA-256 |
|---|---|
| `audit_verdikt_v3-1.html` | `259296ed258f472e103b12ee28b9009f5ff60c3bb0da32da87549a93fa95512f` |
| `mc_annual.py` | `8fdab798316e00e146d2aa5f5af635a726501965f3cbb1bfde37ba798f60a480` |
| `mc_coverage.py` | `0de256b59f5cd04808fa5a6e676f4ee24751623cb984e7a354ecc3b9b15ade3b` |
| `mc_headtohead.py` | `f4f79c7d394dedafb8609552da539c95dbd2536121186cbaad63d6e540c402ca` |

The Python exhibits contain the first reviewer's original Windows workstation
path.  That path is preserved for evidentiary integrity and is **not active V4
code**.  Use the portable V4 scripts in the bundle root and `code/`; do not run
these historical scripts without first adapting a copy outside the bundle.
