"""Adversarialni test: pokryti 95% HAC intervalu pro primarni derivator balicku.

Null: storage tendency dE/dt NEMA trend.  Generuje se tok F(t) bez trendu,
integruje se na energeticky stav E(t), aplikuje se JEJICH derivator a JEJICH
ols_hac_trend.  Spravne kalibrovany 95% interval musi pokryvat nulu v 95 %
pripadu.  Nizsi pokryti => intervaly jsou prilis uzke => MDE95 podhodnocuje
skutecny detekcni limit.

Vykonnostni poznamka: block_mean_tendency i central_span_tendency jsou LINEARNI
operatory na vstupnim vektoru (casova mrizka je fixni).  Vytahnu je proto jednou
jako matici aplikaci na bazove vektory - vysledek je bitove tentyz operator,
jen rychly.  decimal_year je deterministicka funkce fixniho indexu, takze se
cachuje.  Vlastni OLS/HAC algoritmus zustava jejich, nedotceny.
"""
import sys
from pathlib import Path

BUNDLE = Path(r"C:\Users\vitp\Desktop\external_audit_bundle_v3")
sys.path.insert(0, str(BUNDLE / "code"))

import numpy as np
import pandas as pd
import src.energy_budget as eb
from src.analyze_ohc_storage import block_mean_tendency, central_span_tendency, monthly_midpoints

N_MONTHS = 216          # 2005-01 .. 2022-12, presne jako v pipeline
N_ITER = 4000
INDEX = monthly_midpoints("2005-01", N_MONTHS)
_p = INDEX.to_period("M")
SEC = np.asarray([(b - a).total_seconds() for a, b in
                  zip(_p.to_timestamp(how="start"), (_p + 1).to_timestamp(how="start"))])

# --- cache decimal_year (deterministicka funkce fixniho indexu) ---
_orig_decimal_year = eb.decimal_year
_dy_cache: dict[tuple, np.ndarray] = {}


def _cached_decimal_year(index):
    key = (len(index), index[0].value, index[-1].value)
    if key not in _dy_cache:
        _dy_cache[key] = _orig_decimal_year(index)
    return _dy_cache[key]


eb.decimal_year = _cached_decimal_year


def build_operator(fn):
    """Vytahne linearni operator derivatoru jako matici pomoci bazovych vektoru."""
    cols = []
    t_idx = None
    for i in range(N_MONTHS):
        basis = np.zeros(N_MONTHS)
        basis[i] = 1.0
        ti, out = fn(basis, INDEX)
        t_idx = ti
        cols.append(out)
    M = np.column_stack(cols)
    # overeni linearity na nahodnem vektoru
    rng = np.random.default_rng(7)
    v = rng.standard_normal(N_MONTHS) * 1e20
    _, direct = fn(v, INDEX)
    err = np.max(np.abs(M @ v - direct)) / np.max(np.abs(direct))
    assert err < 1e-12, f"operator neni linearni: {err:.3e}"
    return t_idx, M


T_BLOCK, M_BLOCK = build_operator(block_mean_tendency)
T_CENTRAL, M_CENTRAL = build_operator(central_span_tendency)
print(f"operatory overeny jako linearni; n_block={len(T_BLOCK)}, n_central={len(T_CENTRAL)}\n")


def run(phi, seasonal_amp, maxlags, deriv="block", seed=12345, n_iter=N_ITER):
    rng = np.random.default_rng(seed)
    M, t_idx = (M_BLOCK, T_BLOCK) if deriv == "block" else (M_CENTRAL, T_CENTRAL)
    month_wave = np.sin(2 * np.pi * (INDEX.month.to_numpy() - 1) / 12.0)
    cover = 0
    slopes = np.empty(n_iter)
    ses = np.empty(n_iter)
    for k in range(n_iter):
        e = rng.standard_normal(N_MONTHS)
        if phi:                      # AR(1) tok bez trendu
            f = np.empty(N_MONTHS)
            f[0] = e[0] / np.sqrt(1 - phi**2)
            for t in range(1, N_MONTHS):
                f[t] = phi * f[t - 1] + e[t]
        else:
            f = e
        if seasonal_amp:
            f = f + seasonal_amp * month_wave
        energy = np.concatenate([[0.0], np.cumsum(f * SEC)])[:-1] + 0.5 * f * SEC
        tr = eb.ols_hac_trend(M @ energy, t_idx, maxlags=maxlags)
        if tr.ci_low <= 0.0 <= tr.ci_high:
            cover += 1
        slopes[k] = tr.slope_per_decade
        ses[k] = tr.se_per_decade
    return {"coverage": cover / n_iter, "true_sd": float(np.std(slopes, ddof=1)),
            "mean_se": float(np.mean(ses)), "ratio": float(np.std(slopes, ddof=1) / np.mean(ses)),
            "n": len(t_idx)}


if __name__ == "__main__":
    print(f"N_ITER={N_ITER}, N_MONTHS={N_MONTHS}, nominalni pokryti = 95.0%\n")
    print("A) PRIMARNI DERIVATOR (block_12m_means), bez sezonnosti")
    print(f"{'phi':>5} {'maxlags':>8} {'n':>5} {'pokryti':>9} {'SD/SE':>7}   {'podhodnoceni SE'}")
    for phi in (0.0, 0.6, 0.9):
        for ml in (12, 24, 36, 48, 72):
            r = run(phi, 0.0, ml)
            flag = "  <-- deklarovane v METHODS" if ml == 24 else ""
            print(f"{phi:>5.1f} {ml:>8} {r['n']:>5} {r['coverage']:>8.1%} {r['ratio']:>7.2f}   "
                  f"{(r['ratio']-1)*100:>+6.1f}%{flag}")
        print()

    print("B) VLIV DESEASONALIZACE (phi=0.6, maxlags=24)")
    print(f"{'seas_amp':>9} {'pokryti':>9} {'SD/SE':>7}")
    for amp in (0.0, 1.0, 3.0, 10.0):
        r = run(0.6, amp, 24)
        print(f"{amp:>9.1f} {r['coverage']:>8.1%} {r['ratio']:>7.2f}")

    print("\nC) SROVNANI DERIVATORU (phi=0.6, maxlags=24)")
    print(f"{'derivator':>22} {'n':>5} {'pokryti':>9} {'SD/SE':>7}")
    for d in ("block", "central"):
        r = run(0.6, 0.0, 24, deriv=d)
        print(f"{d:>22} {r['n']:>5} {r['coverage']:>8.1%} {r['ratio']:>7.2f}")
