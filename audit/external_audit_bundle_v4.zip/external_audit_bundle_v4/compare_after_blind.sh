#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
PYTHON_BIN="${PYTHON:-python3}"
WORKSPACE="${AUDIT_WORKSPACE:-$ROOT/work/raw_reproduction_workspace}"
BLIND="$WORKSPACE/outputs/INDEPENDENT_RAW_REPRODUCTION.csv"
if [[ ! -s "$BLIND" ]] || [[ ! -s "$WORKSPACE/outputs/BLIND_REPRODUCTION_RESULT.txt" ]]; then
  printf 'INCOMPLETE — RAW DATA REPRODUCTION NOT PERFORMED.\n' >&2
  exit 2
fi
exec "$PYTHON_BIN" "$ROOT/code/reveal_and_compare.py" \
  --blind-results "$BLIND" \
  --reference "$ROOT/reference_results/BLIND_REFERENCE_VALUES.csv" \
  --output-dir "$WORKSPACE/outputs"
