# Open methodological questions

1. Does the Monte Carlo calibration transfer from synthetic single-process
   tendencies to multicomponent `H_corr`, whose components have different
   persistence, measurement structures and covariance?
2. Can one critical value legitimately be applied to `H_corr`, CERES raw,
   storage alias, ERA5 AHT and the remainder?
3. Is the white/AR(1)/AR(2) DGP envelope adequate?  It omits long memory,
   state-dependent variance, nonstationarity and regime shifts.
4. Does AR(1) `phi=0.9` represent a defensible stress test or dominate the
   maximum-DGP envelope in a way that obscures more realistic performance?
5. What is out-of-sample coverage under new seeds and residual-based DGPs?
6. Should the reported interval be called a 95% CI, or only a calibrated
   scenario envelope?
7. Is retaining HAC(24) standard errors and calibrating the critical value
   preferable to prewhitened HAC, fixed-b inference, sieve/ARMA bootstrap or
   longer block bootstrap?
8. How should unquantified deep-ocean, land, glacier/ice-sheet and sea-ice
   structural uncertainty be represented without inventing an ad-hoc sum?
9. How much can ERA5 observing-system changes or model structure affect AHT
   trends over a short common record?
10. How large are cap-resolved NCEI OHC mapping/sampling errors, especially in
    sparsely observed polar waters?
11. How material is storage below 2000 m for the cap trends?
12. What covariance is induced by the global OHC constraint in CERES EBAF, and
    how independent is the regional OHC correction in practice?
13. Can the absolute non-atmospheric remainder be safely decomposed with an
    independently observed OHT product, or does omitted storage dominate its
    trend uncertainty?
14. Does monthly global-mean removal affect interpretation through pathways
    other than the explicit algebraic term that cancels in `H_corr`?
15. Is the CERES-era record long enough to separate a forced/long-term trend
    from multidecadal variability at the requested transport boundaries?
