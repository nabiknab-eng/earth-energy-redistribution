# SEALED UNTIL BLIND RAW REPRODUCTION IS COMPLETE

Do not read this file, `reference_results/`, or `reference_figures/` until you
have downloaded the four official datasets, completed an independent
raw-to-result calculation and saved `INDEPENDENT_RAW_REPRODUCTION.csv`.

After that point, run `./compare_after_blind.sh`.  It joins the preserved blind
results to `reference_results/BLIND_REFERENCE_VALUES.csv` and writes a revealed
comparison.  No reference value is imported by the main reproduction script.

Headline author references for interpretation after reveal are:

- `H_corr` best estimate at 60/65/70°N: +0.77 / -0.11 / +2.75 TW decade-1.
- full MC temporal half-width: 98.85 / 80.12 / 72.84 TW decade-1.
- non-extreme-DGP sensitivity half-width: 76.27 / 61.82 / 56.19 TW decade-1.
- storage-alias trend: 21.30 / 18.23 / 12.18 TW decade-1; calibrated intervals
  include zero.

These are comparison targets, never computational inputs.  Any disagreement
must be preserved and diagnosed rather than tuned away.
