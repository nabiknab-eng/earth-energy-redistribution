# Přesná specifikace původních downloadů

Historický celkový objem je **1,843,950,436 B (1.717 GiB)**. Jednotlivé SHA a
bytes jsou provenance reference; jejich neshoda po fresh downloadu není sama o
sobě vědecká neshoda.

## CERES EBAF Edition4.2.1

- Instituce: NASA Langley Research Center.
- Oficiální OPeNDAP:
  `https://opendap.larc.nasa.gov/opendap/CERES/EBAF/Edition4.2.1/CERES_EBAF_Edition4.2.1_200003-202603.nc`
- Remote filename: `CERES_EBAF_Edition4.2.1_200003-202603.nc`.
- Lokální subset: `ceres_ebaf_ed4.2.1_zonal_global_200003-202603.nc`.
- Období: 2000-03 až 2026-03; hlavní analýza 2005-01 až 2022-12.
- Prostor: native 180 zonálních 1° pásem a globální monthly scalars; žádná
  lon×lat mapa.
- Proměnné a exact subset jsou v `ceres_ebaf_ed4.2.1.json`.
- Původní lokální subset: 1,654,948 B;
  SHA256 `7739eb63b1440dcd2f13a2c1c12c0b1dbb91a45e091e4178ba6c013f9742f2b5`.

## ERA5 mass-consistent derived energy/moisture budget

- Instituce: ECMWF / Copernicus Climate Change Service.
- CDS dataset/API identifier: `derived-reanalysis-energy-moisture-budget`.
- Product version: `v1.0` v původních NetCDF members.
- API endpoint používaný `cdsapi`: `https://cds.climate.copernicus.eu/api`.
- Landing page:
  `https://cds.climate.copernicus.eu/datasets/derived-reanalysis-energy-moisture-budget`.
- Proměnné: `vertical_integral_of_northward_total_energy_flux` a
  `tendency_of_vertical_integral_of_total_energy`.
- Období: AHT 2000-01 až 2022-12; SH atmospheric storage 2005-01 až 2022-12.
- Spatial subsets: 90°S–30°N, 29.75–85.25°N, 85–90°N, 30–90°N a
  90–50°S podle jednotlivých větví.
- Přesných 15 request payloadů, year chunks, months, areas, filenames,
  original SHA256 a bytes je v `era5_requests.json`.
- Žádný `format` ani `grid` parametr nebyl do původních requestů přidán.
- Původní archivy: 1,757,939,898 B celkem; 15 individuálních SHA256 v JSON.
- Immutable původní request copies jsou v `code/era5/original_requests/`.

## NCEI OHC 0–2000 m monthly

- Instituce: NOAA NCEI/NODC Ocean Climate Laboratory.
- Exact product title:
  `Ocean Heat Content anomalies from WOA09 : heat_content_anomaly 0-2000 m monthly 1.00 degree`.
- Oficiální URL:
  `https://www.ncei.noaa.gov/data/oceans/woa/DATA_ANALYSIS/3M_HEAT_CONTENT/NETCDF/heat_content/heat_content_anomaly_0-2000_monthly.nc`
- Remote filename: `heat_content_anomaly_0-2000_monthly.nc`.
- Původní lokální filename:
  `heat_content_anomaly_0-2000_monthly_20260707.nc`.
- Download subset: žádný; native global 1×1° NetCDF.
- Použitá proměnná: `h18_hc`, units `10^18_joules`; období 2005-01 až 2022-12.
- Původní soubor: 66,430,205 B;
  SHA256 `c9bfadc494dccf3f1cfeb9f1ffa4d6cebb6d79bbf0bdadd3aa64ef639524a05d`.
- Další detail je v `ncei_ohc_0_2000_monthly.json`.

## PIOMAS v2.1

- Instituce: University of Washington APL Polar Science Center.
- Data page:
  `https://psc.apl.uw.edu/research/projects/arctic-sea-ice-volume-anomaly/data/`.
- Model-grid page:
  `https://psc.apl.uw.edu/research/projects/arctic-sea-ice-volume-anomaly/data/model_grid`.
- Monthly volume URL:
  `https://psc.apl.uw.edu/wordpress/wp-content/uploads/schweiger/ice_volume/PIOMAS.monthly.Current.v2.1.csv`.
- Annual effective-thickness base URL:
  `https://pscfiles.apl.uw.edu/zhang/PIOMAS/data/v2.1/heff/`.
- Files: aggregate CSV plus `heff.H2005.nc.gz` až `heff.H2022.nc.gz`.
- Prostor: celý 360×120 curvilinear Arctic grid; cap subsets vznikají lokálně.
- Proměnné: `heff`, `lat_scaler`, `kmt`, `dxt`, `dyt`, official volume.
- Období: 2005-01 až 2022-12.
- Původní objem: 17,925,385 B.
- Každý filename, SHA256 a bytes je v `piomas_original_files.json`; URL vzniká
  přesným připojením filename k uvedenému official base URL.

