# V4 independent raw-data audit

This bundle supports a second, adversarial audit of a CERES-era reconstruction
of Earth's meridional energy redistribution.  It tests two separate objects:

1. the absolute climatological TOA balance, CERES-implied transport and ERA5
   atmospheric transport over 90°S–90°N; and
2. the post-audit inference for the trend of **known-storage-corrected required
   transport** across Arctic boundaries.

It does **not** test attribution to CO2, clouds, aerosols, forcing or any climate
theory.  It does not claim that a non-detected trend is zero.

## Non-negotiable audit rule

The ZIP contains no raw or author-reduced climate time series.  Download CERES,
ERA5, NCEI OHC and PIOMAS from the specified official sources and perform the
raw-to-result chain.  If that is not done, the verdict must be:

> **INCOMPLETE — RAW DATA REPRODUCTION NOT PERFORMED.**

A code-only desk audit is useful commentary but is not a completed V4 audit.
If a source cannot be downloaded, write `DATASET_DOWNLOAD_FAILED`, identify the
dataset, URL/API error and every result that remains unverified.  Do not replace
the failed input with an author-reduced series.

## Blind protocol

Do not open `reference_results/`, `reference_figures/` or
`REFERENCE_RESULTS_AFTER_BLIND_REPRODUCTION.md` before recording independent
results.  The main script does not import any reference value.

1. Read `REVIEWER_PROMPT.md`, `METHODS.md`,
   `DATA_DOWNLOAD_AND_PROVENANCE.md`, `EXPECTED_RAW_METADATA.md`,
   `CLAIMS_AND_EVIDENCE.md`, `OPEN_METHODICAL_QUESTIONS.md` and
   `KNOWN_LIMITATIONS.md`.
2. Prefer an independent implementation of geometry, transport, storage and
   statistics.  The supplied code is inspectable, not an oracle.
3. Install the pinned environment, configure CDS credentials, and run:

   ```bash
   python3 -m venv .audit-venv
   . .audit-venv/bin/activate
   pip install -r requirements-lock.txt
   ./run_v4_blind_reproduction.sh
   ```

4. Inspect and preserve
   `work/raw_reproduction_workspace/outputs/INDEPENDENT_RAW_REPRODUCTION.csv`.
5. Only after the blind table exists, reveal and compare:

   ```bash
   ./compare_after_blind.sh
   ```

Use `AUDIT_WORKSPACE=/absolute/path` to place the approximately 1.72 GiB raw
download and generated intermediates elsewhere.  Use `SKIP_DOWNLOAD=1` only
when that location already contains independently downloaded official inputs;
it must never point at author-reduced time series.

## Reading order after the blind calculation

1. `REFERENCE_RESULTS_AFTER_BLIND_REPRODUCTION.md`
2. `RESPONSE_TO_FIRST_EXTERNAL_AUDIT.md`
3. `stage10_audit_response/`
4. `first_external_audit/`
5. `reference_results/` and `reference_figures/`

The final review must give separate verdicts for absolute redistribution,
storage-corrected budget, trend inference and the overall scientific claim.
