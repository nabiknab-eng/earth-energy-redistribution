#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
PYTHON_BIN="${PYTHON:-python3}"
WORKSPACE="${AUDIT_WORKSPACE:-$ROOT/work/raw_reproduction_workspace}"
exec "$PYTHON_BIN" "$ROOT/code/download_all_original_data.py" --workspace-dir "$WORKSPACE" "$@"
