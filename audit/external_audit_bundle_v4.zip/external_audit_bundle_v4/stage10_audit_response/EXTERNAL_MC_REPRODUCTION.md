# Reprodukce externích Monte Carlo skriptů

## Stav

Všechny tři dodané skripty byly 2026-08-08 spuštěny **beze změny** v
projektovém prostředí `.venv`. Skripty obsahují pevnou Windows cestu
`C:\Users\vitp\Desktop\external_audit_bundle_v3`; na macOS proto vznikl pouze
kompatibilní adresář s kopií nezměněného V3 kódu. Samotné skripty nebyly
editovány. První technický pokus se systémovým Pythonem skončil před výpočtem
kvůli chybějícímu `matplotlib`; výsledky níže pocházejí z úspěšného běhu ve
stejném `.venv`, které používá hlavní analýza.

Vstupní soubory a SHA-256:

- `mc_coverage.py`: `0de256b59f5cd04808fa5a6e676f4ee24751623cb984e7a354ecc3b9b15ade3b`
- `mc_annual.py`: `8fdab798316e00e146d2aa5f5af635a726501965f3cbb1bfde37ba798f60a480`
- `mc_headtohead.py`: `f4f79c7d394dedafb8609552da539c95dbd2536121186cbaad63d6e540c402ca`
- audit HTML: `259296ed258f472e103b12ee28b9009f5ff60c3bb0da32da87549a93fa95512f`

## Přímé výsledky

`mc_coverage.py`, 4 000 realizací, seed 12345, primární derivátor,
`maxlags=24`:

| AR(1) φ | coverage | empirická SD | průměrná SE | SD/SE |
|---:|---:|---:|---:|---:|
| 0,0 | 77,925 % | 0,15040 | 0,09939 | 1,513 |
| 0,6 | 76,775 % | 0,37486 | 0,24398 | 1,536 |
| 0,9 | 69,025 % | 1,42992 | 0,78736 | 1,816 |

Pro φ=0,6 má `central_12m_endpoints` coverage 80,05 %, SD/SE 1,428.
Přidaný sezónní cyklus coverage prakticky nemění (76,8–76,9 %).

`mc_annual.py`, 4 000 realizací, seed 999, n=16, požadavek
`maxlags=24` (efektivně 15):

| AR(1) φ | coverage | empirická SD | průměrná SE | SD/SE |
|---:|---:|---:|---:|---:|
| 0,0 | 51,15 % | 0,15254 | 0,05684 | 2,684 |
| 0,6 | 50,475 % | 0,37710 | 0,13782 | 2,736 |
| 0,9 | 45,825 % | 1,41673 | 0,46245 | 3,064 |

`mc_headtohead.py`, 6 000 společných realizací, seed 2024, φ=0,6:

| derivátor | empirická SD | relativní účinnost | průměrná SE | SD/SE | coverage |
|---|---:|---:|---:|---:|---:|
| block_12m_means | 0,36919 | 1,00 | 0,24518 | 1,51 | 78,0 % |
| central_12m_endpoints | 0,34461 | 0,93 | 0,24467 | 1,41 | 80,9 % |
| annual_difference | 0,38568 | 1,04 | 0,14020 | 2,75 | 50,0 % |

Zaznamenané wall-clock časy byly přibližně 59 s, 24,3 s a 12,3 s. Čas
zahrnuje importy a u prvního běhu jednorázovou přípravu cache fontů.

## Verdikt reprodukce

- N1 (podpokrytí měsíční HAC inference): **CONFIRMED**.
- N2 (patologická annual-difference HAC inference): **CONFIRMED**.
- R1 (původní tvrzení, že derivátory mají skutečnou účinnost lišící se 3×):
  **INVALID CRITICISM**; head-to-head ukazuje podobnou empirickou SD.
- R2 (původní tvrzení založené na nominální signifikanci): **INVALID
  CRITICISM**; po kalibraci intervaly nulu nevylučují.

Úplný strukturovaný výpis klíčových běhů je v
`external_mc_reproduction.csv`. Rozšířená nezávislá matice je v
`monte_carlo_calibration_matrix.csv`.

