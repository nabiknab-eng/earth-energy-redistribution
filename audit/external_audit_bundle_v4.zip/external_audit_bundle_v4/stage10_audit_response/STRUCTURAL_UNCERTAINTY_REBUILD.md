# Přestavba strukturální nejistoty

## Výsledek

Původní `structural bound` ani součet `MDE95 + structural bound` nemají
obhajitelnou statistickou interpretaci. Původní `safe threshold` je proto
zrušen, nikoli nahrazen jinou ad-hoc konstantou.

Nový výstup odděluje:

1. MC-kalibrovanou temporální inferenci,
2. přesně vyčíslené metodické scénáře,
3. nevyčíslené fyzikální/reanalýzní strukturální nejistoty.

## Audit původních složek

| složka | původní vzorec | audit | post-audit zacházení |
|---|---|---|---|
| deep ocean | `0.06 × MDE95(OHC 0–2000)` | temporal noise neměří neznalost >2000 m | UNQUANTIFIED |
| OHC mapping | `max(|block−central|, 0.20 × MDE95)` | MDE floor dvojitě počítá stejný šum; floor vyhrával na klíčových hranicích | UNQUANTIFIED |
| sea-ice model | `0.012 W m⁻² × EARTH_AREA × drift` | stejných 7,201 TW/dekádu pro všechny čepičky; chybné prostorové škálování | UNQUANTIFIED |
| land heat | globální rate uncertainty alokovaná přes cap land area | v projektu chybí dohledatelný cap-resolved nezávislý trendový error model | UNQUANTIFIED |
| glacier/ice sheet | 3,0 do 75°N, potom 1,5 | hardcoded nespojitost bez masky/datového podkladu | UNQUANTIFIED |
| atmospheric kinetic/potential | 0 | příslušná energie je zahrnuta v ERA5 total energy | zahrnuto v best estimate; strukturální trend ERA5 zůstává UNQUANTIFIED |

Na 60/65/70°N činil původní structural součet 20,899 / 17,566 / 16,109
TW/dekádu. Z toho deep + OHC mapping představovaly 8,642 / 6,119 / 5,381
TW/dekádu a nebyly nezávislé na temporální inferenci. Sea-ice term byl všude
7,201 TW/dekádu bez ohledu na velikost čepičky. Tyto hodnoty se dále nepoužívají.

## PIOMAS rescaling — vyčíslený metodický scénář

Měsíční faktor grid→official má rozsah 0,990–1,203, průměr 1,0284, lineární
trend −0,0183 za dekádu a kvadratickou druhou derivaci −0,000414 za dekádu².
Korelace jeho 12měsíční tendence s sea-ice storage tendency je podle hranice
−0,35 až −0,49.

Rozdíl H_corr trendu mezi současným měsíčním scalingem a konstantním/no
scalingem je:

| hranice | max. absolutní změna (TW/dekádu) | plná temporální půlšířka |
|---:|---:|---:|
| 50°N | 0,345 | 155,63 |
| 60°N | 0,338 | 98,85 |
| 65°N | 0,332 | 80,12 |
| 70°N | 0,321 | 72,84 |
| 75°N | 0,265 | 58,15 |
| 80°N | 0,174 | 39,82 |

Uniformní rescaling tedy skutečně vnáší měřitelný signál, ale jeho dopad na
trend je v těchto datech o více než dva řády menší než kalibrovaná temporální
nejistota. To je **metodická citlivost**, nikoli nezávislý odhad úplné PIOMAS
nejistoty. Latitude-aware scaling nebyl vytvořen, protože pan-arktický aggregate
neobsahuje informaci potřebnou k jeho obhajobě.

## Co zůstává nevyčísleno

- deep ocean pod 2000 m,
- cap-resolved mapping/sampling error NCEI OHC,
- strukturální chyba PIOMAS a ERA5 trendu,
- land heat a glacier/ice-sheet enthalpy.

Nevyčísleno neznamená nula. Bez nových nezávislých dat nebo validovaného error
modelu z nich nelze vytvořit combined threshold. Strojově čitelný audit je v
`post_audit_structural_uncertainty.csv`.

