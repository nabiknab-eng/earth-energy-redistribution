# Výsledky po adversariálním auditu

## Odpovědi na deset rozhodujících otázek

1. **Potvrdil se N1?** Ano (**CONFIRMED**). Nezměněný externí test dává pro
   primární HAC(24) coverage 77,9/76,8/69,0 % pro AR1 φ=0/0,6/0,9. Rozšířená
   matice dává 67,5–81,2 %.
2. **Jaký je kalibrovaný temporal detection limit na 60/65/70°N?** Primární
   plný předem deklarovaný DGP obal je **98,85 / 80,12 / 72,84 TW/dekádu**.
   Citlivost bez extrémního AR1 φ=0,9 je 76,27 / 61,82 / 56,19 TW/dekádu.
3. **Potvrdil se N2 annual difference?** Ano (**CONFIRMED**). Původní
   `maxlags=24` dává při n=16 coverage 45,8–51,1 %. Staré roční CI jsou
   neplatné; bodové odhady byly zachovány a intervaly nahrazeny lagem 2 plus
   MC kalibrací.
4. **Je původní structural bound obhajitelný?** Ne. Obsahoval temporal-MDE
   proxy, Earth-area sea-ice scaling a nedoložený glacier step.
5. **Co z něj zůstává?** Žádný obhajitelný combined probabilistický bound.
   Vyčíslen zůstává jen PIOMAS rescaling jako metodický scénář (0,34/0,33/0,32
   TW/dekádu na 60/65/70°N); deep ocean, cap OHC mapping, land/glacier storage
   a strukturální chyba PIOMAS/ERA5 jsou explicitně **UNQUANTIFIED**.
6. **Je storage alias sám statisticky rozeznatelný?** Ne. Na 60/65/70°N jsou
   trendy 21,30 / 18,23 / 12,18 s intervaly [−60,06; 102,66] / [−38,58;
   75,04] / [−36,51; 60,88] TW/dekádu.
7. **Změnily se bodové H_corr trendy?** Ne (numerická změna <10⁻¹²
   TW/dekádu).
8. **Změnilo se jejich znaménko?** Ne.
9. **Změnil se hlavní závěr?** Ne: robustní trend known-storage-corrected
   required transportu přes hlavní arktické hranice nebyl rozlišen. Změnila se
   síla a formulace důkazu: původní safe threshold se ruší a storage alias není
   nezávislá validace.
10. **Jak analýzu klasifikovat?** Energetické bodové rozklady jsou
    informativní, ale trendová část je při současné délce řady především
    **feasibility/detectability study**. Nedetekce není důkaz nuly.

## Hlavní post-audit výsledek

Všechny hodnoty jsou TW/dekádu. `H_corr` znamená
**known-storage-corrected required transport**, nikoli nezávisle pozorovaný
actual total transport.

| hranice | H_corr best | kalibrovaný 95% CI | temporální limit | ERA5 AHT best | ERA5 AHT 95% CI | unresolved remainder | rozhodnutí |
|---:|---:|---:|---:|---:|---:|---:|---|
| 50°N | 16,62 | [−139,00; 172,25] | 155,63 | 56,84 | [−45,53; 159,22] | −40,22 | NOT DETECTED |
| 60°N | 0,77 | [−98,08; 99,62] | 98,85 | 12,26 | [−61,36; 85,88] | −11,49 | NOT DETECTED |
| 65°N | −0,11 | [−80,23; 80,02] | 80,12 | 2,66 | [−58,79; 64,12] | −2,77 | NOT DETECTED |
| 70°N | 2,75 | [−70,08; 75,59] | 72,84 | −2,18 | [−47,47; 43,12] | 4,93 | NOT DETECTED |
| 75°N | 5,13 | [−53,01; 63,28] | 58,15 | 1,43 | [−22,28; 25,14] | 3,71 | NOT DETECTED |
| 80°N | 5,03 | [−34,79; 44,85] | 39,82 | 1,94 | [−5,23; 9,11] | 3,09 | NOT DETECTED |

Interval unresolved remainder je uložen v `POST_AUDIT_KEY_RESULTS.csv`; ani
remainder není oceánský transport a žádný jeho klíčový interval nevylučuje
nulu. Strukturální chyba ERA5 není těmito temporálními intervaly pokryta.

## Co se změnilo proti Etapě 9

| hranice | pre H_corr | post H_corr | změna best | pre nominální půlšířka | post kalibrovaná půlšířka | proč |
|---:|---:|---:|---:|---:|---:|---|
| 50°N | 16,62 | 16,62 | 0,00 | 66,75 | 155,63 | MC coverage correction |
| 60°N | 0,77 | 0,77 | 0,00 | 42,40 | 98,85 | MC coverage correction |
| 65°N | −0,11 | −0,11 | 0,00 | 34,37 | 80,12 | MC coverage correction |
| 70°N | 2,75 | 2,75 | 0,00 | 31,24 | 72,84 | MC coverage correction |
| 75°N | 5,13 | 5,13 | 0,00 | 24,94 | 58,15 | MC coverage correction |
| 80°N | 5,03 | 5,03 | 0,00 | 17,08 | 39,82 | MC coverage correction |

Původní structural bound 29,28/20,90/17,57/16,11/15,13/12,54 a původní safe
threshold 96,03/63,30/51,93/47,35/40,08/29,62 se po auditu nepoužívají. Není
pro ně vytvořena náhradní suma.

## Annual-difference oprava

Roční bodové H_corr trendy na 60/65/70°N jsou −1,06 / 0,07 / 4,64. Nové
kalibrované intervaly jsou [−72,48; 70,35] / [−51,02; 51,15] / [−35,65;
44,93]. Původní zdánlivě nenulový annual interval na 75°N [0,25; 14,43] se po
opravě mění na [−25,57; 40,25]. Roční větev tedy dál slouží jen jako bodová
derivátorová citlivost, nikoli jako nezávislý důkaz robustness.

## Storage alias a globální mean removal

Platí konstrukcí:

`H_raw = <N>global A_cap − N_cap`

`H_alias = <N>global A_cap − dE_known/dt`

`H_corr = H_raw − H_alias = dE_known/dt − N_cap`.

Proto je H_corr algebraicky nezávislé na monthly global-mean removal v raw
CERES implied transportu. Rozdíl raw versus corrected ukazuje velikost změny
mezi uniformním global-storage proxy a známým regionálním storage; není to druhé
nezávislé pozorování transportu. Interval aliasu je počítán přímo z jeho
společné měsíční řady, takže zachovává kovarianci vstupů.

## Strukturální limity

`safe threshold` není confidence interval, prediction interval ani formální
detekční práh. Automatické sčítání temporal MDE a scénářových konstant je
ukončeno. Post-audit rozhodnutí proto znamená pouze:

> Současná datová sestava v rámci deklarovaného Monte Carlo obalu nerozlišuje
> znaménko ani velikost trendu known-storage-corrected required transportu přes
> 50–80°N. Nevyčíslené strukturální nejistoty tento závěr nepřevádějí na důkaz
> nulového trendu.

Nejsou z toho vyvozovány příčiny změny ASR, CO₂, clouds, aerosols ani forcing.

## Auditní stopa

- předopravný snapshot: `audit_pre_correction_snapshot_20260808/`
- nezměněné externí běhy: `EXTERNAL_MC_REPRODUCTION.md`
- kalibrační matice: `MONTE_CARLO_CALIBRATION.md`
- strukturální přestavba: `STRUCTURAL_UNCERTAINTY_REBUILD.md`
- odpověď N1–N7/R1–R2: `AUDITOR_FINDINGS_RESPONSE.md`
- strojově čitelné výsledky: `POST_AUDIT_KEY_RESULTS.csv`,
  `POST_AUDIT_UNCERTAINTY.csv`, `STORAGE_ALIAS_WITH_CI.csv`
- testy: 66 PASS při `MPLCONFIGDIR=/private/tmp/mpl-stage10 .venv/bin/python -m pytest -q tests`

