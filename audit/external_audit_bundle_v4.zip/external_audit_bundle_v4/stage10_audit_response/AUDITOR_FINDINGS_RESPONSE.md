# Odpověď na nálezy externího auditu

| finding | auditor claim | reproduced? | correction | effect on main result |
|---|---|---|---|---|
| N1 | HAC(24) u primárního překryvného derivátoru má jen ~70–78% coverage a SE je podhodnocena | **CONFIRMED** | plná kalibrační matice; MC-envelope kritická hodnota 4,569 nad HAC(24) SE | bodové trendy stejné; intervaly podstatně širší; nedetekce zůstává |
| N2 | annual difference používá 15 efektivních lagů při n=16 a ~50% coverage | **CONFIRMED** | staré roční CI označeno INVALID; lag 2 + MC kritická hodnota 4,106 | bodové roční odhady stejné; žádný klíčový roční CI nevylučuje nulu |
| N3 | structural bound/safe threshold dvojitě počítá šum a obsahuje ad-hoc škálování | **CONFIRMED** | deep/OHC MDE složky, Earth-area sea-ice a glacier step vyřazeny; safe threshold zrušen | nelze dále tvrdit jedno combined číslo; hlavní temporální nedetekce se posuzuje samostatně |
| N4 | raw−alias=H_corr je algebraická identita, ne nezávislé potvrzení | **CONFIRMED** | storage alias přejmenován na rozklad uniform proxy vs known regional storage; vlastní joint-series CI | alias na klíčových hranicích sám není temporálně rozlišen; H_corr je nezávislé na monthly global-mean removal |
| N5 | některé PASS diagnostiky jsou identity | **PARTIALLY CONFIRMED** | diagnostiky rozděleny na identity, numerické, data-integrity a nezávislé testy | nemění čísla; snižuje důkazní váhu algebraických PASS. Static-mask check může detekovat změnu masky, ale ne Argo mapping/sampling error |
| N6 | chybějí testy inferenčního a structural aparátu | **CONFIRMED** | přidány trend/coverage/small-n/negative-variance, derivátor, structural a PIOMAS testy | 66 cílených testů prochází; chyby N1–N3 jsou nyní explicitně zachyceny |
| N7 | PIOMAS uniform scaling může vnášet trend; silent variance clamp; latentní regional-grid geometrie; další drobnosti | **PARTIALLY CONFIRMED** | scaling audit tří scénářů; záporná variance vyhazuje chybu; regionální latitude subset je odmítnut; annual lag deklarován | PIOMAS scaling mění H_corr jen o 0,17–0,35 TW/dekádu, tedy nemění hlavní výsledek; ostatní změny jsou preventivní |
| R1 | původní kritika tvrdila, že derivátory se skutečnou účinností liší 3× | **INVALID CRITICISM** | nezměněný head-to-head skript reprodukován | empirická SD se liší jen 0,93–1,04 relativně; primární volba nebyla „nejhorší“ |
| R2 | původní kritika stavěla na jediných signifikantních raw/SH intervalech | **INVALID CRITICISM** | všechny relevantní řady vyhodnoceny kalibrovanými intervaly | údajná signifikance mizí; nelze tvrdit, že storage correction odstranila nezávisle potvrzený signál |

## Doplňující poznámky

- Tvrzení auditu, že změna 1,9–2,7 % je „fyzikálně nepravděpodobná“, nebylo
  převzato. Monte Carlo kalibruje statistickou citlivost, nikoli fyzikální prior.
- Bodové bilanční rovnice, geometrie, znaménka a jednotky audit nevyvrátil a
  nové testy je nadále potvrzují.
- R1 a R2 jsou v auditním HTML označeny samotným auditorem jako retrakce;
  jejich reprodukce zde potvrzuje retrakci, nikoli původní kritiku.

