# Monte Carlo kalibrace trendové inference

## Účel a design

Kalibrace byla zvolena před aplikací na klimatická znaménka. Měsíční toková
tendence byla simulována, integrována na energetický stav a až potom zpracována
stejnými třemi derivátory jako data. Tím se zachovává překryv a autokorelace,
které derivátor sám vytváří.

- seed: `20260808`
- 600 realizací na buňku; MC chyba coverage je přibližně 0,9–2,0 procentního
  bodu podle coverage
- 299 bootstrap replikací na realizaci
- 216 měsíců (2005-01 až 2022-12)
- DGP: white noise; AR(1) φ=0,3/0,6/0,9; AR(2) (1,20, −0,35)
- pravdivý trend: 0, 10 a 40 TW/dekádu
- derivátory: block 12m, central endpoints, annual difference
- inference: původní HAC(24), HAC 0/3/6/12, automatický HAC, moving-block a
  non-overlap block bootstrap

Úplných 360 buněk je v `monte_carlo_calibration_matrix.csv`; metadata a
kritické hodnoty jsou v `monte_carlo_calibration_metadata.json`.

## Co se reprodukovalo

Původní HAC(24) u primárního derivátoru má přes celou matici coverage
67,5–81,2 % (medián 77,0 %) a maximální poměr empirická SD / průměrná SE 1,89.
To potvrzuje N1. Moving-block bootstrap s 12měsíčními bloky problém sám
neřeší: minimum coverage je 63,3 %; blok je kratší než efektivní závislost
vytvořená překryvným filtrem.

U annual difference má původní HAC(24) coverage 44,2–53,8 %. Automatický lag 2
je výrazně lepší (70,5–86,0 %), ale bez kalibrace stále nedosahuje 95 %.
Původní roční intervaly jsou proto označeny jako neplatné; bodové odhady zůstaly.

Změna pravdivého trendu mezi 0/10/40 TW/dekádu nemění závěr o coverage. Malé
nenulové průměrné bias v jednotlivých 600členných buňkách jsou kompatibilní s
Monte Carlo chybou; samostatný bezšumový test dává subprocentní kalendářní
odchylku derivátoru.

## Zvolená kalibrace

Žádná neadjustovaná metoda neměla přibližně nominální coverage v celé
deklarované matici. Proto se pro každý derivátor použil maximální
DGP-specifický 95. percentil `|odhad−pravda|/SE`:

| derivátor | základní SE | plný kritický násobek |
|---|---|---:|
| block_12m_means | HAC(24) | 4,569 |
| central_12m_endpoints | HAC(24) | 4,351 |
| annual_difference | opravený HAC(2) | 4,106 |

Pro block derivátor jsou DGP-specifické násobky 3,455 (white), 3,472
(AR1 0,3), 3,491 (AR1 0,6), 4,569 (AR1 0,9) a 3,525 (AR2). Plný obal je
zvolen proto, že současná data sama nedovolují spolehlivě identifikovat
nepozorovaný proces před překryvným filtrem. Citlivost bez AR1 φ=0,9 je však
vždy uvedena zvlášť.

Po této kalibraci je empirical coverage 93,8–99,0 % pro block, 94,5–99,3 %
pro central a 94,0–99,5 % pro annual. Odchylka minima od 95 % je s 600
realizacemi srovnatelná s Monte Carlo chybou.

## Detekční limit pro hlavní veličinu

Zde „empirický detekční limit“ znamená kalibrovanou 95% temporální půlšířku
konkrétního odhadu, nikoli univerzální fyzikální mez ani formální power-based
MDE.

| hranice | původní nominální půlšířka | bez AR1 φ=0,9 | plný DGP obal | % klimatologického H za dekádu |
|---:|---:|---:|---:|---:|
| 60°N | 42,40 | 76,27 | 98,85 | 2,95 % |
| 65°N | 34,37 | 61,82 | 80,12 | 3,14 % |
| 70°N | 31,24 | 56,19 | 72,84 | 4,12 % |

Externí jednospecifikační přepočet pro AR1 φ=0,6 dával přibližně 64/52/47
TW/dekádu. Není v rozporu s maticí; je užší, protože nepokrývá φ=0,9 ani celý
předem deklarovaný obal.

Výběr byl proveden podle coverage, nikoli podle toho, zda interval vyloučí
nulu. Žádné tvrzení o fyzikální pravděpodobnosti procentních změn z Monte
Carlo testu neplyne.

