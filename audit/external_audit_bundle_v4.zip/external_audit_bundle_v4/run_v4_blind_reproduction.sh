#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd -P)"
PYTHON_BIN="${PYTHON:-python3}"
WORKSPACE="${AUDIT_WORKSPACE:-$ROOT/work/raw_reproduction_workspace}"
export AUDIT_WORKSPACE="$WORKSPACE"
export MPLCONFIGDIR="${MPLCONFIGDIR:-$WORKSPACE/.mplconfig}"

mkdir -p "$WORKSPACE/raw" "$WORKSPACE/provenance" "$WORKSPACE/independent_era5"

if [[ "${SKIP_DOWNLOAD:-0}" == "1" ]]; then
  "$ROOT/download_all_original_data.sh" --mode existing
else
  "$ROOT/download_all_original_data.sh" --mode download
fi
"$PYTHON_BIN" "$ROOT/code/verify_original_data.py" --workspace-dir "$WORKSPACE"

"$PYTHON_BIN" - "$WORKSPACE" "$ROOT" <<'PY'
from pathlib import Path
import shutil
import sys
workspace, root = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
for name in ("tables", "outputs", "figures", "tests", "src"):
    target = workspace / name
    if target.parent != workspace:
        raise SystemExit(f"unsafe generated-directory target: {target}")
    shutil.rmtree(target, ignore_errors=True)
for name in ("tables", "outputs", "figures", "tests"):
    (workspace / name).mkdir()
shutil.copytree(root / "code" / "pre_audit_src", workspace / "src")
for test in (root / "tests").glob("test_*.py"):
    if test.name not in {"test_stage10_post_audit.py", "test_era5_independent_check.py", "test_v4_bundle_contract.py"}:
        shutil.copy2(test, workspace / "tests" / test.name)
for name in ("era5_global_aht_requests.json", "era5_transport_profile_requests.json", "era5_sh_atmospheric_storage_requests.json"):
    shutil.copy2(root / "code" / "era5" / "original_requests" / name, workspace / "provenance" / name)
PY

export PYTHONPATH="$WORKSPACE"
"$PYTHON_BIN" "$ROOT/code/era5/reduce_raw_era5_independently.py" --raw-dir "$WORKSPACE/raw/era5" --output-dir "$WORKSPACE/independent_era5"
"$PYTHON_BIN" "$ROOT/code/install_independent_era5_reductions.py" --independent-dir "$WORKSPACE/independent_era5" --workspace-dir "$WORKSPACE"

cd "$WORKSPACE"
"$PYTHON_BIN" -m src.validate_ceres
"$PYTHON_BIN" -m src.process_transport_profile_inputs
"$PYTHON_BIN" -m src.analyze_transport_profile
"$PYTHON_BIN" -m src.quantify_missing_storage
"$PYTHON_BIN" -m src.finalize_transport_outputs
"$PYTHON_BIN" -m src.build_global_energy_context
"$PYTHON_BIN" -m src.finalize_stage9_storage_corrected_transport
"$PYTHON_BIN" "$ROOT/code/extract_generated_pre_audit_baseline.py" --workspace-dir "$WORKSPACE"

"$PYTHON_BIN" - "$WORKSPACE" "$ROOT" <<'PY'
from pathlib import Path
import shutil
import sys
workspace, root = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
shutil.rmtree(workspace / "src")
shutil.copytree(root / "code" / "src", workspace / "src")
shutil.copy2(root / "tests" / "test_stage10_post_audit.py", workspace / "tests" / "test_stage10_post_audit.py")
PY

"$PYTHON_BIN" -m src.finalize_stage9_storage_corrected_transport
"$PYTHON_BIN" -m src.run_stage10_monte_carlo
"$PYTHON_BIN" -m src.finalize_stage10_post_audit
"$PYTHON_BIN" -m pytest -q "$WORKSPACE/tests" | tee "$WORKSPACE/outputs/BLIND_PIPELINE_TEST_RESULTS.txt"
"$PYTHON_BIN" -m pytest -q "$ROOT/tests/test_era5_independent_check.py" | tee "$WORKSPACE/outputs/ERA5_INDEPENDENT_TEST_RESULTS.txt"
"$PYTHON_BIN" "$ROOT/code/build_blind_results_table.py" --workspace-dir "$WORKSPACE"

{
  printf 'BLIND RAW REPRODUCTION COMPLETE\n'
  printf 'Workspace: %s\n' "$WORKSPACE"
  printf 'Author reference values were not calculation inputs and remain sealed.\n'
  printf 'Blind results: %s\n' "$WORKSPACE/outputs/INDEPENDENT_RAW_REPRODUCTION.csv"
  printf 'Next, and only now, run: ./compare_after_blind.sh\n'
} | tee "$WORKSPACE/outputs/BLIND_REPRODUCTION_RESULT.txt"
