# Prompt for the second independent external audit

You are an independent, adversarial scientific reviewer.  Your job is not to
confirm the authors.  Try to falsify:

A. that absolute meridional energy redistribution was reconstructed correctly;

B. that a trend in known-storage-corrected required transport is not robustly
distinguished by the current common record; and

C. that the repairs made after the first audit are methodologically valid.

Do not investigate attribution to CO2, clouds, aerosols or forcing.

## Mandatory completion condition

Download CERES EBAF Ed4.2.1, ERA5 derived mass-consistent energy/moisture
budget, NCEI OHC 0–2000 m and PIOMAS v2.1 from the official specifications.
Independently execute raw data → preprocessing → integration → storage →
transport → trend/inference.  Do not use bundled reference tables as inputs.

If you do not perform that chain, your verdict must be exactly:

> **INCOMPLETE — RAW DATA REPRODUCTION NOT PERFORMED.**

If a source fails, report `DATASET_DOWNLOAD_FAILED`, its URL/API error and all
unverified results.  Never substitute an author-reduced climate series.

You may and should ignore author helper functions for critical calculations.
Write your own area integration, transport integration, storage derivative and
statistics pipeline where feasible.  Treat the supplied code as an auditable
claim, not an oracle.

## Blind protocol

Before opening `reference_results/`, `reference_figures/` or
`REFERENCE_RESULTS_AFTER_BLIND_REPRODUCTION.md`:

1. download and validate all raw products;
2. preprocess them independently;
3. compute absolute TOA balance and transports;
4. compute storage correction and cap closure;
5. compute all trend and statistical results;
6. save your own `INDEPENDENT_RAW_REPRODUCTION.csv`.

Only then reveal author references and calculate differences.  Preserve both
the sealed and revealed files.

The mandatory CSV columns are:

`quantity, authors_reference, reviewer_raw_result, absolute_difference, relative_difference, units, status, probable_cause`.

Before reveal, put a literal sealed marker in `authors_reference` and leave
differences blank.  Include at least global ASR/OLR/NET, both NET zero
crossings, NH/SH implied-transport extrema and their latitudes,
cross-equatorial transport, selected-latitude CERES implied transport and ERA5
AHT, `H_corr` climatology and trend at 60/65/70°N, storage alias at those
boundaries, calibrated intervals and detection half-widths.

## A. Absolute redistribution audit

1. Verify `ASR`, positive-outward `OLR`, and positive-downward `N_TOA=ASR-OLR`.
2. Independently derive exact grid-cell/band areas and cosine weighting.
3. Trace every conversion `W m-2 → W → TW → PW`.
4. Verify latitude order, longitude duplication, integration direction and
   northward/poleward signs.
5. Verify the discrete derivative of transport against zonal mean-removed
   surplus/deficit.
6. Verify transport is zero at both poles and the global residual is numerical.
7. Reproduce NH/SH extrema, their latitudes, zero crossings and
   cross-equatorial transport without imposing hemispheric symmetry.
8. Determine whether the absolute several-PW magnitude is physically and
   numerically credible.  Use literature only as a sanity check, never as a
   tuning target.
9. Identify the strongest possible error in the absolute reconstruction.  A
   failed raw integration is potentially fatal regardless of trend results.

## B. ERA5 AHT audit

1. Confirm exact v1.0 product identity, mass consistency and definitions of
   total energy, moisture/latent and dry-static contributions from official
   metadata/documentation.
2. Independently integrate `tefln` in W m-1 around each latitude parallel.
3. Check absolute AHT, signs, poles, NH/SH asymmetry and trend.
4. Assess discontinuities at the supplied request-subset joins.
5. Assess observing-system and reanalysis structural trend risk.
6. State explicitly that ERA5 is a reanalysis, not direct independent
   observation.

## C. Storage and corrected budget

1. Derive `H_required=dE_cap/dt-N_cap` from conservation of energy.
2. Verify `H_corr=dE_known/dt-N_cap` and use the full name
   **known-storage-corrected required transport**.
3. Audit NCEI extensive-cell OHC units, cap integration, masks, coverage and
   differentiation; look for accidental second area weighting.
4. Audit ERA5 atmospheric storage and exact cap geometry.
5. Audit PIOMAS native-grid volume, official aggregate comparison, scaling
   factor/trend, `E_ice=-rho L V`, and cap tendency.  Check concentration is not
   counted twice.
6. Reproduce monthly scaling, constant mean scaling and no-scaling scenarios.
7. Identify omissions: >2000 m ocean, land, glaciers/ice sheets and ice
   enthalpy terms.
8. Verify `H_raw=<N>A_cap-N_cap`,
   `H_alias=<N>A_cap-dE_known/dt`, and
   `H_raw-H_alias=H_corr`.  Treat this as identity, not validation.
9. Test whether cancellation of the explicit global-mean term really makes
   `H_corr` algebraically independent of monthly mean removal, while separately
   assessing CERES EBAF global-constraint dependence.
10. Find the strongest possible error in storage correction.

## D. Non-atmospheric remainder

Audit `H_remainder=H_corr-AHT` in climatology and trend.  Do not automatically
call it OHT.  Determine whether its magnitude/profile is physically plausible
given ocean transport, omitted storage, observational error, mapping error and
reanalysis error.  State what, if anything, can safely be inferred.

## E. Post-audit statistical audit

Answer every question:

1. Is tendency → state → derivative Monte Carlo construction correct?
2. Is the inserted trend in the right estimand and free of calendar bias?
3. Are white/AR(1)/AR(2) processes a sufficient DGP envelope?
4. Is AR(1) phi=0.9 a legitimate stress test?
5. Are long memory, regime shifts, nonstationarity or heteroskedasticity needed?
6. Would a residual-based DGP be more defensible?
7. Is retaining HAC(24) SE and calibrating its critical value acceptable?
8. Is maximum-DGP q95 defensible, and may it be called a 95% CI rather than a
   calibrated scenario envelope?
9. Is critical value 4.569 stable to an out-of-sample seed and is 600
   simulations per cell adequate?
10. Was calibration evaluated in-sample?
11. Are block lengths 12 months too short?  Test 18/24/36 months where useful.
12. Compare fixed-b, sieve/parametric ARMA bootstrap, prewhitened HAC and/or
    alternative defensible methods.
13. Reproduce the invalid former annual HAC behavior and the lag-2 correction.
14. Test calibration transfer separately for `H_corr`, CERES raw, storage
    alias, ERA5 AHT and remainder.  Do not assume one critical value fits all.
15. Identify the strongest possible error in trend inference.

## F. Structural uncertainty and first-audit corrections

1. Decide whether retiring the former structural bound/safe threshold was
   correct.  Do not invent a new combined number merely for completeness.
2. Separate probabilistic uncertainty from scenario sensitivity.
3. Audit deep ocean, OHC mapping/sampling, PIOMAS structure, land heat,
   glaciers/ice sheets and ERA5 structural trend error.  Unquantified is not
   zero.
4. For each N1–N7 and R1–R2 in
   `RESPONSE_TO_FIRST_EXTERNAL_AUDIT.md`, state whether the reproduction,
   classification, repair and numerical consequence are correct.
5. Look for an uncertainty that was merely renamed rather than fixed.

## G. Figures and hidden circularity

For each reference figure, check numerical provenance, axes, units, sign
convention, observation/derived/reanalysis/residual labels and whether
climatology is confused with trend.  Judge scientific truthfulness, not design.

Search explicitly for:

- unit, sign, area or latitude-orientation errors;
- double counting or omitted storage;
- identities presented as independent validation;
- shared inputs and hidden circularity among CERES, OHC and ERA5 branches;
- reference results leaking into computation;
- tuning toward author numbers.

## H. Required falsification summary

State:

1. strongest possible error in absolute transport;
2. strongest error in storage correction;
3. strongest error in trend inference;
4. strongest error in ERA5 comparison;
5. strongest error in PIOMAS treatment;
6. whether hidden circularity exists;
7. whether any unit/sign/area error exists;
8. whether an algebraic identity is presented as validation;
9. whether uncertainty was only renamed;
10. which result survives the strongest attacks.

Propose the smallest decisive test for each of the two strongest objections.

## I. Split verdict

Give four independent verdicts:

**A. ABSOLUTE ENERGY REDISTRIBUTION:** reproduced / partially reproduced / not
reproduced / physically invalid / indeterminate.

**B. STORAGE-CORRECTED BUDGET:** reproduced / partially reproduced / not
reproduced / physically invalid / indeterminate.

**C. TREND INFERENCE:** robust / conservative but defensible / optimistic /
invalid / indeterminate.

**D. OVERALL SCIENTIFIC CLAIM:** supported / supported with major limitations /
feasibility-detectability only / physically indeterminate / unsupported.

Finally give a manuscript recommendation: accept / minor revision / major
revision / reject, with exact required corrections.  Distinguish data error,
method error, statistical insufficiency and genuine physical indeterminacy.
