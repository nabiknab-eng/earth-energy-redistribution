# Methods specification for independent implementation

## Quantities and signs

All radiative fluxes use positive downward at TOA:

`ASR = incoming solar - reflected shortwave`,

`OLR = outgoing longwave` (reported as a positive outward magnitude),

`N_TOA = ASR - OLR`.

Thus positive `N_TOA` is energy entering the Earth system.  Meridional
transport is positive northward on the global profile.  At an NH cap boundary,
positive poleward transport means northward into the cap.  A negative value on
the SH global profile represents southward transport.

## Exact spherical geometry

The implementation uses `R = 6,371,000 m`.  For a latitude band bounded by
`phi_s` and `phi_n`,

`A_band = 2 pi R^2 [sin(phi_n) - sin(phi_s)]`.

For cell-centred 1° CERES latitude rows, edges are the midpoints and are clipped
to ±90°.  The sum of row areas must equal `4 pi R^2`.  Convert in the explicit
order `W m-2 × m2 = W`, `1 TW = 1e12 W`, `1 PW = 1e15 W`.

## CERES implied transport

For each month remove the exact area-weighted global mean from zonal `N_TOA`:

`N*(phi,t) = N_TOA(phi,t) - <N_TOA>(t)`.

Starting at the South Pole, integrate the band powers to each latitude edge:

`H_raw(phi,t) = integral[-90,phi] N*(theta,t) dA`.

This construction makes `H_raw(-90)=H_raw(+90)=0`.  Its discrete latitude
derivative must recover the mean-removed band power.  Equivalently for an NH
cap poleward of boundary `phi`:

`H_raw = <N_TOA> A_cap - N_cap`,

where `N_cap = integral[phi,90] N_TOA dA`.  `H_raw` is a transport required by
the uniform-global-storage proxy; it is not independently observed actual
total transport.  Monthly mean removal can alias geographically nonuniform
storage into this quantity.

Climatological absolute transport uses the common CERES/ERA5 window in the
generated context products.  The code also reports CERES TOA climatology for
2001-01–2025-12 and the Loeb-style global sanity window 2000-03–2020-02.  Every
reported period travels with the output row.

## ERA5 atmospheric energy transport and storage

The source is the mass-consistent
`derived-reanalysis-energy-moisture-budget` v1.0 product.  For `tefln`, units
are W m-1.  At latitude `phi`, each unique 0.25° longitude cell contributes

`tefln × R cos(phi) delta_lambda` W.

Sum the 1,440 unique longitudes; exclude the duplicated cyclic endpoint.  The
result is total northward atmospheric energy transport through the parallel.
Set the two pole values to zero by geometry.  No latitude integration of
`tefln` is performed.

For atmospheric storage, `tetend` is W m-2.  Compute a zonal mean over unique
longitudes and multiply by exact clipped spherical row areas, then sum the cap.
The ERA5 field represents vertically integrated total atmospheric energy; the
product is a reanalysis diagnostic, not a direct observation.  The auditor
must independently check the product documentation for the total-energy,
moisture/latent-energy and mass-consistency definitions.

## Ocean and sea-ice storage

NCEI `h18_hc` is an **extensive** heat-content anomaly for each 1° ocean grid
cell in `10^18 J`; it is summed over cap cells without multiplying by area a
second time.  Land/fill cells are excluded.  The analysis uses 0–2000 m,
2005-01–2022-12.  Cap coverage and static valid masks are reported.

PIOMAS effective thickness is integrated using the native curvilinear grid
metrics and ocean mask.  Grid volume is compared with the official monthly
Pan-Arctic series.  The declared branch tests monthly official scaling,
constant mean scaling and no scaling.  Sea-ice latent energy relative to the
ice-free state is

`E_ice = - rho_ice L_f V`,

with `rho_ice = 917 kg m-3` and `L_f = 334,000 J kg-1`.  Melting therefore
raises this energy state.  Effective thickness already contains concentration;
concentration must not be applied again.

## Storage derivatives and cap closure

Three derivative constructions are retained:

- primary overlapping 12-month block means;
- central 12-month endpoints;
- annual difference, used as sensitivity only.

Calendar-aware elapsed seconds are used before conversion to W.  The known
storage state/tendency includes NCEI OHC 0–2000 m, ERA5 atmospheric storage and
NH PIOMAS latent storage.  It omits deep ocean, land, glaciers/ice sheets and
some ice enthalpy terms.

For an NH cap:

`H_required = dE_cap/dt - N_cap`,

`H_corr = dE_known/dt - N_cap`.

`H_corr` is named **known-storage-corrected required transport**.  It is not an
independently observed actual total transport.  Define

`H_alias = <N_TOA> A_cap - dE_known/dt`.

Then, algebraically,

`H_raw - H_alias = H_corr`.

That identity validates bookkeeping only; it is not independent evidence.
It also shows cancellation of the explicit monthly global-mean term.  The
auditor must still examine whether the CERES EBAF global energy constraint can
affect regional `N_cap` or covariance by another route.

The comparison remainder is

`H_remainder = H_corr - ERA5_AHT`.

It may contain ocean transport, omitted storage and correlated observational,
mapping or reanalysis error.  It must not automatically be called OHT.

## Trends and post-audit inference

Trends are OLS slopes expressed in TW decade-1.  Seasonal means are removed for
monthly series where declared.  Newey-West/HAC covariance uses the implemented
finite-sample normalization and rejects invalid small-sample/negative-variance
states.  The former annual `HAC(24)` interval is retired; annual difference uses
effective lag 2.

After the first audit, synthetic monthly tendency processes are integrated to
energy states and passed through the actual derivative estimators.  The DGP
matrix contains white noise, AR(1) `phi=0.3,0.6,0.9`, an AR(2) long-memory
stress process and inserted trends of 0, 10 and 40 TW decade-1.  It uses a fixed
seed, 600 simulations per cell and bootstrap comparisons.  The selected
interval scales HAC standard errors by the maximum DGP-specific empirical 95th
percentile of `|estimate-truth|/SE`.

This is best described as a **calibrated scenario envelope**, not a universal
probability statement.  The reviewer must test transfer to the multicomponent
real series, out-of-sample seeds, residual-based DGPs, longer memory, regime
shifts and alternative HAC/bootstrap methods.

## Structural uncertainty

The original additive `safe threshold` was retired because it mixed temporal
MDE proxies, scenario constants and double-counted components.  V4 keeps
temporal inference, quantified PIOMAS scaling sensitivity and unquantified
structural limitations separate.  Unquantified does not mean zero.
